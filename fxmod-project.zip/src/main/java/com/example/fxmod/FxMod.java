package com.example.fxmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class FxMod implements ModInitializer {
    public static final String ID = "fxmod";
    public static final Identifier FIRE_PACKET = new Identifier(ID, "fuga_fire");
    public static final Identifier IMPACT_PACKET = new Identifier(ID, "fuga_impact");
    public static final Identifier WHIP_PACKET = new Identifier(ID, "whip");
    public static final Identifier SPIKES_PACKET = new Identifier(ID, "spikes");
    public static final Identifier STOMP_PACKET = new Identifier(ID, "stomp");
    public static final Identifier CHRONO_PACKET = new Identifier(ID, "chrono");
    public static final Identifier CHRONO_START = new Identifier(ID, "chrono_start");

    public static final Item STORM_WAND = new StormWandItem(new FabricItemSettings().maxCount(1));
    public static final Item FUGA = new FugaItem(new FabricItemSettings().maxCount(1));

    @Override
    public void onInitialize() {
        Registry.register(Registries.ITEM, new Identifier(ID, "storm_wand"), STORM_WAND);
        Registry.register(Registries.ITEM, new Identifier(ID, "fuga"), FUGA);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> { e.add(STORM_WAND); e.add(FUGA); });
        ServerTickEvents.END_SERVER_TICK.register(server -> { Fx.tick(); FugaFx.tick(); FireWhip.tick(); Spikes.tick(); Chronos.tick(); });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> { Chronos.clear(); });
        ServerPlayNetworking.registerGlobalReceiver(CHRONO_PACKET, (server, player, handler, buf, sender) ->
            server.execute(() -> Chronos.start(player)));
        ServerPlayNetworking.registerGlobalReceiver(SPIKES_PACKET, (server, player, handler, buf, sender) ->
            server.execute(() -> Spikes.start(player)));
        ServerPlayNetworking.registerGlobalReceiver(WHIP_PACKET, (server, player, handler, buf, sender) -> {
            boolean off = buf.readBoolean();
            server.execute(() -> FireWhip.strike(player, off));
        });
    }
}
