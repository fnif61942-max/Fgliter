package com.example.fxmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import com.example.fxmod.wish.WishLexicon;
import com.example.fxmod.wish.WishRules;
import com.example.fxmod.wish.Wishes;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;

public class FxMod implements ModInitializer {
    public static final String ID = "fxmod";
    public static final Identifier FIRE_PACKET = new Identifier(ID, "fuga_fire");
    public static final Identifier IMPACT_PACKET = new Identifier(ID, "fuga_impact");
    public static final Identifier WHIP_PACKET = new Identifier(ID, "whip");
    public static final Identifier SPIKES_PACKET = new Identifier(ID, "spikes");
    public static final Identifier STOMP_PACKET = new Identifier(ID, "stomp");
    public static final Identifier CHRONO_PACKET = new Identifier(ID, "chrono");
    public static final Identifier CHRONO_START = new Identifier(ID, "chrono_start");
    public static final Identifier WISH_PACKET = new Identifier(ID, "wish");
    public static final Identifier WISH_START = new Identifier(ID, "wish_start");

    public static final Item STORM_WAND = new StormWandItem(new FabricItemSettings().maxCount(1));
    public static final Item FUGA = new FugaItem(new FabricItemSettings().maxCount(1));
    public static final Item CHRONO_WISH = new ChronoWishItem(new FabricItemSettings().maxCount(1).rarity(Rarity.EPIC));

    @Override
    public void onInitialize() {
        Registry.register(Registries.ITEM, new Identifier(ID, "storm_wand"), STORM_WAND);
        Registry.register(Registries.ITEM, new Identifier(ID, "fuga"), FUGA);
        Registry.register(Registries.ITEM, new Identifier(ID, "chrono_wish"), CHRONO_WISH);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> { e.add(STORM_WAND); e.add(FUGA); e.add(CHRONO_WISH); });
        ServerTickEvents.END_SERVER_TICK.register(server -> { Fx.tick(); FugaFx.tick(); FireWhip.tick(); Spikes.tick(); Chronos.tick(); Wishes.tick(); WishRules.tick(server); });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> { Chronos.clear(); Wishes.clear(); WishRules.clear(); WishLexicon.clear(); });
        ServerChunkEvents.CHUNK_LOAD.register(WishRules::onChunkLoad);
        ServerPlayNetworking.registerGlobalReceiver(WISH_PACKET, (server, player, handler, buf, sender) -> {
            String text = buf.readString(256);
            server.execute(() -> Wishes.submit(player, text));
        });
        ServerPlayNetworking.registerGlobalReceiver(CHRONO_PACKET, (server, player, handler, buf, sender) ->
            server.execute(() -> Chronos.start(player)));
        ServerPlayNetworking.registerGlobalReceiver(SPIKES_PACKET, (server, player, handler, buf, sender) ->
            server.execute(() -> Spikes.start(player)));
        ServerPlayNetworking.registerGlobalReceiver(WHIP_PACKET, (server, player, handler, buf, sender) -> {
            boolean off = buf.readBoolean();
            server.execute(() -> FireWhip.strike(player, off));
        });
    }
}
