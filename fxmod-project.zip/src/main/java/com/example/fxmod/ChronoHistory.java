package com.example.fxmod;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Журнал изменений блоков (кольцевой буфер). Нужен, чтобы «Хронос» мог откатить мир назад во времени. */
public final class ChronoHistory {
    public static final int CAP = 1 << 20, MASK = CAP - 1;   // ~1 млн записей на измерение (~16 МБ)
    public static final int WINDOW = 3600;                   // сколько тиков назад можно откатить (3600 = 3 минуты)
    /** Пока true — изменения не пишутся в журнал (идёт сам откат). */
    public static boolean suppress = false;

    private static final Map<RegistryKey<World>, Buf> BUFS = new HashMap<>();

    private static final class Buf {
        final long[] pos = new long[CAP];
        final int[] id = new int[CAP];     // id состояния блока ДО изменения; -1 = запись уже откачена
        final int[] tick = new int[CAP];
        int head = 0, size = 0;
    }

    public static final class Session {
        final ServerWorld w; final Buf b; int idx; public int total; public int done;
        Session(ServerWorld w, Buf b, int idx, int total) { this.w = w; this.b = b; this.idx = idx; this.total = total; }
        public boolean finished() { return done >= total; }
    }

    /** Очистить журнал (при остановке сервера — чтобы история одного мира не попала в другой). */
    public static void clear() { BUFS.clear(); suppress = false; }

    /** Вызывается миксином при каждом изменении блока на сервере. */
    public static void record(ServerWorld w, BlockPos pos, BlockState old) {
        if (suppress) return;
        Buf b = BUFS.computeIfAbsent(w.getRegistryKey(), k -> new Buf());
        int h = b.head;
        b.pos[h] = pos.asLong();
        b.id[h] = Block.getRawIdFromState(old);
        b.tick[h] = w.getServer().getTicks();
        b.head = (h + 1) & MASK;
        if (b.size < CAP) b.size++;
    }

    /** Начать откат: сессия включает все изменения за последние WINDOW тиков. */
    public static Session begin(ServerWorld w) {
        Buf b = BUFS.get(w.getRegistryKey());
        if (b == null || b.size == 0) return new Session(w, null, 0, 0);
        int cutoff = w.getServer().getTicks() - WINDOW;
        int n = 0;
        for (int i = 0; i < b.size; i++) {
            int j = (b.head - 1 - i) & MASK;
            if (b.id[j] < 0) continue;
            if (b.tick[j] < cutoff) break;
            n++;
        }
        return new Session(w, b, (b.head - 1) & MASK, n);
    }

    /** Откатить до want изменений (от новых к старым), не дольше deadline. Возвращает несколько позиций для эффектов. */
    public static void step(Session s, int want, long deadline, List<BlockPos> sample) {
        if (s.total == 0) return;
        suppress = true;
        try {
            while (want > 0 && s.done < s.total) {
                int j = s.idx;
                s.idx = (j - 1) & MASK;
                int id = s.b.id[j];
                if (id < 0) continue;
                BlockPos bp = BlockPos.fromLong(s.b.pos[j]);
                s.b.id[j] = -1;
                if (s.w.isChunkLoaded(bp)) {
                    s.w.setBlockState(bp, Block.getStateFromRawId(id), Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
                    if (sample != null && sample.size() < 40 && (s.done & 127) == 0) sample.add(bp);
                }
                s.done++;
                want--;
                if ((s.done & 63) == 0 && System.nanoTime() > deadline) break;
            }
        } finally {
            suppress = false;
        }
    }

    private ChronoHistory() {}
}
