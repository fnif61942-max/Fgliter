package com.example.fxmod.mixin;

import com.example.fxmod.ChronoHistory;
import net.minecraft.block.BlockState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Записывает каждое изменение блока в журнал истории (для отката мира способностью «Хронос»). */
@Mixin(WorldChunk.class)
public abstract class WorldChunkMixin {
    @Inject(method = "setBlockState", at = @At("RETURN"), require = 0)
    private void fxmod$record(BlockPos pos, BlockState state, boolean moved, CallbackInfoReturnable<BlockState> cir) {
        BlockState old = cir.getReturnValue();
        if (old == null) return;
        if (((WorldChunk) (Object) this).getWorld() instanceof ServerWorld sw) ChronoHistory.record(sw, pos, old);
    }
}
