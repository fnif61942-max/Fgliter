package com.example.fxmod.mixin;

import com.example.fxmod.client.ChronoClient;
import com.example.fxmod.client.FugaCinematic;
import com.example.fxmod.client.SpikeClient;
import com.example.fxmod.client.WishClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Во время кинокамеры не рисуем руку от первого лица; для «Хроно желания» меняем угол обзора (долли-зум). */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "renderHand", at = @At("HEAD"), cancellable = true, require = 0)
    private void fxmod$noHand(MatrixStack matrices, Camera camera, float tickDelta, CallbackInfo ci) {
        if (FugaCinematic.active() || SpikeClient.cineActive() || ChronoClient.cineActive() || WishClient.cineActive()) ci.cancel();
    }

    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void fxmod$fov(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        double f = WishClient.fovFactor(tickDelta);
        if (f != 1.0) cir.setReturnValue(cir.getReturnValue() * f);
    }
}
