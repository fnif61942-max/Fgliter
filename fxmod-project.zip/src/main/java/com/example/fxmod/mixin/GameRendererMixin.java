package com.example.fxmod.mixin;

import com.example.fxmod.client.ChronoClient;
import com.example.fxmod.client.FugaCinematic;
import com.example.fxmod.client.SpikeClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Страховка: во время кинокамеры никогда не рисуем руку от первого лица. */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "renderHand", at = @At("HEAD"), cancellable = true, require = 0)
    private void fxmod$noHand(MatrixStack matrices, Camera camera, float tickDelta, CallbackInfo ci) {
        if (FugaCinematic.active() || SpikeClient.cineActive() || ChronoClient.cineActive()) ci.cancel();
    }
}
