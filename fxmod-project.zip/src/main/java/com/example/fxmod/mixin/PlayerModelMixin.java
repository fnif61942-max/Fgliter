package com.example.fxmod.mixin;

import com.example.fxmod.client.SpikeClient;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Анимация удара ногой по земле (замах → удар → восстановление). */
@Mixin(PlayerEntityModel.class)
public abstract class PlayerModelMixin {
    @Inject(method = "setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void fxmod$stomp(LivingEntity entity, float f, float g, float h, float i, float j, CallbackInfo ci) {
        float[] p = SpikeClient.pose(entity.getId());
        if (p == null) return;
        PlayerEntityModel<?> m = (PlayerEntityModel<?>) (Object) this;
        m.rightLeg.pitch = p[0];
        m.leftLeg.pitch = p[1];
        m.rightArm.pitch = p[2];
        m.leftArm.pitch = p[2];
        m.body.pitch = p[3];
        m.head.pitch += p[4];
        m.leftPants.copyTransform(m.leftLeg);
        m.rightPants.copyTransform(m.rightLeg);
        m.leftSleeve.copyTransform(m.leftArm);
        m.rightSleeve.copyTransform(m.rightArm);
        m.jacket.copyTransform(m.body);
    }
}
