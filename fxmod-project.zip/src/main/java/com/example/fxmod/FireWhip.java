package com.example.fxmod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Arm;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Огненный хлыст: удар кулаком на расстоянии, 10 урона + поджог, хлыст идёт из той руки, которой бьёшь. */
public final class FireWhip {
    // ================= НАСТРОЙКИ =================
    public static final float DAMAGE = 10f;
    public static final double REACH = 16.0;   // дальность хлыста, блоков
    public static final int FIRE_SECONDS = 6;  // сколько секунд горит цель
    private static final int COOLDOWN = 7;     // тиков между ударами
    // =============================================

    private static final int DURATION = 7;
    private static final Map<UUID, Integer> LAST = new HashMap<>();
    private static final List<Lash> LASHES = new ArrayList<>();
    private static int now = 0;

    private static final class Lash {
        final ServerPlayerEntity p; final boolean off; final Vec3d tip; final boolean hit; int t = 0;
        Lash(ServerPlayerEntity p, boolean off, Vec3d tip, boolean hit) { this.p = p; this.off = off; this.tip = tip; this.hit = hit; }
    }

    private static void fx(ServerWorld w, ParticleEffect e, double x, double y, double z, int n, double dx, double dy, double dz, double sp) {
        for (ServerPlayerEntity pl : w.getPlayers()) w.spawnParticles(pl, e, true, x, y, z, n, dx, dy, dz, sp);
    }

    /** Откуда выходит хлыст: позиция руки (левая/правая с учётом ведущей руки игрока). */
    private static Vec3d handPos(ServerPlayerEntity p, boolean off) {
        Vec3d look = p.getRotationVec(1f);
        Vec3d right = look.crossProduct(new Vec3d(0, 1, 0));
        if (right.lengthSquared() < 1.0E-6) right = new Vec3d(1, 0, 0);
        right = right.normalize();
        boolean rightArm = (p.getMainArm() == Arm.RIGHT) != off;
        double side = rightArm ? 1 : -1;
        return p.getEyePos().add(look.multiply(0.7)).add(right.multiply(0.4 * side)).add(0, -0.35, 0);
    }

    public static void strike(ServerPlayerEntity p, boolean off) {
        ItemStack held = p.getMainHandStack();
        if (!(held.isEmpty() || held.isOf(FxMod.FUGA))) return;
        if (p.isUsingItem() || !p.isAlive() || p.isSpectator()) return;
        Integer last = LAST.get(p.getUuid());
        if (last != null && now - last < COOLDOWN - 2) return;
        LAST.put(p.getUuid(), now);

        ServerWorld w = p.getServerWorld();
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1f);
        Vec3d end = eye.add(look.multiply(REACH));

        HitResult bh = w.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        double maxDist = bh.getType() == HitResult.Type.MISS ? REACH : bh.getPos().distanceTo(eye);
        Vec3d limit = eye.add(look.multiply(maxDist));
        Box box = p.getBoundingBox().stretch(look.multiply(maxDist)).expand(1.0);
        EntityHitResult eh = ProjectileUtil.raycast(p, eye, limit, box,
                e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator() && e.canHit(), maxDist * maxDist);

        Vec3d tip = limit;
        boolean hit = false;
        if (eh != null) {
            Entity target = eh.getEntity();
            tip = eh.getPos();
            hit = true;
            target.damage(w.getDamageSources().playerAttack(p), DAMAGE);
            target.setOnFireFor(FIRE_SECONDS);
            if (target instanceof LivingEntity le) le.takeKnockback(0.4, -look.x, -look.z);
        }

        LASHES.add(new Lash(p, off, tip, hit));
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 0.7f, 1.6f);
        if (hit) w.playSound(null, BlockPosOf(tip), SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.PLAYERS, 1.0f, 1.2f);
    }

    private static net.minecraft.util.math.BlockPos BlockPosOf(Vec3d v) { return net.minecraft.util.math.BlockPos.ofFloored(v); }

    public static void tick() {
        now++;
        Iterator<Lash> it = LASHES.iterator();
        while (it.hasNext()) {
            Lash l = it.next();
            l.t++;
            if (!l.p.isAlive() || l.p.isRemoved() || l.t > DURATION) { it.remove(); continue; }
            draw(l);
        }
    }

    private static void draw(Lash l) {
        ServerWorld w = l.p.getServerWorld();
        Vec3d o = handPos(l.p, l.off);
        Vec3d d = l.tip.subtract(o);
        double len = d.length();
        if (len < 0.5) return;
        Vec3d dir = d.multiply(1.0 / len);
        Vec3d u = dir.crossProduct(new Vec3d(0, 1, 0));
        if (u.lengthSquared() < 1.0E-6) u = new Vec3d(1, 0, 0);
        u = u.normalize();                          // «вправо» относительно хлыста
        Vec3d v = dir.crossProduct(u).normalize();  // «вверх»
        boolean rightArm = (l.p.getMainArm() == Arm.RIGHT) != l.off;
        double side = rightArm ? 1 : -1;

        double prog = Math.min(1.0, l.t / 3.0);     // хлыст вытягивается за 3 тика
        // изгиб: хлыст описывает дугу от стороны руки и выпрямляется к щелчку
        double bend = side * len * 0.32 * (1.0 - 0.75 * Math.min(1.0, l.t / 5.0));
        double hump = len * 0.10 * (1.0 - Math.min(1.0, l.t / 6.0));
        Vec3d ctrl = o.add(d.multiply(0.5)).add(u.multiply(bend)).add(v.multiply(hump));
        double amp = 0.7 * (1.0 - l.t / (double) DURATION);

        int n = (int) (len * 2.5) + 8;
        for (int i = 0; i <= n; i++) {
            double s = i / (double) n;
            if (s > prog) break;
            double a0 = (1 - s) * (1 - s), b0 = 2 * (1 - s) * s, c0 = s * s;   // кривая Безье
            Vec3d pt = o.multiply(a0).add(ctrl.multiply(b0)).add(l.tip.multiply(c0));
            double wob = Math.sin(s * Math.PI * 3 - l.t * 1.5) * amp * Math.sin(s * Math.PI);
            pt = pt.add(u.multiply(wob)).add(v.multiply(wob * 0.4));
            fx(w, ParticleTypes.FLAME, pt.x, pt.y, pt.z, 1, 0.03, 0.03, 0.03, 0.01);
            if (i % 3 == 0) fx(w, ParticleTypes.SMOKE, pt.x, pt.y, pt.z, 1, 0.05, 0.05, 0.05, 0.01);
            if (i % 5 == 0) fx(w, ParticleTypes.LAVA, pt.x, pt.y, pt.z, 1, 0.05, 0.05, 0.05, 0);
        }
        if (l.t == 3) { // щелчок на конце
            fx(w, ParticleTypes.FLAME, l.tip.x, l.tip.y, l.tip.z, 30, 0.4, 0.4, 0.4, 0.1);
            fx(w, ParticleTypes.LAVA, l.tip.x, l.tip.y, l.tip.z, l.hit ? 8 : 3, 0.3, 0.3, 0.3, 0);
            if (l.hit) fx(w, ParticleTypes.EXPLOSION, l.tip.x, l.tip.y, l.tip.z, 1, 0, 0, 0, 0);
        }
    }

    private FireWhip() {}
}
