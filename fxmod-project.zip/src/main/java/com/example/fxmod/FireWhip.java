package com.example.fxmod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Arm;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Огненный хлыст: удар с размаху на расстоянии, 10 урона + поджог. Хлыст выходит из той руки, которой бьёшь. */
public final class FireWhip {
    // ================= НАСТРОЙКИ =================
    public static final float DAMAGE = 10f;
    public static final double REACH = 16.0;   // дальность хлыста, блоков
    public static final int FIRE_SECONDS = 6;  // сколько секунд горит цель
    private static final int COOLDOWN = 7;     // тиков между ударами
    // =============================================

    private static final int HIT_TICK = 4;     // тик, на котором хлыст «щёлкает» и наносит урон
    private static final int DURATION = 8;
    private static final Map<UUID, Integer> LAST = new HashMap<>();
    private static final List<Lash> LASHES = new ArrayList<>();
    private static int now = 0;

    private static final class Lash {
        final ServerPlayerEntity p; final boolean off; final Vec3d tip, look; final Entity target; int t = 0;
        Lash(ServerPlayerEntity p, boolean off, Vec3d tip, Vec3d look, Entity target) {
            this.p = p; this.off = off; this.tip = tip; this.look = look; this.target = target;
        }
    }

    private static void fx(ServerWorld w, ParticleEffect e, double x, double y, double z, int n, double dx, double dy, double dz, double sp) {
        for (ServerPlayerEntity pl : w.getPlayers()) w.spawnParticles(pl, e, true, x, y, z, n, dx, dy, dz, sp);
    }

    private static double smooth(double x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }

    /** Откуда выходит хлыст: позиция руки (левая/правая с учётом ведущей руки игрока). */
    private static Vec3d handPos(ServerPlayerEntity p, boolean off) {
        Vec3d look = p.getRotationVec(1f);
        Vec3d right = look.crossProduct(new Vec3d(0, 1, 0));
        if (right.lengthSquared() < 1.0E-6) right = new Vec3d(1, 0, 0);
        right = right.normalize();
        boolean rightArm = (p.getMainArm() == Arm.RIGHT) != off;
        double side = rightArm ? 1 : -1;
        return p.getEyePos().add(look.multiply(0.7)).add(right.multiply(0.4 * side)).add(0, -0.35, 0);
    }

    public static void strike(ServerPlayerEntity p, boolean off) {
        ItemStack held = p.getMainHandStack();
        if (!(held.isEmpty() || held.isOf(FxMod.FUGA))) return;
        if (p.isUsingItem() || !p.isAlive() || p.isSpectator()) return;
        Integer last = LAST.get(p.getUuid());
        if (last != null && now - last < COOLDOWN - 2) return;
        LAST.put(p.getUuid(), now);

        ServerWorld w = p.getServerWorld();
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1f);
        Vec3d end = eye.add(look.multiply(REACH));

        HitResult bh = w.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        double maxDist = bh.getType() == HitResult.Type.MISS ? REACH : bh.getPos().distanceTo(eye);
        Vec3d limit = eye.add(look.multiply(maxDist));
        Box box = p.getBoundingBox().stretch(look.multiply(maxDist)).expand(1.0);
        EntityHitResult eh = ProjectileUtil.raycast(p, eye, limit, box,
                e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator() && e.canHit(), maxDist * maxDist);

        Entity target = eh != null ? eh.getEntity() : null;
        Vec3d tip = eh != null ? eh.getPos() : limit;
        LASHES.add(new Lash(p, off, tip, look, target));
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.0f, 1.3f);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 0.5f, 1.7f);
    }

    public static void tick() {
        now++;
        Iterator<Lash> it = LASHES.iterator();
        while (it.hasNext()) {
            Lash l = it.next();
            l.t++;
            if (!l.p.isAlive() || l.p.isRemoved() || l.t > DURATION) { it.remove(); continue; }
            if (l.t == HIT_TICK) impact(l);
            draw(l);
        }
    }

    private static Vec3d tipNow(Lash l) {
        if (l.target != null && l.target.isAlive()) return l.target.getPos().add(0, l.target.getHeight() * 0.5, 0);
        return l.tip;
    }

    /** Момент щелчка: урон, поджог, толчок, вспышка и звук. */
    private static void impact(Lash l) {
        ServerWorld w = l.p.getServerWorld();
        Vec3d at = tipNow(l);
        boolean hit = false;
        if (l.target != null && l.target.isAlive()) {
            hit = true;
            l.target.damage(w.getDamageSources().playerAttack(l.p), DAMAGE);
            l.target.setOnFireFor(FIRE_SECONDS);
            if (l.target instanceof LivingEntity le) le.takeKnockback(0.4, -l.look.x, -l.look.z);
        }
        fx(w, ParticleTypes.FLAME, at.x, at.y, at.z, 30, 0.4, 0.4, 0.4, 0.1);
        fx(w, ParticleTypes.LAVA, at.x, at.y, at.z, hit ? 8 : 3, 0.3, 0.3, 0.3, 0);
        if (hit) fx(w, ParticleTypes.EXPLOSION, at.x, at.y, at.z, 1, 0, 0, 0, 0);
        w.playSound(null, BlockPos.ofFloored(at), SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, SoundCategory.PLAYERS, 1.0f, 1.6f);
        if (hit) w.playSound(null, BlockPos.ofFloored(at), SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.PLAYERS, 1.0f, 1.2f);
    }

    /**
     * Удар с размаху: хлыст сначала занесён вверх и в сторону руки, потом основание идёт за рукой,
     * а хвост запаздывает и догоняет — щелчок на конце.
     */
    private static void draw(Lash l) {
        ServerWorld w = l.p.getServerWorld();
        Vec3d o = handPos(l.p, l.off);
        Vec3d tip = tipNow(l);
        Vec3d d = tip.subtract(o);
        double len = d.length();
        if (len < 0.5) return;
        Vec3d dir = d.multiply(1.0 / len);
        Vec3d u = dir.crossProduct(new Vec3d(0, 1, 0));
        if (u.lengthSquared() < 1.0E-6) u = new Vec3d(1, 0, 0);
        u = u.normalize();                          // «вправо» относительно хлыста
        Vec3d v = dir.crossProduct(u).normalize();  // «вверх»
        boolean rightArm = (l.p.getMainArm() == Arm.RIGHT) != l.off;
        double side = rightArm ? 1 : -1;

        Vec3d dir0 = dir.multiply(0.25).add(u.multiply(side * 0.9)).add(v.multiply(1.0)).normalize(); // замах
        int n = (int) (len * 2) + 8;
        double seg = len / n;
        Vec3d pt = o;
        for (int i = 0; i < n; i++) {
            double s = i / (double) n;
            double q = smooth((l.t - 0.5 - 1.6 * s) / 2.6);       // хвост запаздывает
            Vec3d di = dir0.multiply(1 - q).add(dir.multiply(q));
            double dl = di.length();
            di = dl < 1.0E-4 ? dir : di.multiply(1.0 / dl);
            pt = pt.add(di.multiply(seg));
            // остаточный изгиб дугой + затухающая волна
            double arc = side * len * 0.10 * Math.sin(Math.PI * s) * (0.4 + 0.6 * q);
            double wob = Math.sin(s * Math.PI * 3 - l.t * 1.5) * 0.5 * (1.0 - l.t / (double) DURATION) * Math.sin(Math.PI * s);
            Vec3d p2 = pt.add(u.multiply(arc + wob)).add(v.multiply(wob * 0.4));
            fx(w, ParticleTypes.FLAME, p2.x, p2.y, p2.z, 1, 0.03, 0.03, 0.03, 0.01);
            if (i % 3 == 0) fx(w, ParticleTypes.SMOKE, p2.x, p2.y, p2.z, 1, 0.05, 0.05, 0.05, 0.01);
            if (i % 5 == 0) fx(w, ParticleTypes.LAVA, p2.x, p2.y, p2.z, 1, 0.05, 0.05, 0.05, 0);
        }
    }

    private FireWhip() {}
}
