package com.example.fxmod;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** «Fuga» — колоссальная огненная стрела: взрыв 50 м, 450 урона, кратер с магмой и обсидианом, столп до небес. */
public final class FugaFx {
    // ================= НАСТРОЙКИ =================
    public static final double RADIUS = 50.0;          // радиус взрыва, блоков
    private static final float DAMAGE = 450f;          // урон
    private static final boolean DESTROY_TERRAIN = true; // false = без разрушения блоков
    private static final int DENSITY = 2;              // плотность частиц: 1 = легче для телефона, 3 = максимум
    private static final long CARVE_BUDGET_NS = 18_000_000L; // сколько мс на тик тратить на разрушение
    private static final int CARVE_MAX_PER_TICK = 20000;
    // =============================================

    public static final double SPEED = 3.0; // блоков за тик — камера считает так же
    private static final double WAVE_SPEED = 2.4;
    private static final List<Bolt> BOLTS = new ArrayList<>();
    private static final List<Blast> BLASTS = new ArrayList<>();
    private static final List<Crater> CRATERS = new ArrayList<>();
    private static int[] OFFS;

    private static final class Bolt {
        final ServerWorld w; final LivingEntity owner; final Vec3d dir; Vec3d pos; int t = 0;
        Bolt(ServerWorld w, LivingEntity owner, Vec3d pos, Vec3d dir) { this.w = w; this.owner = owner; this.pos = pos; this.dir = dir; }
    }

    private static final class Blast {
        final ServerWorld w; final LivingEntity owner; final Vec3d pos; int t = 0;
        final Set<UUID> hit = new HashSet<>();
        Blast(ServerWorld w, LivingEntity owner, Vec3d pos) { this.w = w; this.owner = owner; this.pos = pos; }
    }

    private static final class Crater {
        final ServerWorld w; final int cx, cy, cz; int idx = 0;
        Crater(ServerWorld w, BlockPos c) { this.w = w; this.cx = c.getX(); this.cy = c.getY(); this.cz = c.getZ(); }
    }

    // ---------- частицы (видны камере даже далеко от игрока) ----------
    private static void fx(ServerWorld w, ParticleEffect e, double x, double y, double z, int n, double dx, double dy, double dz, double sp) {
        for (ServerPlayerEntity pl : w.getPlayers()) w.spawnParticles(pl, e, true, x, y, z, n, dx, dy, dz, sp);
    }

    /** Одна частица с заданной скоростью (для спиралей и падающих струй). */
    private static void fxv(ServerWorld w, ParticleEffect e, double x, double y, double z, double vx, double vy, double vz) {
        for (ServerPlayerEntity pl : w.getPlayers()) w.spawnParticles(pl, e, true, x, y, z, 0, vx, vy, vz, 1.0);
    }

    private static Vec3d[] basis(Vec3d dir) {
        Vec3d u = dir.crossProduct(new Vec3d(0, 1, 0));
        if (u.lengthSquared() < 1.0E-4) u = new Vec3d(1, 0, 0);
        u = u.normalize();
        return new Vec3d[]{u, dir.crossProduct(u).normalize()};
    }

    // ---------- зарядка и выстрел ----------
    public static void charge(ServerWorld w, LivingEntity p, int ticks) {
        Vec3d dir = p.getRotationVec(1f);
        Vec3d c = p.getEyePos().add(dir.multiply(2.0));
        Vec3d[] b = basis(dir);
        double r = Math.min(ticks, 20) * 0.06;
        for (int i = 0; i < 20; i++) {
            double a = i * Math.PI * 2 / 20 + ticks * 0.3;
            Vec3d o = b[0].multiply(Math.cos(a) * r).add(b[1].multiply(Math.sin(a) * r));
            fx(w, ParticleTypes.FLAME, c.x + o.x, c.y + o.y, c.z + o.z, 1, 0, 0, 0, 0.01);
        }
        for (int k = 0; k < 10; k++) {
            Vec3d s = c.add(dir.multiply(-1.0 + k * 0.3));
            fx(w, ParticleTypes.FLAME, s.x, s.y, s.z, 1, 0.03, 0.03, 0.03, 0.0);
        }
        fx(w, ParticleTypes.LAVA, p.getX(), p.getY() + 1, p.getZ(), 1, 0.6, 0.6, 0.6, 0);
        if (ticks == 20) {
            w.playSound(null, p.getBlockPos(), SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.PLAYERS, 2f, 0.6f);
            fx(w, ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        }
    }

    public static void fire(ServerWorld w, LivingEntity p) {
        offsets(); // заранее готовим сферу разрушения, чтобы не было подвисания при взрыве
        Vec3d dir = p.getRotationVec(1f);
        Vec3d start = p.getEyePos().add(dir.multiply(1.5));
        BOLTS.add(new Bolt(w, p, start, dir));
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 2f, 0.5f);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, SoundCategory.PLAYERS, 1.5f, 0.6f);
        if (p instanceof ServerPlayerEntity sp) {
            PacketByteBuf buf = PacketByteBufs.create();
            Vec3d eye = p.getEyePos();
            buf.writeDouble(eye.x); buf.writeDouble(eye.y); buf.writeDouble(eye.z);
            buf.writeDouble(dir.x); buf.writeDouble(dir.y); buf.writeDouble(dir.z);
            ServerPlayNetworking.send(sp, FxMod.FIRE_PACKET, buf);
        }
    }

    // ---------- главный тик ----------
    public static void tick() {
        Iterator<Bolt> it = BOLTS.iterator();
        while (it.hasNext()) {
            Bolt b = it.next();
            b.t++;
            boolean hit = false;
            for (int s = 0; s < 4 && !hit; s++) {
                b.pos = b.pos.add(b.dir.multiply(0.75));
                trail(b);
                BlockPos bp = BlockPos.ofFloored(b.pos);
                if (!b.w.getBlockState(bp).getCollisionShape(b.w, bp).isEmpty()) {
                    hit = true;
                    b.pos = b.pos.subtract(b.dir.multiply(0.75));
                } else if (!b.w.getOtherEntities(b.owner, new Box(b.pos, b.pos).expand(0.8),
                        e -> e instanceof LivingEntity && e.isAlive()).isEmpty()) {
                    hit = true;
                }
            }
            if (hit || b.t > 40) {
                explode(b);
                it.remove();
            }
        }

        Iterator<Blast> bi = BLASTS.iterator();
        while (bi.hasNext()) {
            Blast bl = bi.next();
            bl.t++;
            blastTick(bl);
            if (bl.t >= 120) bi.remove();
        }

        Iterator<Crater> ci = CRATERS.iterator();
        while (ci.hasNext()) {
            if (carveTick(ci.next())) ci.remove();
        }
    }

    private static void trail(Bolt b) {
        ServerWorld w = b.w;
        Vec3d[] bs = basis(b.dir);
        fx(w, ParticleTypes.FLAME, b.pos.x, b.pos.y, b.pos.z, 14, 0.3, 0.3, 0.3, 0.03);
        fx(w, ParticleTypes.LAVA, b.pos.x, b.pos.y, b.pos.z, 2, 0.25, 0.25, 0.25, 0);
        fx(w, ParticleTypes.SMOKE, b.pos.x, b.pos.y, b.pos.z, 3, 0.25, 0.25, 0.25, 0.01);
        fx(w, ParticleTypes.CAMPFIRE_COSY_SMOKE, b.pos.x, b.pos.y, b.pos.z, 1, 0.1, 0.1, 0.1, 0.02);
        for (int i = 0; i < 10; i++) {
            double a = i * Math.PI / 5 + b.t * 0.8;
            Vec3d o = bs[0].multiply(Math.cos(a)).add(bs[1].multiply(Math.sin(a)));
            fx(w, ParticleTypes.FLAME, b.pos.x + o.x, b.pos.y + o.y, b.pos.z + o.z, 1, 0, 0, 0, 0.0);
        }
    }

    // ---------- взрыв ----------
    private static void explode(Bolt b) {
        ServerWorld w = b.w;
        Vec3d p = b.pos;
        BLASTS.add(new Blast(w, b.owner, p));
        if (DESTROY_TERRAIN) CRATERS.add(new Crater(w, BlockPos.ofFloored(p)));

        fx(w, ParticleTypes.FLASH, p.x, p.y, p.z, 8, 3, 3, 3, 0);
        fx(w, ParticleTypes.EXPLOSION_EMITTER, p.x, p.y, p.z, 8, 6, 4, 6, 0);
        fx(w, ParticleTypes.FLAME, p.x, p.y, p.z, 1500, 6, 6, 6, 0.6);
        fx(w, ParticleTypes.LAVA, p.x, p.y, p.z, 300, 8, 6, 8, 0);
        fx(w, ParticleTypes.LARGE_SMOKE, p.x, p.y, p.z, 400, 8, 6, 8, 0.15);
        w.playSound(null, BlockPos.ofFloored(p), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 10f, 0.5f);

        if (b.owner instanceof ServerPlayerEntity sp) {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeDouble(p.x); buf.writeDouble(p.y); buf.writeDouble(p.z);
            ServerPlayNetworking.send(sp, FxMod.IMPACT_PACKET, buf);
        }
    }

    // ---------- что происходит после взрыва ----------
    private static void blastTick(Blast bl) {
        ServerWorld w = bl.w;
        Vec3d p = bl.pos;
        int t = bl.t;
        double rNow = Math.min(RADIUS, t * WAVE_SPEED);
        double rPrev = Math.min(RADIUS, (t - 1) * WAVE_SPEED);

        if (t <= 30) waveDamage(bl, rNow);
        if (t <= 24) spiralWave(bl, rPrev, rNow);
        pillar(bl);
        spiralRain(bl);

        if (t >= 8 && t <= 90) { // огненный и пепельный дождь по всей зоне
            fx(w, ParticleTypes.FALLING_LAVA, p.x, p.y + 45, p.z, 70, 40, 20, 40, 0);
            fx(w, ParticleTypes.ASH, p.x, p.y + 25, p.z, 100, 45, 25, 45, 0.02);
        }
        if (t == 1) fx(w, ParticleTypes.FLASH, p.x, p.y + 2, p.z, 10, 4, 4, 4, 0);
        if (t == 5) w.playSound(null, BlockPos.ofFloored(p), SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, SoundCategory.PLAYERS, 10f, 0.4f);
        if (t == 12) w.playSound(null, BlockPos.ofFloored(p), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 10f, 0.5f);
        if (t == 25) w.playSound(null, BlockPos.ofFloored(p), SoundEvents.ENTITY_WITHER_DEATH, SoundCategory.PLAYERS, 6f, 0.5f);
    }

    /** Ударная волна накрывает существ по мере расширения до 50 блоков. */
    private static void waveDamage(Blast bl, double rNow) {
        Vec3d p = bl.pos;
        Box area = new Box(p, p).expand(RADIUS);
        for (Entity e : bl.w.getOtherEntities(bl.owner, area, en -> en instanceof LivingEntity && !bl.hit.contains(en.getUuid()))) {
            double d = e.getPos().distanceTo(p);
            if (d > rNow) continue;
            bl.hit.add(e.getUuid());
            e.damage(bl.w.getDamageSources().indirectMagic(bl.owner, bl.owner), DAMAGE);
            e.setOnFireFor(15);
            Vec3d kb = e.getPos().subtract(p).normalize().multiply(2.5).add(0, 1.0, 0);
            e.setVelocity(kb);
            e.velocityModified = true;
        }
    }

    /** Ударная волна из спиральных рукавов + плотный фронт. */
    private static void spiralWave(Blast bl, double r0, double r1) {
        ServerWorld w = bl.w;
        Vec3d p = bl.pos;
        int t = bl.t;
        int arms = 8;
        for (int k = 0; k < arms; k++) {
            for (double r = r0; r < r1; r += 0.35) {
                double a = r * 0.11 + k * (Math.PI * 2 / arms) + t * 0.25;
                double x = p.x + Math.cos(a) * r, z = p.z + Math.sin(a) * r;
                double tx = -Math.sin(a), tz = Math.cos(a);
                fxv(w, ParticleTypes.FLAME, x, p.y + 0.4, z, tx * 0.5, 0.45, tz * 0.5);
                fxv(w, ParticleTypes.FLAME, x, p.y + 1.5, z, tx * 0.4, 0.8, tz * 0.4);
                fxv(w, ParticleTypes.LARGE_SMOKE, x, p.y + 0.8, z, tx * 0.3, 0.3, tz * 0.3);
            }
        }
        int pts = (int) (r1 * 3) + 24;
        for (int i = 0; i < pts; i++) {
            double a = i * (Math.PI * 2 / pts) + t * 0.2;
            double x = p.x + Math.cos(a) * r1, z = p.z + Math.sin(a) * r1;
            fx(w, ParticleTypes.FLAME, x, p.y + 0.5, z, 3, 0.3, 0.8, 0.3, 0.1);
            if (i % 3 == 0) fx(w, ParticleTypes.LAVA, x, p.y + 0.6, z, 1, 0.3, 0.3, 0.3, 0);
        }
    }

    /** Сплошной столп огня до потолка мира + шапка из дыма. */
    private static void pillar(Blast bl) {
        int t = bl.t;
        if (t > 100) return;
        ServerWorld w = bl.w;
        Vec3d p = bl.pos;
        double H = Math.max(60, w.getTopY() - p.y);
        double h = Math.min(H, t * 16.0);
        double fade = t > 60 ? Math.max(0.2, 1.0 - (t - 60) / 45.0) : 1.0;
        for (double y = 0; y <= h; y += 4) {
            double rad = 10 - 4 * (y / H);
            double sd = rad * 0.42;
            fx(w, ParticleTypes.FLAME, p.x, p.y + y, p.z, (int) (20 * DENSITY * fade), sd, 2.2, sd, 0.05);
            fx(w, ParticleTypes.LAVA, p.x, p.y + y, p.z, Math.max(1, (int) (3 * DENSITY * fade)), sd, 2.0, sd, 0);
            fx(w, ParticleTypes.LARGE_SMOKE, p.x, p.y + y, p.z, (int) (4 * DENSITY * fade), sd * 1.2, 2.0, sd * 1.2, 0.03);
        }
        if (t >= 12 && t <= 70) {
            double y = p.y + h;
            fx(w, ParticleTypes.LARGE_SMOKE, p.x, y, p.z, 60 * DENSITY, 22, 4, 22, 0.08);
            fx(w, ParticleTypes.FLAME, p.x, y, p.z, 40 * DENSITY, 16, 3, 16, 0.1);
        }
    }

    /** Частицы быстро падают вниз по спиралям (винтовые струи огня). */
    private static void spiralRain(Blast bl) {
        int t = bl.t;
        if (t < 6 || t > 90) return;
        ServerWorld w = bl.w;
        Vec3d p = bl.pos;
        double top = Math.min(w.getTopY() - p.y, 16.0 * t);
        int strands = 7, samples = 16;
        for (int k = 0; k < strands; k++) {
            double rad = 5 + k * 6.5;
            for (int j = 0; j < samples; j++) {
                double hh = top * (j + (t % 3) / 3.0) / samples;
                double a = t * 0.45 - hh * 0.06 + k * 1.05;
                double x = p.x + Math.cos(a) * rad, z = p.z + Math.sin(a) * rad;
                double tx = -Math.sin(a), tz = Math.cos(a);
                fxv(w, ParticleTypes.FLAME, x, p.y + hh, z, tx * 0.9, -2.2, tz * 0.9);
                fxv(w, ParticleTypes.FLAME, x, p.y + hh, z, tx * 0.6, -2.6, tz * 0.6);
                if (j % 4 == 0) fxv(w, ParticleTypes.LAVA, x, p.y + hh, z, tx * 0.5, -1.8, tz * 0.5);
            }
        }
    }

    // ---------- разрушение террейна: кратер 50 м с магмой и обсидианом ----------
    private static int[] offsets() {
        if (OFFS != null) return OFFS;
        int R = (int) RADIUS;
        int side = 2 * R + 1;
        long[] tmp = new long[side * side * side];
        int n = 0;
        for (int dx = -R; dx <= R; dx++)
            for (int dy = -R; dy <= R; dy++)
                for (int dz = -R; dz <= R; dz++) {
                    int d2 = dx * dx + dy * dy + dz * dz;
                    if (d2 > R * R) continue;
                    tmp[n++] = ((long) d2 << 21) | ((long) (dx + R) << 14) | ((long) (dy + R) << 7) | (dz + R);
                }
        Arrays.sort(tmp, 0, n); // от центра наружу
        int[] out = new int[n];
        for (int i = 0; i < n; i++) out[i] = (int) (tmp[i] & 0x1FFFFF);
        OFFS = out;
        return out;
    }

    /** Возвращает true, когда кратер закончен. */
    private static boolean carveTick(Crater c) {
        int[] offs = offsets();
        int R = (int) RADIUS;
        double inner = R - 1.6;
        ServerWorld w = c.w;
        long deadline = System.nanoTime() + CARVE_BUDGET_NS;
        BlockPos.Mutable m = new BlockPos.Mutable();
        int done = 0;
        while (c.idx < offs.length && done < CARVE_MAX_PER_TICK) {
            if ((done & 63) == 0 && System.nanoTime() > deadline) break;
            int o = offs[c.idx++];
            done++;
            int dx = ((o >> 14) & 127) - R, dy = ((o >> 7) & 127) - R, dz = (o & 127) - R;
            m.set(c.cx + dx, c.cy + dy, c.cz + dz);
            if (m.getY() < w.getBottomY() || m.getY() >= w.getTopY()) continue;
            if (!w.isChunkLoaded(m)) continue;
            BlockState st = w.getBlockState(m);
            if (st.isAir()) continue;
            if (st.getHardness(w, m) < 0) continue; // бедрок и т.п.
            BlockState ns = Blocks.AIR.getDefaultState();
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dy <= 0 && d >= inner) { // дно кратера: обсидиан и магма
                int h = ((dx * 73856093) ^ (dy * 19349663) ^ (dz * 83492791)) & 255;
                ns = h < 85 ? Blocks.MAGMA_BLOCK.getDefaultState()
                        : h < 100 ? Blocks.CRYING_OBSIDIAN.getDefaultState()
                        : Blocks.OBSIDIAN.getDefaultState();
            }
            w.setBlockState(m, ns, Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
        }
        return c.idx >= offs.length;
    }

    private FugaFx() {}
}
