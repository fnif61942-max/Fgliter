package com.example.fxmod;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.AbstractFireBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * «Fuga» (порт на Fabric). Структура способности и числа (зарядка 200 тиков, орб 80, скорость 4 с разгоном,
 * дальность 160, радиус 48, столп 384, кулдаун 1200) основаны на God Wand авторов HyIsNoob / KhangHy (MIT).
 * Весь код и эффекты написаны заново, ассеты (звуки, текстуры) оригинала не используются.
 */
public final class FugaFx {
    // ================= НАСТРОЙКИ =================
    public static final int CHARGE_TICKS = 200;        // сколько держать ПКМ (200 = 10 сек)
    public static final int ORB_TICKS = 80;            // за сколько тиков вырастает огненный шар
    public static final int COOLDOWN = 1200;          // перезарядка (1200 = 60 сек)
    public static final double RADIUS = 48.0;          // радиус взрыва
    public static final double MAX_RANGE = 160.0;      // дальность полёта стрелы
    public static final double SPEED = 4.0;            // макс. скорость стрелы, блоков за тик
    public static final double EASE = 6.0;             // разгон стрелы
    private static final float DAMAGE = 450f;          // урон
    private static final int COLUMN_HEIGHT = 384;      // высота огненного столпа
    private static final boolean DESTROY_TERRAIN = true; // false = без разрушения блоков
    private static final int DENSITY = 2;              // плотность частиц: 1 = легче для телефона, 3 = максимум
    private static final long CARVE_BUDGET_NS = 18_000_000L;
    private static final int CARVE_MAX_PER_TICK = 20000;
    // =============================================

    private static final double WAVE_SPEED = 2.4;
    private static final Random RNG = new Random();
    private static final List<Bolt> BOLTS = new ArrayList<>();
    private static final List<Blast> BLASTS = new ArrayList<>();
    private static final List<Crater> CRATERS = new ArrayList<>();
    private static int[] OFFS;

    /** Расстояние, пролетаемое стрелой за age тиков: плавный разгон до SPEED. */
    public static double flightDistance(double age) {
        if (age <= 0) return 0;
        return SPEED * (age - EASE * (1 - Math.exp(-age / EASE)));
    }

    private static final class Bolt {
        final ServerWorld w; final LivingEntity owner; final Vec3d origin, dir; final double total; int age = 0; double prev = 0;
        Bolt(ServerWorld w, LivingEntity owner, Vec3d origin, Vec3d dir, double total) {
            this.w = w; this.owner = owner; this.origin = origin; this.dir = dir; this.total = total;
        }
    }

    private static final class Blast {
        final ServerWorld w; final LivingEntity owner; final Vec3d pos; int t = 0;
        final Set<UUID> hit = new HashSet<>();
        Blast(ServerWorld w, LivingEntity owner, Vec3d pos) { this.w = w; this.owner = owner; this.pos = pos; }
    }

    private static final class Crater {
        final ServerWorld w; final int cx, cy, cz; int idx = 0;
        Crater(ServerWorld w, BlockPos c) { this.w = w; this.cx = c.getX(); this.cy = c.getY(); this.cz = c.getZ(); }
    }

    // ---------- частицы (видны камере даже далеко от игрока) ----------
    private static void fx(ServerWorld w, ParticleEffect e, double x, double y, double z, int n, double dx, double dy, double dz, double sp) {
        for (ServerPlayerEntity pl : w.getPlayers()) w.spawnParticles(pl, e, true, x, y, z, n, dx, dy, dz, sp);
    }

    private static void fxv(ServerWorld w, ParticleEffect e, double x, double y, double z, double vx, double vy, double vz) {
        for (ServerPlayerEntity pl : w.getPlayers()) w.spawnParticles(pl, e, true, x, y, z, 0, vx, vy, vz, 1.0);
    }

    private static Vec3d[] basis(Vec3d dir) {
        Vec3d u = dir.crossProduct(new Vec3d(0, 1, 0));
        if (u.lengthSquared() < 1.0E-4) u = new Vec3d(1, 0, 0);
        u = u.normalize();
        return new Vec3d[]{u, dir.crossProduct(u).normalize()};
    }

    private static boolean targetable(Entity e, LivingEntity owner) {
        if (e == owner || !e.isAlive()) return false;
        return !(e instanceof PlayerEntity pl && (pl.isCreative() || pl.isSpectator()));
    }

    // ---------- зарядка: орб огня, вихри, втягивание энергии ----------
    public static void charge(ServerWorld w, LivingEntity p, int ticks) {
        Vec3d dir = p.getRotationVec(1f);
        Vec3d c = p.getEyePos().add(dir.multiply(3.5));
        double grow = Math.min(1.0, ticks / (double) ORB_TICKS);
        double energy = Math.min(1.0, ticks / (double) CHARGE_TICKS);
        double r = 0.4 + 2.6 * grow;

        // оболочка орба
        int shell = 20 + (int) (40 * grow);
        for (int i = 0; i < shell; i++) {
            double th = RNG.nextDouble() * Math.PI * 2, z = RNG.nextDouble() * 2 - 1, rr = Math.sqrt(1 - z * z);
            fx(w, ParticleTypes.FLAME, c.x + rr * Math.cos(th) * r, c.y + z * r, c.z + rr * Math.sin(th) * r, 1, 0, 0, 0, 0.0);
        }
        fx(w, ParticleTypes.LAVA, c.x, c.y, c.z, 2, r * 0.6, r * 0.6, r * 0.6, 0);

        // вращающиеся кольца вокруг орба
        Vec3d[] b = basis(dir);
        for (int k = 0; k < 3; k++) {
            for (int i = 0; i < 18; i++) {
                double a = i * Math.PI * 2 / 18 + ticks * (0.25 + 0.1 * k) + k * 2.1;
                double rr = r * (1.3 + 0.25 * k);
                double tilt = k * 0.6;
                Vec3d o = b[0].multiply(Math.cos(a) * rr).add(b[1].multiply(Math.sin(a) * rr * Math.cos(tilt))).add(dir.multiply(Math.sin(a) * rr * Math.sin(tilt)));
                fx(w, ParticleTypes.FLAME, c.x + o.x, c.y + o.y, c.z + o.z, 1, 0, 0, 0, 0.0);
            }
        }

        // огонь втягивается в орб со всех сторон
        if (ticks > 15) {
            int n = (int) (4 + 14 * energy) * DENSITY;
            for (int i = 0; i < n; i++) {
                double a = RNG.nextDouble() * Math.PI * 2, d = 8 + RNG.nextDouble() * 18;
                Vec3d s = new Vec3d(c.x + Math.cos(a) * d, p.getY() + RNG.nextDouble() * 8, c.z + Math.sin(a) * d);
                Vec3d v = c.subtract(s).normalize().multiply(0.9);
                fxv(w, ParticleTypes.FLAME, s.x, s.y, s.z, v.x, v.y, v.z);
            }
        }
        // трещины магмы вокруг игрока по мере зарядки
        if (ticks > 40) {
            fx(w, ParticleTypes.LAVA, p.getX(), p.getY() + 0.2, p.getZ(), (int) (1 + 4 * energy), 2 + 6 * energy, 0.1, 2 + 6 * energy, 0);
            fx(w, ParticleTypes.CAMPFIRE_COSY_SMOKE, p.getX(), p.getY() + 0.3, p.getZ(), 1, 4, 0.1, 4, 0.02);
        }

        // звук растёт по тону
        if (ticks % 25 == 0)
            w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_FIRE_AMBIENT, SoundCategory.PLAYERS, 3f, (float) (0.5 + grow));
        if (ticks == ORB_TICKS)
            w.playSound(null, p.getBlockPos(), SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.PLAYERS, 4f, 0.5f);
        if (ticks == CHARGE_TICKS) {
            w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 4f, 0.5f);
            fx(w, ParticleTypes.FLASH, c.x, c.y, c.z, 3, 0.5, 0.5, 0.5, 0);
        }

        if (p instanceof ServerPlayerEntity sp && ticks % 5 == 0) {
            sp.sendMessage(Text.literal(ticks >= CHARGE_TICKS ? "Fuga: ГОТОВО, отпусти ПКМ!" : "Fuga: " + (ticks * 100 / CHARGE_TICKS) + "%"), true);
        }
    }

    // ---------- выстрел ----------
    public static void fire(ServerWorld w, LivingEntity p) {
        offsets();
        Vec3d dir = p.getRotationVec(1f);
        Vec3d eye = p.getEyePos();
        Vec3d start = eye.add(dir.multiply(1.5));

        // дальность: до блока или 160, но не дальше загруженных чанков
        Vec3d end = eye.add(dir.multiply(MAX_RANGE));
        HitResult hr = w.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        double dist = hr.getType() == HitResult.Type.MISS ? MAX_RANGE : hr.getPos().distanceTo(eye) - 1.0;
        for (double s = 16; s <= dist; s += 16) {
            Vec3d q = eye.add(dir.multiply(s));
            if (!w.isChunkLoaded(BlockPos.ofFloored(q))) { dist = s - 16; break; }
        }
        double total = Math.max(2.0, dist - 1.5);

        BOLTS.add(new Bolt(w, p, start, dir, total));

        p.setVelocity(-dir.x * 0.55, 0.12, -dir.z * 0.55); // отдача
        p.velocityModified = true;
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 4f, 0.4f);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, SoundCategory.PLAYERS, 4f, 0.5f);
        fx(w, ParticleTypes.EXPLOSION_EMITTER, start.x, start.y, start.z, 1, 0, 0, 0, 0);
        if (p instanceof ServerPlayerEntity sp) {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeDouble(eye.x); buf.writeDouble(eye.y); buf.writeDouble(eye.z);
            buf.writeDouble(dir.x); buf.writeDouble(dir.y); buf.writeDouble(dir.z);
            ServerPlayNetworking.send(sp, FxMod.FIRE_PACKET, buf);
        }
    }

    // ---------- главный тик ----------
    public static void tick() {
        Iterator<Bolt> it = BOLTS.iterator();
        while (it.hasNext()) {
            Bolt b = it.next();
            b.age++;
            double d = Math.min(b.total, flightDistance(b.age));
            for (double s = b.prev + 0.75; s <= d; s += 0.75) trail(b, b.origin.add(b.dir.multiply(s)), b.age);
            b.prev = d;
            if (d >= b.total - 1.0E-6 || b.age > 200) {
                explode(b, b.origin.add(b.dir.multiply(d)));
                it.remove();
            }
        }

        Iterator<Blast> bi = BLASTS.iterator();
        while (bi.hasNext()) {
            Blast bl = bi.next();
            bl.t++;
            blastTick(bl);
            if (bl.t >= 160) bi.remove();
        }

        Iterator<Crater> ci = CRATERS.iterator();
        while (ci.hasNext()) {
            Crater c = ci.next();
            if (carveTick(c)) { spires(c); ci.remove(); }
        }
    }

    private static void trail(Bolt b, Vec3d pos, int age) {
        ServerWorld w = b.w;
        Vec3d[] bs = basis(b.dir);
        fx(w, ParticleTypes.FLAME, pos.x, pos.y, pos.z, 14, 0.4, 0.4, 0.4, 0.03);
        fx(w, ParticleTypes.LAVA, pos.x, pos.y, pos.z, 2, 0.3, 0.3, 0.3, 0);
        fx(w, ParticleTypes.SMOKE, pos.x, pos.y, pos.z, 3, 0.3, 0.3, 0.3, 0.01);
        fx(w, ParticleTypes.CAMPFIRE_COSY_SMOKE, pos.x, pos.y, pos.z, 1, 0.1, 0.1, 0.1, 0.02);
        for (int i = 0; i < 10; i++) {
            double a = i * Math.PI / 5 + age * 0.8;
            Vec3d o = bs[0].multiply(Math.cos(a) * 1.2).add(bs[1].multiply(Math.sin(a) * 1.2));
            fx(w, ParticleTypes.FLAME, pos.x + o.x, pos.y + o.y, pos.z + o.z, 1, 0, 0, 0, 0.0);
        }
    }

    // ---------- взрыв ----------
    private static void explode(Bolt b, Vec3d p) {
        ServerWorld w = b.w;
        BLASTS.add(new Blast(w, b.owner, p));
        if (DESTROY_TERRAIN) CRATERS.add(new Crater(w, BlockPos.ofFloored(p)));

        fx(w, ParticleTypes.FLASH, p.x, p.y, p.z, 8, 3, 3, 3, 0);
        fx(w, ParticleTypes.EXPLOSION_EMITTER, p.x, p.y, p.z, 8, 6, 4, 6, 0);
        fx(w, ParticleTypes.FLAME, p.x, p.y, p.z, 1500, 6, 6, 6, 0.6);
        fx(w, ParticleTypes.LAVA, p.x, p.y, p.z, 300, 8, 6, 8, 0);
        fx(w, ParticleTypes.LARGE_SMOKE, p.x, p.y, p.z, 400, 8, 6, 8, 0.15);
        w.playSound(null, BlockPos.ofFloored(p), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 10f, 0.5f);

        if (b.owner instanceof ServerPlayerEntity sp) {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeDouble(p.x); buf.writeDouble(p.y); buf.writeDouble(p.z);
            ServerPlayNetworking.send(sp, FxMod.IMPACT_PACKET, buf);
        }
    }

    // ---------- что происходит после взрыва ----------
    private static void blastTick(Blast bl) {
        ServerWorld w = bl.w;
        Vec3d p = bl.pos;
        int t = bl.t;
        double rNow = Math.min(RADIUS, t * WAVE_SPEED);
        double rPrev = Math.min(RADIUS, (t - 1) * WAVE_SPEED);

        if (t <= 30) waveDamage(bl, rNow);
        if (t <= 24) spiralWave(bl, rPrev, rNow);
        pillar(bl);
        spiralRain(bl);
        if (t >= 8 && t <= 72) outflow(bl);
        if (t % 10 == 0 && t <= 80) slow(bl);

        if (t >= 8 && t <= 120) {
            fx(w, ParticleTypes.FALLING_LAVA, p.x, p.y + 45, p.z, 70, 40, 20, 40, 0);
            fx(w, ParticleTypes.ASH, p.x, p.y + 25, p.z, 100, 45, 25, 45, 0.02);
        }
        if (t == 1) fx(w, ParticleTypes.FLASH, p.x, p.y + 2, p.z, 10, 4, 4, 4, 0);
        if (t == 5) w.playSound(null, BlockPos.ofFloored(p), SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, SoundCategory.PLAYERS, 10f, 0.4f);
        if (t == 12) w.playSound(null, BlockPos.ofFloored(p), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 10f, 0.5f);
        if (t == 25) w.playSound(null, BlockPos.ofFloored(p), SoundEvents.ENTITY_WITHER_DEATH, SoundCategory.PLAYERS, 6f, 0.5f);
    }

    /** Ударная волна накрывает существ по мере расширения до 48 блоков: 450 урона один раз. */
    private static void waveDamage(Blast bl, double rNow) {
        Vec3d p = bl.pos;
        Box area = new Box(p, p).expand(RADIUS, COLUMN_HEIGHT, RADIUS);
        for (Entity e : bl.w.getOtherEntities(bl.owner, area, en -> en instanceof LivingEntity && !bl.hit.contains(en.getUuid()))) {
            if (!targetable(e, bl.owner)) continue;
            double hd = Math.hypot(e.getX() - p.x, e.getZ() - p.z);
            if (hd > rNow) continue;
            bl.hit.add(e.getUuid());
            e.damage(bl.w.getDamageSources().indirectMagic(bl.owner, bl.owner), DAMAGE);
            e.setOnFireFor(15);
            Vec3d kb = new Vec3d(e.getX() - p.x, 0, e.getZ() - p.z).normalize().multiply(2.5).add(0, 1.0, 0);
            e.setVelocity(kb);
            e.velocityModified = true;
        }
    }

    /** Огненное «истечение»: толкает наружу, держит в огне, поджигает землю вокруг. */
    private static void outflow(Blast bl) {
        ServerWorld w = bl.w;
        Vec3d p = bl.pos;
        Box area = new Box(p, p).expand(RADIUS, COLUMN_HEIGHT, RADIUS);
        for (Entity e : w.getOtherEntities(bl.owner, area, en -> en instanceof LivingEntity)) {
            if (!targetable(e, bl.owner)) continue;
            double dx = e.getX() - p.x, dz = e.getZ() - p.z;
            double hd = Math.hypot(dx, dz);
            if (hd > RADIUS || hd < 1.0E-4) continue;
            e.setFireTicks(Math.max(e.getFireTicks(), 100));
            Vec3d v = e.getVelocity();
            e.setVelocity(v.add(dx / hd * 0.6, 0.15, dz / hd * 0.6));
            e.velocityModified = true;
        }
        for (int i = 0; i < 6; i++) {
            double a = RNG.nextDouble() * Math.PI * 2, d = RNG.nextDouble() * 30;
            int x = (int) Math.floor(p.x + Math.cos(a) * d), z = (int) Math.floor(p.z + Math.sin(a) * d);
            BlockPos probe = new BlockPos(x, (int) p.y, z);
            if (!w.isChunkLoaded(probe)) continue;
            int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z);
            BlockPos fp = new BlockPos(x, y, z);
            if (!w.getBlockState(fp).isAir()) continue;
            BlockState fs = AbstractFireBlock.getState(w, fp);
            if (fs.canPlaceAt(w, fp)) w.setBlockState(fp, fs, Block.NOTIFY_LISTENERS);
        }
    }

    /** Замедление всех живых существ в радиусе ~58 блоков. */
    private static void slow(Blast bl) {
        Vec3d p = bl.pos;
        Box area = new Box(p, p).expand(57.6, 96, 57.6);
        for (Entity e : bl.w.getOtherEntities(bl.owner, area, en -> en instanceof LivingEntity)) {
            if (!targetable(e, bl.owner)) continue;
            ((LivingEntity) e).addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 30, 3));
        }
    }

    /** Ударная волна из спиральных рукавов + плотный фронт. */
    private static void spiralWave(Blast bl, double r0, double r1) {
        ServerWorld w = bl.w;
        Vec3d p = bl.pos;
        int t = bl.t;
        int arms = 8;
        for (int k = 0; k < arms; k++) {
            for (double r = r0; r < r1; r += 0.35) {
                double a = r * 0.11 + k * (Math.PI * 2 / arms) + t * 0.25;
                double x = p.x + Math.cos(a) * r, z = p.z + Math.sin(a) * r;
                double tx = -Math.sin(a), tz = Math.cos(a);
                fxv(w, ParticleTypes.FLAME, x, p.y + 0.4, z, tx * 0.5, 0.45, tz * 0.5);
                fxv(w, ParticleTypes.FLAME, x, p.y + 1.5, z, tx * 0.4, 0.8, tz * 0.4);
                fxv(w, ParticleTypes.LARGE_SMOKE, x, p.y + 0.8, z, tx * 0.3, 0.3, tz * 0.3);
            }
        }
        int pts = (int) (r1 * 3) + 24;
        for (int i = 0; i < pts; i++) {
            double a = i * (Math.PI * 2 / pts) + t * 0.2;
            double x = p.x + Math.cos(a) * r1, z = p.z + Math.sin(a) * r1;
            fx(w, ParticleTypes.FLAME, x, p.y + 0.5, z, 3, 0.3, 0.8, 0.3, 0.1);
            if (i % 3 == 0) fx(w, ParticleTypes.LAVA, x, p.y + 0.6, z, 1, 0.3, 0.3, 0.3, 0);
        }
    }

    /** Сплошной столп огня до потолка мира (до 384 блоков) + шапка из дыма. */
    private static void pillar(Blast bl) {
        int t = bl.t;
        if (t > 160) return;
        ServerWorld w = bl.w;
        Vec3d p = bl.pos;
        double H = Math.max(60, Math.min(COLUMN_HEIGHT, w.getTopY() - p.y));
        double h = Math.min(H, t * 16.0);
        double fade = t > 80 ? Math.max(0.15, 1.0 - (t - 80) / 80.0) : 1.0;
        for (double y = 0; y <= h; y += 4) {
            double rad = 10 - 4 * (y / H);
            double sd = rad * 0.42;
            fx(w, ParticleTypes.FLAME, p.x, p.y + y, p.z, (int) (20 * DENSITY * fade), sd, 2.2, sd, 0.05);
            fx(w, ParticleTypes.LAVA, p.x, p.y + y, p.z, Math.max(1, (int) (3 * DENSITY * fade)), sd, 2.0, sd, 0);
            fx(w, ParticleTypes.LARGE_SMOKE, p.x, p.y + y, p.z, (int) (4 * DENSITY * fade), sd * 1.2, 2.0, sd * 1.2, 0.03);
        }
        if (t >= 12 && t <= 90) {
            double y = p.y + h;
            fx(w, ParticleTypes.LARGE_SMOKE, p.x, y, p.z, 60 * DENSITY, 22, 4, 22, 0.08);
            fx(w, ParticleTypes.FLAME, p.x, y, p.z, 40 * DENSITY, 16, 3, 16, 0.1);
        }
    }

    /** Частицы быстро падают вниз по спиралям. */
    private static void spiralRain(Blast bl) {
        int t = bl.t;
        if (t < 6 || t > 100) return;
        ServerWorld w = bl.w;
        Vec3d p = bl.pos;
        double top = Math.min(Math.min(COLUMN_HEIGHT, w.getTopY() - p.y), 16.0 * t);
        int strands = 7, samples = 16;
        for (int k = 0; k < strands; k++) {
            double rad = 5 + k * 6.5;
            for (int j = 0; j < samples; j++) {
                double hh = top * (j + (t % 3) / 3.0) / samples;
                double a = t * 0.45 - hh * 0.06 + k * 1.05;
                double x = p.x + Math.cos(a) * rad, z = p.z + Math.sin(a) * rad;
                double tx = -Math.sin(a), tz = Math.cos(a);
                fxv(w, ParticleTypes.FLAME, x, p.y + hh, z, tx * 0.9, -2.2, tz * 0.9);
                fxv(w, ParticleTypes.FLAME, x, p.y + hh, z, tx * 0.6, -2.6, tz * 0.6);
                if (j % 4 == 0) fxv(w, ParticleTypes.LAVA, x, p.y + hh, z, tx * 0.5, -1.8, tz * 0.5);
            }
        }
    }

    // ---------- разрушение террейна: кратер 48 м с магмой и обсидианом ----------
    private static int[] offsets() {
        if (OFFS != null) return OFFS;
        int R = (int) RADIUS;
        int side = 2 * R + 1;
        long[] tmp = new long[side * side * side];
        int n = 0;
        for (int dx = -R; dx <= R; dx++)
            for (int dy = -R; dy <= R; dy++)
                for (int dz = -R; dz <= R; dz++) {
                    int d2 = dx * dx + dy * dy + dz * dz;
                    if (d2 > R * R) continue;
                    tmp[n++] = ((long) d2 << 21) | ((long) (dx + R) << 14) | ((long) (dy + R) << 7) | (dz + R);
                }
        Arrays.sort(tmp, 0, n);
        int[] out = new int[n];
        for (int i = 0; i < n; i++) out[i] = (int) (tmp[i] & 0x1FFFFF);
        OFFS = out;
        return out;
    }

    private static boolean carveTick(Crater c) {
        int[] offs = offsets();
        int R = (int) RADIUS;
        double inner = R - 1.6;
        ServerWorld w = c.w;
        long deadline = System.nanoTime() + CARVE_BUDGET_NS;
        BlockPos.Mutable m = new BlockPos.Mutable();
        int done = 0;
        while (c.idx < offs.length && done < CARVE_MAX_PER_TICK) {
            if ((done & 63) == 0 && System.nanoTime() > deadline) break;
            int o = offs[c.idx++];
            done++;
            int dx = ((o >> 14) & 127) - R, dy = ((o >> 7) & 127) - R, dz = (o & 127) - R;
            m.set(c.cx + dx, c.cy + dy, c.cz + dz);
            if (m.getY() < w.getBottomY() || m.getY() >= w.getTopY()) continue;
            if (!w.isChunkLoaded(m)) continue;
            BlockState st = w.getBlockState(m);
            if (st.isAir()) continue;
            if (st.getHardness(w, m) < 0) continue;
            BlockState ns = Blocks.AIR.getDefaultState();
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dy <= 0 && d >= inner) {
                int h = ((dx * 73856093) ^ (dy * 19349663) ^ (dz * 83492791)) & 255;
                ns = h < 85 ? Blocks.MAGMA_BLOCK.getDefaultState()
                        : h < 100 ? Blocks.CRYING_OBSIDIAN.getDefaultState()
                        : Blocks.OBSIDIAN.getDefaultState();
            }
            w.setBlockState(m, ns, Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
        }
        return c.idx >= offs.length;
    }

    /** После кратера: чёрные шипы (спайры) вокруг края. */
    private static void spires(Crater c) {
        ServerWorld w = c.w;
        Random r = new Random(c.cx * 31L + c.cz);
        for (int i = 0; i < 12; i++) {
            double a = r.nextDouble() * Math.PI * 2, d = 30 + r.nextDouble() * 16;
            int x = c.cx + (int) (Math.cos(a) * d), z = c.cz + (int) (Math.sin(a) * d);
            if (!w.isChunkLoaded(new BlockPos(x, c.cy, z))) continue;
            int top = w.getTopY(Heightmap.Type.WORLD_SURFACE, x, z);
            int h = 10 + r.nextInt(18), rad = 1 + r.nextInt(2);
            for (int dy = 0; dy <= h; dy++) {
                double rr = rad * (1 - dy / (double) h) + 0.6;
                for (int dx = -rad; dx <= rad; dx++)
                    for (int dz = -rad; dz <= rad; dz++) {
                        if (dx * dx + dz * dz > rr * rr) continue;
                        BlockPos bp = new BlockPos(x + dx, top + dy, z + dz);
                        if (bp.getY() >= w.getTopY() || !w.getBlockState(bp).isAir()) continue;
                        BlockState bs = dy > h - 3 ? Blocks.MAGMA_BLOCK.getDefaultState()
                                : r.nextInt(5) == 0 ? Blocks.OBSIDIAN.getDefaultState() : Blocks.BLACKSTONE.getDefaultState();
                        w.setBlockState(bp, bs, Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
                    }
            }
        }
    }

    private FugaFx() {}
}
