package com.example.fxmod;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/** Клавиша G: удар ногой по земле, затем волна шипов из незерака и магмы (50 x 10 блоков, высота до 40). */
public final class Spikes {
    // ================= НАСТРОЙКИ =================
    public static final double LENGTH = 50.0;     // длина зоны шипов
    public static final double WIDTH = 10.0;      // ширина зоны
    public static final int MAX_HEIGHT = 40;      // макс. высота шипов
    public static final double LEAN_DEG = 10.0;   // наклон шипов ОТ игрока (от вертикали); больше = сильнее наклон
    public static final float DAMAGE = 50f;
    public static final int FIRE_SECONDS = 20;    // сколько горит враг
    public static final int COOLDOWN = 160;       // перезарядка в тиках (160 = 8 сек)
    private static final int STOMP_TICKS = 10;    // замах до удара ногой
    private static final double WAVE_SPEED = 3.0; // скорость волны, блоков/тик
    private static final int GROW_TICKS = 7;      // за сколько тиков вырастает шип
    private static final int LIFETIME = 220;      // через сколько тиков шипы рассыпаются
    private static final boolean KEEP_SPIKES = false; // true = шипы остаются навсегда
    // =============================================

    private static final List<Ability> ACTIVE = new ArrayList<>();
    private static final Map<UUID, Integer> LAST = new HashMap<>();
    private static int now = 0;

    private static final class Spike {
        double s, lat, h, r0, bx, bz; int by, delay, built = 0; boolean started, dead;
        final List<List<BlockPos>> levels = new ArrayList<>();
    }

    private static final class Ability {
        final ServerWorld w; final ServerPlayerEntity owner; final Vec3d origin, fwd, right;
        final List<Spike> spikes = new ArrayList<>(); final Set<UUID> hit = new HashSet<>();
        int t = 0; boolean retract;
        Ability(ServerWorld w, ServerPlayerEntity owner, Vec3d origin, Vec3d fwd) {
            this.w = w; this.owner = owner; this.origin = origin; this.fwd = fwd; this.right = new Vec3d(-fwd.z, 0, fwd.x);
        }
    }

    private static void fx(ServerWorld w, ParticleEffect e, double x, double y, double z, int n, double dx, double dy, double dz, double sp) {
        for (ServerPlayerEntity pl : w.getPlayers()) w.spawnParticles(pl, e, true, x, y, z, n, dx, dy, dz, sp);
    }

    private static void fxv(ServerWorld w, ParticleEffect e, double x, double y, double z, double vx, double vy, double vz) {
        for (ServerPlayerEntity pl : w.getPlayers()) w.spawnParticles(pl, e, true, x, y, z, 0, vx, vy, vz, 1.0);
    }

    private static int hash(int x, int y, int z) { return ((x * 73856093) ^ (y * 19349663) ^ (z * 83492791)) & 0x7fffffff; }

    // ---------- запуск ----------
    public static void start(ServerPlayerEntity p) {
        if (p.isUsingItem() || !p.isAlive() || p.isSpectator()) return;
        Integer last = LAST.get(p.getUuid());
        if (last != null && now - last < COOLDOWN) {
            p.sendMessage(Text.literal("Шипы перезаряжаются: " + ((COOLDOWN - (now - last)) / 20 + 1) + " с"), true);
            return;
        }
        LAST.put(p.getUuid(), now);

        ServerWorld w = p.getServerWorld();
        Vec3d look = p.getRotationVec(1f);
        Vec3d fwd = new Vec3d(look.x, 0, look.z);
        if (fwd.lengthSquared() < 1.0E-4) {
            double yaw = Math.toRadians(p.getYaw());
            fwd = new Vec3d(-Math.sin(yaw), 0, Math.cos(yaw));
        }
        fwd = fwd.normalize();
        Ability a = new Ability(w, p, p.getPos(), fwd);
        layout(a, new Random(p.getId() * 31L + now));
        ACTIVE.add(a);

        // анимацию удара ногой видят все рядом; владелец получает ещё и кинокамеру
        for (ServerPlayerEntity pl : w.getPlayers()) {
            if (pl.squaredDistanceTo(p) > 160 * 160) continue;
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeInt(p.getId());
            buf.writeDouble(a.origin.x); buf.writeDouble(a.origin.y); buf.writeDouble(a.origin.z);
            buf.writeDouble(fwd.x); buf.writeDouble(fwd.z);
            ServerPlayNetworking.send(pl, FxMod.STOMP_PACKET, buf);
        }
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_BLAZE_AMBIENT, SoundCategory.PLAYERS, 2f, 0.5f);
    }

    /** Раскладка шипов: ряды вдоль зоны, высота растёт к середине. */
    private static void layout(Ability a, Random r) {
        double[] slots = {-4.0, -1.35, 1.35, 4.0};
        for (double s = 4.0; s <= LENGTH; s += 2.6) {
            double prof = Math.sin(Math.PI * (s - 4) / (LENGTH - 4)); // 0 → 1 → 0
            for (double slot : slots) {
                if (r.nextDouble() > 0.82) continue;
                Spike sp = new Spike();
                sp.s = s + (r.nextDouble() - 0.5) * 1.2;
                sp.lat = Math.max(-WIDTH / 2, Math.min(WIDTH / 2, slot + (r.nextDouble() - 0.5) * 1.2));
                double latF = 1 - 0.25 * Math.abs(sp.lat) / (WIDTH / 2);
                double h = (10 + 30 * Math.pow(prof, 0.8)) * (0.78 + 0.22 * r.nextDouble()) * latF;
                if (Math.abs(sp.lat) < 2 && prof > 0.9) h = MAX_HEIGHT; // «король» зоны
                sp.h = Math.min(MAX_HEIGHT, Math.max(8, h));
                sp.r0 = 1.4 + sp.h * 0.045;
                sp.delay = STOMP_TICKS + (int) (sp.s / WAVE_SPEED) + r.nextInt(3);
                a.spikes.add(sp);
            }
        }
    }

    // ---------- главный тик ----------
    public static void tick() {
        now++;
        Iterator<Ability> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Ability a = it.next();
            a.t++;
            if (tickAbility(a)) it.remove();
        }
    }

    private static boolean tickAbility(Ability a) {
        if (a.t <= STOMP_TICKS) windup(a);
        if (a.t >= STOMP_TICKS && a.t <= STOMP_TICKS + 8) impactRing(a);
        if (a.t >= STOMP_TICKS && a.t <= STOMP_TICKS + 20) cracks(a);

        int idx = 0;
        for (Spike sp : a.spikes) {
            idx++;
            int age = a.t - sp.delay;
            if (age < 0 || sp.dead) continue;
            if (!sp.started) {
                sp.started = true;
                if (!startSpike(a, sp, idx)) { sp.dead = true; continue; }
            }
            if (!a.retract && sp.built < (int) Math.ceil(sp.h)) {
                double g = Math.min(1.0, age / (double) GROW_TICKS);
                int target = (int) Math.ceil(sp.h * (1 - (1 - g) * (1 - g)));
                build(a, sp, target);
            }
        }

        if (a.t >= STOMP_TICKS && a.t <= 75) waveDamage(a);

        if (!KEEP_SPIKES && a.t >= LIFETIME) {
            a.retract = true;
            return retractTick(a);
        }
        return KEEP_SPIKES && a.t > 120;
    }

    // ---------- замах и удар ногой ----------
    private static void windup(Ability a) {
        ServerWorld w = a.w;
        Vec3d foot = a.origin.add(a.fwd.multiply(0.5)).add(a.right.multiply(0.25));
        double k = a.t / (double) STOMP_TICKS;
        double rad = 3.5 * (1 - k) + 0.5;
        for (int i = 0; i < 16; i++) {
            double ang = i * Math.PI * 2 / 16 + a.t * 0.5;
            double x = foot.x + Math.cos(ang) * rad, z = foot.z + Math.sin(ang) * rad;
            fxv(w, ParticleTypes.FLAME, x, foot.y + 0.1, z, (foot.x - x) * 0.12, 0.05, (foot.z - z) * 0.12);
        }
        fx(w, ParticleTypes.FLAME, foot.x, foot.y + 0.2, foot.z, 6, 0.3, 0.4, 0.3, 0.04);
        fx(w, ParticleTypes.LAVA, foot.x, foot.y + 0.2, foot.z, 1, 0.5, 0.1, 0.5, 0);
        if (a.t == STOMP_TICKS)
            a.w.playSound(null, BlockPos.ofFloored(foot), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 3f, 0.5f);
        if (a.t == STOMP_TICKS)
            a.w.playSound(null, BlockPos.ofFloored(foot), SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.PLAYERS, 1.5f, 0.5f);
    }

    /** Кольцо ударной волны от места удара ногой. */
    private static void impactRing(Ability a) {
        ServerWorld w = a.w;
        Vec3d foot = a.origin.add(a.fwd.multiply(0.5)).add(a.right.multiply(0.25));
        double r = (a.t - STOMP_TICKS) * 1.8 + 1.0;
        int pts = (int) (r * 7) + 14;
        for (int i = 0; i < pts; i++) {
            double ang = i * Math.PI * 2 / pts;
            double x = foot.x + Math.cos(ang) * r, z = foot.z + Math.sin(ang) * r;
            fxv(w, ParticleTypes.FLAME, x, foot.y + 0.2, z, Math.cos(ang) * 0.25, 0.35, Math.sin(ang) * 0.25);
            if (i % 3 == 0) fx(w, ParticleTypes.LARGE_SMOKE, x, foot.y + 0.3, z, 1, 0.1, 0.1, 0.1, 0.02);
        }
        if (a.t == STOMP_TICKS) fx(w, ParticleTypes.EXPLOSION_EMITTER, foot.x, foot.y + 0.3, foot.z, 1, 0, 0, 0, 0);
    }

    /** Огненные трещины бегут по земле впереди волны шипов. */
    private static void cracks(Ability a) {
        ServerWorld w = a.w;
        double s1 = Math.min(LENGTH, (a.t - STOMP_TICKS + 1) * WAVE_SPEED + 6);
        double s0 = Math.max(1, s1 - WAVE_SPEED - 2);
        Random r = new Random(a.t);
        for (double s = s0; s < s1; s += 0.6) {
            for (int k = -2; k <= 2; k++) {
                double lat = k * 2.2 + (r.nextDouble() - 0.5) * 1.5;
                if (Math.abs(lat) > WIDTH / 2 + 1) continue;
                double x = a.origin.x + a.fwd.x * s + a.right.x * lat;
                double z = a.origin.z + a.fwd.z * s + a.right.z * lat;
                fx(w, ParticleTypes.LAVA, x, a.origin.y + 0.2, z, 1, 0.15, 0.05, 0.15, 0);
                fxv(w, ParticleTypes.FLAME, x, a.origin.y + 0.2, z, 0, 0.12, 0);
            }
        }
    }

    // ---------- рост шипа ----------
    private static boolean startSpike(Ability a, Spike sp, int idx) {
        ServerWorld w = a.w;
        sp.bx = a.origin.x + a.fwd.x * sp.s + a.right.x * sp.lat;
        sp.bz = a.origin.z + a.fwd.z * sp.s + a.right.z * sp.lat;
        int x = (int) Math.floor(sp.bx), z = (int) Math.floor(sp.bz);
        if (!w.isChunkLoaded(new BlockPos(x, (int) a.origin.y, z))) return false;
        int gy = findGround(w, x, (int) Math.floor(a.origin.y), z);
        if (gy < 0) return false;
        sp.by = gy;
        fx(w, ParticleTypes.LAVA, sp.bx, gy + 0.4, sp.bz, 8, sp.r0 * 0.6, 0.2, sp.r0 * 0.6, 0);
        fx(w, ParticleTypes.FLAME, sp.bx, gy + 0.4, sp.bz, 40, sp.r0 * 0.7, 0.3, sp.r0 * 0.7, 0.12);
        fx(w, ParticleTypes.LARGE_SMOKE, sp.bx, gy + 0.6, sp.bz, 12, sp.r0 * 0.7, 0.3, sp.r0 * 0.7, 0.05);
        BlockPos bp = new BlockPos(x, gy, z);
        if (idx % 4 == 0) w.playSound(null, bp, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.6f, 0.7f + (idx % 7) * 0.05f);
        else w.playSound(null, bp, SoundEvents.BLOCK_NETHERRACK_BREAK, SoundCategory.PLAYERS, 2.0f, 0.5f);
        return true;
    }

    /** Первая «воздушная» клетка над землёй рядом с высотой игрока, либо -1. */
    private static int findGround(ServerWorld w, int x, int y0, int z) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        int top = Math.min(w.getTopY() - 2, y0 + 3), bottom = Math.max(w.getBottomY() + 1, y0 - 20);
        for (int y = top; y >= bottom; y--) {
            BlockState above = w.getBlockState(m.set(x, y, z));
            if (!(above.isAir() || above.isReplaceable())) continue;
            BlockState below = w.getBlockState(m.set(x, y - 1, z));
            if (!(below.isAir() || below.isReplaceable())) return y;
        }
        return -1;
    }

    private static void build(Ability a, Spike sp, int target) {
        ServerWorld w = a.w;
        double lean = Math.tan(Math.toRadians(LEAN_DEG));
        for (int level = sp.built; level < target; level++) {
            double cx = sp.bx + a.fwd.x * level * lean, cz = sp.bz + a.fwd.z * level * lean;
            double frac = level / sp.h;
            double rr = Math.max(0.55, sp.r0 * Math.pow(1 - frac, 0.85));
            int ci = (int) Math.floor(cx), ck = (int) Math.floor(cz), R = (int) Math.ceil(rr) + 1;
            List<BlockPos> lv = new ArrayList<>();
            for (int dx = -R; dx <= R; dx++)
                for (int dz = -R; dz <= R; dz++) {
                    double ex = ci + dx + 0.5 - cx, ez = ck + dz + 0.5 - cz;
                    double d2 = ex * ex + ez * ez;
                    int hs = hash(ci + dx, level, ck + dz);
                    double lim = rr + ((hs & 7) - 3) * 0.06;
                    if (d2 > lim * lim) continue;
                    BlockPos bp = new BlockPos(ci + dx, sp.by + level, ck + dz);
                    if (bp.getY() >= w.getTopY() || !w.isChunkLoaded(bp)) continue;
                    BlockState cur = w.getBlockState(bp);
                    if (!(cur.isAir() || cur.isReplaceable())) continue;
                    double core = Math.sqrt(d2) / Math.max(rr, 0.01);
                    int pct = (hs >> 3) % 100;
                    BlockState ns;
                    if (frac > 0.8) ns = Blocks.MAGMA_BLOCK.getDefaultState();
                    else if (core < 0.5) ns = pct < 55 ? Blocks.MAGMA_BLOCK.getDefaultState() : Blocks.NETHERRACK.getDefaultState();
                    else ns = pct < 10 ? Blocks.MAGMA_BLOCK.getDefaultState() : Blocks.NETHERRACK.getDefaultState();
                    w.setBlockState(bp, ns, Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
                    lv.add(bp);
                }
            sp.levels.add(lv);
            if (level == target - 1) {
                fx(w, ParticleTypes.FLAME, cx, sp.by + level + 0.5, cz, 6, rr * 0.5, 0.3, rr * 0.5, 0.05);
                if (level % 3 == 0) fx(w, ParticleTypes.LAVA, cx, sp.by + level + 0.5, cz, 1, rr * 0.5, 0.2, rr * 0.5, 0);
            }
        }
        sp.built = target;
    }

    // ---------- урон ----------
    private static void waveDamage(Ability a) {
        ServerWorld w = a.w;
        double waveS = (a.t - STOMP_TICKS) * WAVE_SPEED + 2;
        Vec3d o = a.origin;
        Vec3d e1 = o.add(a.fwd.multiply(LENGTH + 4)).add(a.right.multiply(WIDTH / 2 + 3));
        Vec3d e2 = o.add(a.fwd.multiply(LENGTH + 4)).subtract(a.right.multiply(WIDTH / 2 + 3));
        Vec3d e3 = o.add(a.right.multiply(WIDTH / 2 + 3)), e4 = o.subtract(a.right.multiply(WIDTH / 2 + 3));
        Box box = new Box(Math.min(Math.min(e1.x, e2.x), Math.min(e3.x, e4.x)), o.y - 6, Math.min(Math.min(e1.z, e2.z), Math.min(e3.z, e4.z)),
                Math.max(Math.max(e1.x, e2.x), Math.max(e3.x, e4.x)), o.y + MAX_HEIGHT + 6, Math.max(Math.max(e1.z, e2.z), Math.max(e3.z, e4.z)));
        for (Entity e : w.getOtherEntities(a.owner, box, en -> en instanceof LivingEntity && !a.hit.contains(en.getUuid()))) {
            if (!e.isAlive() || (e instanceof PlayerEntity pl && (pl.isCreative() || pl.isSpectator()))) continue;
            Vec3d rel = e.getPos().subtract(o);
            double s = rel.dotProduct(a.fwd), lat = rel.dotProduct(a.right);
            if (s < 0 || s > LENGTH + 3 || Math.abs(lat) > WIDTH / 2 + 2 || s > waveS) continue;
            a.hit.add(e.getUuid());
            e.damage(w.getDamageSources().indirectMagic(a.owner, a.owner), DAMAGE);
            e.setOnFireFor(FIRE_SECONDS);
            e.setVelocity(a.fwd.x * 0.5 + a.right.x * (Math.random() - 0.5) * 0.8, 1.5, a.fwd.z * 0.5 + a.right.z * (Math.random() - 0.5) * 0.8);
            e.velocityModified = true;
            fx(w, ParticleTypes.FLAME, e.getX(), e.getY() + 1, e.getZ(), 40, 0.5, 0.8, 0.5, 0.15);
            fx(w, ParticleTypes.LAVA, e.getX(), e.getY() + 1, e.getZ(), 10, 0.5, 0.8, 0.5, 0);
        }
    }

    // ---------- шипы рассыпаются ----------
    private static boolean retractTick(Ability a) {
        ServerWorld w = a.w;
        boolean done = true;
        for (Spike sp : a.spikes) {
            if (sp.dead || sp.levels.isEmpty()) continue;
            for (int i = 0; i < 6 && !sp.levels.isEmpty(); i++) {
                List<BlockPos> lv = sp.levels.remove(sp.levels.size() - 1);
                for (BlockPos bp : lv) {
                    if (!w.isChunkLoaded(bp)) continue;
                    BlockState st = w.getBlockState(bp);
                    if (st.isOf(Blocks.NETHERRACK) || st.isOf(Blocks.MAGMA_BLOCK))
                        w.setBlockState(bp, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
                }
                if (i == 0 && !lv.isEmpty() && (sp.levels.size() % 4 == 0)) {
                    BlockPos q = lv.get(0);
                    fx(w, ParticleTypes.LARGE_SMOKE, q.getX() + 0.5, q.getY() + 0.5, q.getZ() + 0.5, 4, 0.6, 0.4, 0.6, 0.03);
                    fx(w, ParticleTypes.FLAME, q.getX() + 0.5, q.getY() + 0.5, q.getZ() + 0.5, 6, 0.6, 0.4, 0.6, 0.05);
                }
            }
            if (!sp.levels.isEmpty()) done = false;
        }
        return done;
    }

    private Spikes() {}
}
