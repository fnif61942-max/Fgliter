package com.example.fxmod.wish;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Разбор текста желания в список действий. Чистая Java (без Minecraft), чтобы её можно было тестировать отдельно.
 * Названия предметов/блоков/мобов приходят из словаря (Lexicon): локализованные названия игры + английские + свои синонимы.
 * Глаголы понимаются на русском и английском.
 */
public final class WishText {

    // ---------------- данные ----------------
    /** kind: B блок, I предмет, E моб, F эффект, C категория мобов, G группа блоков. */
    public static final class Entry {
        public final char kind; public final String id;
        public Entry(char kind, String id) { this.kind = kind; this.id = id; }
    }

    /** type: BLOCKS(a=из, b=во), SUMMON(a=id,n), KILL(a=цель,n=режим 0 убить/1 исчезнуть/2 поджечь), TRANSFORM(a=цель,b=id),
     *  GIVE(a=id,n), TIME(a), WEATHER(a), HEAL, GOD, FLY, EFFECT(a=id,n=секунды). */
    public static final class Action {
        public final String type, a, b; public final int n;
        public Action(String type, String a, String b, int n) { this.type = type; this.a = a; this.b = b; this.n = n; }
        @Override public String toString() { return type + "[" + a + (b.isEmpty() ? "" : " -> " + b) + (n != 0 ? " n=" + n : "") + "]"; }
    }

    public static final class Result {
        public final List<Action> actions = new ArrayList<>();
        public final List<String> unknown = new ArrayList<>();
    }

    private static final class Name {
        final String[] words, stems; final boolean alias; final int chars;
        final List<Entry> entries = new ArrayList<>();
        Name(String phrase, boolean alias) {
            this.words = phrase.split(" ");
            this.stems = new String[words.length];
            int c = 0;
            for (int i = 0; i < words.length; i++) { stems[i] = stem(words[i]); c += words[i].length(); }
            this.chars = c; this.alias = alias;
        }
    }

    public static final class Lexicon {
        private final Map<String, Name> map = new HashMap<>();
        public void add(String phrase, char kind, String id, boolean alias) {
            String key = normalize(phrase);
            if (key.length() < 3) return;
            Name n = map.computeIfAbsent(key + (alias ? "#a" : "#n"), k -> new Name(key, alias));
            n.entries.add(new Entry(kind, id));
        }
        /** Несколько синонимов через «|». */
        public void aliases(String phrases, char kind, String id) { for (String p : phrases.split("\\|")) add(p, kind, id, true); }
        int size() { return map.size(); }
    }

    // ---------------- нормализация ----------------
    public static String normalize(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toLowerCase(Locale.ROOT).toCharArray()) {
            if (c == '\u0451') c = '\u0435';            // ё -> е
            b.append(Character.isLetterOrDigit(c) ? c : ' ');
        }
        return b.toString().trim().replaceAll("\\s+", " ");
    }

    /** Основа слова: отрезаем последнюю букву у длинных слов (русские окончания). */
    private static String stem(String w) { return w.length() >= 5 ? w.substring(0, w.length() - 1) : w; }

    // ---------------- словари глаголов ----------------
    private static final Set<String> SEP = new HashSet<>(Arrays.asList("и", "а", "потом", "затем", "также", "еще", "and", "then", "also", "plus"));
    private static final String[] REP = {"превра", "замен", "измен", "перекрас", "turn", "replac", "chang", "convert", "transform", "swap"};
    private static final String[] REM = {"удал", "убер", "убр", "стер", "сотр", "исчез", "очист", "пропа", "сгин", "remov", "delet", "eras", "clear", "vanish", "wipe", "disappear", "dispel"};
    private static final String[] KILL = {"убей", "убит", "убив", "убь", "уничтож", "истреб", "порази", "казни", "смерт", "kill", "slay", "destroy", "murder", "exterm", "annihil", "smite", "elimin", "execut", "slaughter"};
    private static final String[] SUMMON = {"призов", "призыв", "созда", "спавн", "заспавн", "появ", "вызов", "породи", "сотвор", "добав", "spawn", "summon", "creat", "conjur", "add", "bring", "call"};
    private static final String[] GIVE = {"дай", "выдай", "подар", "хочу", "нужн", "хотел", "give", "gimme", "want", "need", "get"};
    private static final String[] IGN = {"подожг", "поджиг", "поджеч", "поджег", "сожг", "сжеч", "сжег", "зажг", "зажеч", "ignit", "burn", "torch"};
    private static final String[] RAIN = {"дожд", "ливн", "rain", "shower", "drizzl"};
    private static final String[] THUNDER = {"гроз", "шторм", "бур", "thunder", "storm"};
    private static final String[] CLEARW = {"ясн", "солнечн", "sunny", "sunshine"};
    private static final String[] STOPW = {"останов", "прекрат", "убер", "убр", "удал", "отмен", "stop", "cancel", "end", "remov", "delet", "clear", "disable"};
    private static final String[] HEAL = {"вылеч", "исцел", "излеч", "здоров", "heal", "cure", "накорм", "feed"};
    private static final String[] GOD = {"бессмерт", "неуязвим", "immortal", "invincib", "godmode"};
    private static final Set<String> FLY = new HashSet<>(Arrays.asList("летать", "летай", "лететь", "полет", "fly", "flying", "flight"));
    private static final Set<String> CONNECT = new HashSet<>(Arrays.asList("в", "во", "на", "into", "to", "with", "like"));
    private static final Map<String, String> TIME = new HashMap<>();
    private static final Map<String, Integer> NUMS = new HashMap<>();
    static {
        for (String s : "день|днем|day|daytime".split("\\|")) TIME.put(s, "day");
        for (String s : "утро|утром|утра|рассвет|morning|sunrise|dawn".split("\\|")) TIME.put(s, "sunrise");
        for (String s : "полдень|noon|midday".split("\\|")) TIME.put(s, "noon");
        for (String s : "закат|вечер|вечером|sunset|evening|dusk".split("\\|")) TIME.put(s, "sunset");
        for (String s : "ночь|ночью|ночи|night|nighttime".split("\\|")) TIME.put(s, "night");
        for (String s : "полночь|midnight".split("\\|")) TIME.put(s, "midnight");
        String[] ru = {"один", "одну", "одного", "одна", "два", "две", "двух", "три", "трех", "четыре", "пять", "шесть", "семь", "восемь", "девять", "десять", "двадцать", "тридцать", "сорок", "пятьдесят", "сто", "тысячу", "тысяча"};
        int[] rv = {1, 1, 1, 1, 2, 2, 2, 3, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 40, 50, 100, 1000, 1000};
        for (int i = 0; i < ru.length; i++) NUMS.put(ru[i], rv[i]);
        String[] en = {"one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "twenty", "thirty", "fifty", "hundred", "thousand", "a"};
        int[] ev = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 50, 100, 1000, 1};
        for (int i = 0; i < en.length; i++) NUMS.put(en[i], ev[i]);
    }

    private static boolean starts(String t, String[] stems) { for (String s : stems) if (t.startsWith(s)) return true; return false; }

    // ---------------- поиск названий ----------------
    private static final class Match {
        final int start, end, score; final Name name;
        Match(int s, int e, Name n, int score) { start = s; end = e; name = n; this.score = score; }
        List<Entry> pick(String kinds) {
            List<Entry> r = new ArrayList<>();
            for (Entry e : name.entries) if (kinds.indexOf(e.kind) >= 0) r.add(e);
            return r;
        }
        boolean has(String kinds) { return !pick(kinds).isEmpty(); }
    }

    private static List<Match> findMatches(String[] toks, Lexicon lex) {
        List<Match> all = new ArrayList<>();
        for (Name nm : lex.map.values()) {
            int L = nm.words.length;
            for (int i = 0; i + L <= toks.length; i++) {
                int exact = 0; boolean ok = true;
                for (int j = 0; j < L; j++) {
                    String t = toks[i + j], w = nm.words[j];
                    if (t.equals(w)) exact++;
                    else if (!(t.startsWith(nm.stems[j]) && t.length() <= w.length() + 4)) { ok = false; break; }
                }
                if (ok) all.add(new Match(i, i + L, nm, L * 1000 + exact * 300 + nm.chars + (nm.alias ? 200 : 0)));
            }
        }
        all.sort(Comparator.comparingInt((Match m) -> -m.score).thenComparingInt(m -> m.start));
        boolean[] used = new boolean[toks.length];
        List<Match> out = new ArrayList<>();
        for (Match m : all) {
            boolean free = true;
            for (int i = m.start; i < m.end; i++) if (used[i]) { free = false; break; }
            if (!free) continue;
            for (int i = m.start; i < m.end; i++) used[i] = true;
            out.add(m);
        }
        out.sort(Comparator.comparingInt(m -> m.start));
        return out;
    }

    private static int numberNear(String[] toks, int start) {
        for (int k = start - 1; k >= Math.max(0, start - 2); k--) {
            Integer v = numeric(toks[k]);
            if (v != null) return stackMult(toks, v);
        }
        for (String t : toks) { Integer v = numeric(t); if (v != null && !t.equals("a")) return stackMult(toks, v); }
        return stackMult(toks, 1) == 64 ? 64 : 1;
    }
    private static Integer numeric(String t) {
        if (t.matches("\\d{1,6}")) return Integer.parseInt(t);
        return NUMS.get(t);
    }
    private static int stackMult(String[] toks, int v) {
        for (String t : toks) if (t.startsWith("стак") || t.startsWith("stack")) return v * 64;
        return v;
    }

    // ---------------- главный разбор ----------------
    public static Result parse(String text, Lexicon lex) {
        Result res = new Result();
        List<String[]> clauses = new ArrayList<>();
        for (String part : text.split("[,;.!?\\n]+")) {
            String n = normalize(part);
            if (n.isEmpty()) continue;
            List<String> cur = new ArrayList<>();
            for (String t : n.split(" ")) {
                if (SEP.contains(t)) { if (!cur.isEmpty()) { clauses.add(cur.toArray(new String[0])); cur = new ArrayList<>(); } }
                else cur.add(t);
            }
            if (!cur.isEmpty()) clauses.add(cur.toArray(new String[0]));
        }
        boolean[] carry = new boolean[5]; // rem, kill, ign, summon, give — глагол «наследуется» следующей фразой
        for (String[] toks : clauses) {
            if (res.actions.size() >= 12) break;
            int before = res.actions.size();
            boolean[] c2 = clause(toks, lex, res, carry);
            if (res.actions.size() == before) res.unknown.add(String.join(" ", toks));
            else carry = c2;
        }
        return res;
    }

    /** Возвращает флаги глаголов этой фразы (для наследования). */
    private static boolean[] clause(String[] toks, Lexicon lex, Result res, boolean[] carry) {
        boolean rep = false, rem = false, kill = false, ign = false, summon = false, give = false;
        boolean rain = false, thunder = false, clearW = false, stopW = false, heal = false, god = false, fly = false;
        String time = null;
        for (String t : toks) {
            if (starts(t, REP)) rep = true;
            if (starts(t, REM)) rem = true;
            if (starts(t, KILL)) kill = true;
            if (starts(t, SUMMON)) summon = true;
            if (starts(t, GIVE)) give = true;
            if (starts(t, IGN)) ign = true;
            if (starts(t, RAIN)) rain = true;
            if (starts(t, THUNDER)) thunder = true;
            if (starts(t, CLEARW)) clearW = true;
            if (starts(t, STOPW)) stopW = true;
            if (starts(t, HEAL)) heal = true;
            if (starts(t, GOD)) god = true;
            if (FLY.contains(t)) fly = true;
            if (TIME.containsKey(t)) time = TIME.get(t);
        }
        boolean anyVerb = rep || rem || kill || ign || summon || give;
        if (!anyVerb) { rem = carry[0]; kill = carry[1]; ign = carry[2]; summon = carry[3]; give = carry[4]; }
        boolean[] flags = {rem, kill, ign, summon, give};

        List<Match> ms = findMatches(toks, lex);
        boolean hasObj = false;
        for (Match m : ms) if (m.has("BIEGC")) hasObj = true;

        // --- особые желания без предметов ---
        if (!hasObj) {
            boolean did = false;
            if (rain || thunder) { res.actions.add(new Action("WEATHER", stopW ? "clear" : thunder ? "thunder" : "rain", "", 0)); did = true; }
            else if (clearW) { res.actions.add(new Action("WEATHER", "clear", "", 0)); did = true; }
            if (time != null) { res.actions.add(new Action("TIME", time, "", 0)); did = true; }
            if (heal) { res.actions.add(new Action("HEAL", "", "", 0)); did = true; }
            if (god) { res.actions.add(new Action("GOD", "", "", 0)); did = true; }
            if (fly) { res.actions.add(new Action("FLY", "", "", 0)); did = true; }
            boolean eff = false;
            for (Match m : ms) if (m.has("F")) {
                for (Entry e : m.pick("F")) { res.actions.add(new Action("EFFECT", e.id, "1", 600)); eff = true; }
            }
            if (did || eff) return flags;
        }

        // --- замена «X на Y» ---
        if (rep) {
            int conn = -1;
            for (int i = 0; i < toks.length; i++) if (CONNECT.contains(toks[i])) { boolean after = false; for (Match m : ms) if (m.end <= i) after = true; if (after) { conn = i; break; } }
            List<Match> src = new ArrayList<>(); Match dst = null;
            for (Match m : ms) { if (conn >= 0 && m.start > conn) { if (dst == null) dst = m; } else src.add(m); }
            if (conn >= 0 && dst != null && !src.isEmpty()) {
                // существо -> существо
                if (src.get(0).has("EC") && dst.has("E")) {
                    for (Match s : src) for (Entry e : s.pick("EC")) res.actions.add(new Action("TRANSFORM", spec(e), dst.pick("E").get(0).id, 0));
                    return flags;
                }
                List<Entry> to = dst.pick("B");
                if (to.isEmpty()) to = dst.pick("I");
                if (to.isEmpty()) for (Entry g : dst.pick("G")) { String t = Groups.target(g.id); if (t != null) to.add(new Entry('B', t)); }
                if (!to.isEmpty()) {
                    Set<String> from = new java.util.LinkedHashSet<>();
                    for (Match s : src) {
                        for (Entry e : s.pick("G")) for (String[] r : Groups.rules(e.id)) from.addAll(Arrays.asList(r[0].split(",")));
                        for (Entry e : s.pick("B")) from.add(e.id);
                        if (!s.has("BG")) for (Entry e : s.pick("I")) from.add(e.id);
                    }
                    if (!from.isEmpty()) { res.actions.add(new Action("BLOCKS", String.join(",", from), to.get(0).id, 0)); return flags; }
                }
            }
            return flags; // не поняли замену
        }

        // --- удалить / убить / поджечь ---
        if (rem || kill || ign) {
            boolean did = false;
            for (Match m : ms) {
                if (m.has("EC")) {
                    for (Entry e : m.pick("EC")) { res.actions.add(new Action("KILL", spec(e), "", ign ? 2 : kill ? 0 : 1)); did = true; }
                    if (!m.has("BG")) continue;
                }
                if (ign) continue;
                if (m.has("G")) {
                    for (Entry e : m.pick("G")) for (String[] r : Groups.rules(e.id)) { res.actions.add(new Action("BLOCKS", r[0], r[1], 0)); did = true; }
                } else if (m.has("B")) {
                    for (Entry e : m.pick("B")) { res.actions.add(new Action("BLOCKS", e.id, "minecraft:air", 0)); did = true; }
                } else if (m.has("I") && !m.has("EC")) {
                    for (Entry e : m.pick("I")) { res.actions.add(new Action("BLOCKS", e.id, "minecraft:air", 0)); did = true; }
                }
            }
            if (did) return flags;
        }

        // --- призвать / дать ---
        boolean did = false;
        for (Match m : ms) {
            int n = numberNear(toks, m.start);
            if (m.has("E") && !(give && !summon && m.has("I"))) {
                for (Entry e : m.pick("E")) { res.actions.add(new Action("SUMMON", e.id, "", Math.max(1, n))); did = true; }
            } else if (m.has("I")) {
                for (Entry e : m.pick("I")) { res.actions.add(new Action("GIVE", e.id, "", Math.max(1, n))); did = true; }
            } else if (m.has("B")) {
                for (Entry e : m.pick("B")) { res.actions.add(new Action("GIVE", e.id, "", Math.max(1, n))); did = true; }
            } else if (m.has("F")) {
                for (Entry e : m.pick("F")) { res.actions.add(new Action("EFFECT", e.id, "1", 600)); did = true; }
            }
        }
        return did ? flags : flags;
    }

    private static String spec(Entry e) { return e.kind == 'C' ? "cat:" + e.id : "entity:" + e.id; }

    // ---------------- группы блоков ----------------
    public static final class Groups {
        /** Возвращает пары {список блоков через запятую (можно #теги), во что превратить}. */
        public static List<String[]> rules(String key) {
            String air = "minecraft:air";
            switch (key) {
                case "grass": return Arrays.asList(
                        new String[]{"minecraft:grass,minecraft:tall_grass,minecraft:fern,minecraft:large_fern", air},
                        new String[]{"minecraft:grass_block", "minecraft:dirt"});
                case "trees": return Collections.singletonList(new String[]{"#minecraft:logs,#minecraft:leaves", air});
                case "leaves": return Collections.singletonList(new String[]{"#minecraft:leaves", air});
                case "flowers": return Collections.singletonList(new String[]{"#minecraft:flowers", air});
                case "water": return Collections.singletonList(new String[]{"minecraft:water", air});
                case "lava": return Collections.singletonList(new String[]{"minecraft:lava", air});
                case "liquids": return Collections.singletonList(new String[]{"minecraft:water,minecraft:lava", air});
                case "snow": return Collections.singletonList(new String[]{"#minecraft:snow", air});
                case "ice": return Collections.singletonList(new String[]{"#minecraft:ice", air});
                case "dirt": return Collections.singletonList(new String[]{"minecraft:dirt,minecraft:coarse_dirt,minecraft:rooted_dirt,minecraft:podzol,minecraft:mycelium,minecraft:grass_block,minecraft:dirt_path,minecraft:farmland,minecraft:mud", air});
                case "mushrooms": return Collections.singletonList(new String[]{"minecraft:red_mushroom,minecraft:brown_mushroom,minecraft:red_mushroom_block,minecraft:brown_mushroom_block,minecraft:mushroom_stem,minecraft:crimson_fungus,minecraft:warped_fungus", air});
                case "ores": return Collections.singletonList(new String[]{"#minecraft:coal_ores,#minecraft:iron_ores,#minecraft:copper_ores,#minecraft:gold_ores,#minecraft:redstone_ores,#minecraft:lapis_ores,#minecraft:diamond_ores,#minecraft:emerald_ores,minecraft:nether_gold_ore,minecraft:nether_quartz_ore,minecraft:ancient_debris", air});
                default: return Collections.emptyList();
            }
        }
        /** Во что превращать, если группа указана как ЦЕЛЬ замены («замени воду на лаву»). */
        public static String target(String key) {
            switch (key) {
                case "grass": return "minecraft:grass_block";
                case "water": return "minecraft:water";
                case "lava": return "minecraft:lava";
                case "snow": return "minecraft:snow_block";
                case "ice": return "minecraft:ice";
                case "dirt": return "minecraft:dirt";
                case "trees": return "minecraft:oak_log";
                case "leaves": return "minecraft:oak_leaves";
                case "flowers": return "minecraft:poppy";
                case "mushrooms": return "minecraft:red_mushroom_block";
                case "ores": return "minecraft:diamond_ore";
                default: return null;
            }
        }
        private Groups() {}
    }

    // ---------------- свои синонимы (русские разговорные названия) ----------------
    public static void addAliases(Lexicon x) {
        // группы блоков
        x.aliases("трава|травы|траву|травой|grass", 'G', "grass");
        x.aliases("дерево|деревья|деревьев|деревом|лес|леса|tree|trees|forest|forests", 'G', "trees");
        x.aliases("листва|листву|листья|листьев|leaves|foliage", 'G', "leaves");
        x.aliases("цветы|цветов|цветок|цветочки|flowers|flower", 'G', "flowers");
        x.aliases("вода|воду|воды|водой|океан|океаны|океанов|море|моря|морей|озеро|озера|озер|река|реки|рек|water|ocean|oceans|sea|seas|lake|lakes|river|rivers", 'G', "water");
        x.aliases("лава|лаву|лавы|lava", 'G', "lava");
        x.aliases("жидкости|жидкость|liquids|liquid", 'G', "liquids");
        x.aliases("снег|снега|снегу|snow", 'G', "snow");
        x.aliases("лед|льда|льду|ice", 'G', "ice");
        x.aliases("земля|землю|земли|землей|почва|почву|dirt|soil", 'G', "dirt");
        x.aliases("грибы|грибов|гриб|mushrooms|mushroom", 'G', "mushrooms");
        x.aliases("руды|руду|руд|ore|ores", 'G', "ores");
        // категории мобов
        x.aliases("монстры|монстров|монстр|враги|врагов|враждебных|злых|hostile|monsters|monster|enemies|enemy", 'C', "hostile");
        x.aliases("животные|животных|животное|звери|зверей|animals|animal", 'C', "animals");
        x.aliases("мобы|мобов|мобы|существа|существ|все живое|всех живых|mobs|mob|creatures|creature", 'C', "mobs");
        // мобы
        x.aliases("эндер дракон|эндер дракона|эндердракон|дракон края|дракона края|дракон|дракона|дракону|драконов|ender dragon|dragon", 'E', "minecraft:ender_dragon");
        x.aliases("иссушитель|иссушителя|визер|визера|виз|уизер|уизера|wither", 'E', "minecraft:wither");
        x.aliases("крипер|крипера|криперов|криппер|creeper", 'E', "minecraft:creeper");
        x.aliases("зомби|zombie", 'E', "minecraft:zombie");
        x.aliases("скелет|скелета|скелетов|skeleton", 'E', "minecraft:skeleton");
        x.aliases("паук|паука|пауков|spider", 'E', "minecraft:spider");
        x.aliases("эндермен|эндермена|эндерменов|эндерман|странник края|enderman", 'E', "minecraft:enderman");
        x.aliases("курица|курицу|куриц|chicken", 'E', "minecraft:chicken");
        x.aliases("корова|корову|коров|cow", 'E', "minecraft:cow");
        x.aliases("свинья|свинью|свиней|pig", 'E', "minecraft:pig");
        x.aliases("овца|овцу|овец|sheep", 'E', "minecraft:sheep");
        x.aliases("лошадь|лошадей|лошади|horse", 'E', "minecraft:horse");
        x.aliases("волк|волка|волков|wolf", 'E', "minecraft:wolf");
        x.aliases("кошка|кошку|кошек|кот|кота|котов|cat", 'E', "minecraft:cat");
        x.aliases("лиса|лису|лис|fox", 'E', "minecraft:fox");
        x.aliases("панда|панду|панд|panda", 'E', "minecraft:panda");
        x.aliases("кролик|кролика|кроликов|rabbit", 'E', "minecraft:rabbit");
        x.aliases("попугай|попугая|parrot", 'E', "minecraft:parrot");
        x.aliases("летучая мышь|летучую мышь|летучих мышей|bat", 'E', "minecraft:bat");
        x.aliases("житель|жителя|жителей|жители|деревенский житель|villager", 'E', "minecraft:villager");
        x.aliases("железный голем|железного голема|iron golem", 'E', "minecraft:iron_golem");
        x.aliases("снежный голем|снежного голема|snow golem", 'E', "minecraft:snow_golem");
        x.aliases("ифрит|ифрита|блейз|блейза|blaze", 'E', "minecraft:blaze");
        x.aliases("гаст|гаста|ghast", 'E', "minecraft:ghast");
        x.aliases("слизень|слизня|слизь|слизи|slime", 'E', "minecraft:slime");
        x.aliases("ведьма|ведьму|ведьм|witch", 'E', "minecraft:witch");
        x.aliases("страж|стража|guardian", 'E', "minecraft:guardian");
        x.aliases("хранитель|хранителя|warden", 'E', "minecraft:warden");
        x.aliases("шалкер|шалкера|shulker", 'E', "minecraft:shulker");
        x.aliases("фантом|фантома|phantom", 'E', "minecraft:phantom");
        x.aliases("пиглин|пиглина|piglin", 'E', "minecraft:piglin");
        x.aliases("хоглин|хоглина|hoglin", 'E', "minecraft:hoglin");
        x.aliases("аксолотль|аксолотля|axolotl", 'E', "minecraft:axolotl");
        x.aliases("молния|молнию|молнии|lightning", 'E', "minecraft:lightning_bolt");
        // предметы
        x.aliases("алмаз|алмазы|алмазов|алмаза|diamond|diamonds", 'I', "minecraft:diamond");
        x.aliases("изумруд|изумруды|изумрудов|emerald|emeralds", 'I', "minecraft:emerald");
        x.aliases("золото|золота|gold", 'I', "minecraft:gold_ingot");
        x.aliases("железо|железа|iron", 'I', "minecraft:iron_ingot");
        x.aliases("незерит|незерита|netherite", 'I', "minecraft:netherite_ingot");
        x.aliases("уголь|угля|coal", 'I', "minecraft:coal");
        x.aliases("редстоун|редстоуна|redstone", 'I', "minecraft:redstone");
        x.aliases("элитры|элитр|elytra", 'I', "minecraft:elytra");
        x.aliases("тотем|тотема|totem", 'I', "minecraft:totem_of_undying");
        x.aliases("звезда незера|звезду незера|nether star", 'I', "minecraft:nether_star");
        x.aliases("золотое яблоко|золотых яблок|golden apple", 'I', "minecraft:golden_apple");
        x.aliases("динамит|динамита|тнт|tnt", 'I', "minecraft:tnt");
        x.aliases("тнт|tnt|динамит", 'B', "minecraft:tnt");
        // эффекты
        x.aliases("скорость|скорости|speed", 'F', "minecraft:speed");
        x.aliases("сила|силу|силы|strength", 'F', "minecraft:strength");
        x.aliases("регенерация|регенерацию|regeneration", 'F', "minecraft:regeneration");
        x.aliases("невидимость|невидимости|invisibility", 'F', "minecraft:invisibility");
        x.aliases("ночное зрение|ночного зрения|night vision", 'F', "minecraft:night_vision");
        x.aliases("огнестойкость|огнестойкости|огнеупорность|fire resistance", 'F', "minecraft:fire_resistance");
        x.aliases("прыгучесть|прыгучести|jump boost", 'F', "minecraft:jump_boost");
        x.aliases("подводное дыхание|water breathing", 'F', "minecraft:water_breathing");
        x.aliases("спешка|спешку|haste", 'F', "minecraft:haste");
        x.aliases("удача|удачу|luck", 'F', "minecraft:luck");
        x.aliases("сопротивление|сопротивления|resistance", 'F', "minecraft:resistance");
        x.aliases("левитация|левитацию|levitation", 'F', "minecraft:levitation");
    }

    private WishText() {}
}
