package com.example.fxmod.wish;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;

/** «Удали всю траву в мире»: правило записывается в сейв, применяется к загруженным чанкам и ко всем новым. */
public final class WishRules {
    private static final class Job {
        final ServerWorld w; final int cx, cz;
        Job(ServerWorld w, int cx, int cz) { this.w = w; this.cx = cx; this.cz = cz; }
    }

    private static final class Compiled {
        final Set<Block> blocks = new HashSet<>(); final List<TagKey<Block>> tags = new ArrayList<>(); final BlockState to; final boolean water;
        Compiled(String from, String toId) {
            boolean w = false;
            for (String part : from.split(",")) {
                part = part.trim();
                if (part.isEmpty()) continue;
                if (part.startsWith("#")) {
                    Identifier id = Identifier.tryParse(part.substring(1));
                    if (id != null) tags.add(TagKey.of(RegistryKeys.BLOCK, id));
                } else {
                    Identifier id = Identifier.tryParse(part);
                    if (id == null) continue;
                    Block b = Registries.BLOCK.get(id);
                    if (b != Blocks.AIR) blocks.add(b);
                    if (b == Blocks.WATER) w = true;
                }
            }
            water = w;
            Identifier tid = Identifier.tryParse(toId);
            to = (tid == null ? Blocks.AIR : Registries.BLOCK.get(tid)).getDefaultState();
        }
        boolean empty() { return blocks.isEmpty() && tags.isEmpty(); }
        boolean matches(BlockState s) {
            if (blocks.contains(s.getBlock())) return true;
            for (TagKey<Block> t : tags) if (s.isIn(t)) return true;
            if (water) {
                if (s.contains(Properties.WATERLOGGED) && s.get(Properties.WATERLOGGED)) return true;
                return s.isOf(Blocks.KELP) || s.isOf(Blocks.KELP_PLANT) || s.isOf(Blocks.SEAGRASS) || s.isOf(Blocks.TALL_SEAGRASS) || s.isOf(Blocks.BUBBLE_COLUMN);
            }
            return false;
        }
        BlockState result(BlockState s) {
            if (water && !s.isOf(Blocks.WATER) && s.contains(Properties.WATERLOGGED) && s.get(Properties.WATERLOGGED))
                return s.with(Properties.WATERLOGGED, false);   // не ломаем блок, только убираем воду
            return to;
        }
    }

    private static final ConcurrentLinkedQueue<Job> JOBS = new ConcurrentLinkedQueue<>();
    private static List<Compiled> compiled = new ArrayList<>();
    private static int compiledFor = -1;

    public static void clear() { JOBS.clear(); compiled = new ArrayList<>(); compiledFor = -1; }

    private static List<Compiled> compiled(WishState st) {
        if (compiledFor != st.rules.size()) {
            List<Compiled> list = new ArrayList<>();
            for (String[] r : st.rules) { Compiled c = new Compiled(r[0], r[1]); if (!c.empty()) list.add(c); }
            compiled = list;
            compiledFor = st.rules.size();
        }
        return compiled;
    }

    /** Добавить правило. Возвращает true, если оно действительно что-то означает. */
    public static boolean addRule(MinecraftServer server, String from, String to) {
        Compiled c = new Compiled(from, to);
        if (c.empty()) return false;
        WishState st = WishState.get(server);
        for (String[] r : st.rules) if (r[0].equals(from) && r[1].equals(to)) { scanAroundPlayers(server); return true; }
        if (st.rules.size() >= 64) st.rules.remove(0);
        st.rules.add(new String[]{from, to});
        st.markDirty();
        scanAroundPlayers(server);
        return true;
    }

    /** Поставить в очередь все загруженные чанки вокруг игроков. */
    public static void scanAroundPlayers(MinecraftServer server) {
        int r = server.getPlayerManager().getViewDistance() + 1;
        for (ServerPlayerEntity pl : server.getPlayerManager().getPlayerList()) {
            ServerWorld w = pl.getServerWorld();
            ChunkPos cp = pl.getChunkPos();
            for (int dx = -r; dx <= r; dx++)
                for (int dz = -r; dz <= r; dz++) JOBS.add(new Job(w, cp.x + dx, cp.z + dz));
        }
    }

    /** Новый загруженный чанк: применяем правила (трава не вырастет там, где её «отменили»). */
    public static void onChunkLoad(ServerWorld world, WorldChunk chunk) {
        MinecraftServer server = world.getServer();
        if (server == null || WishState.get(server).rules.isEmpty()) return;
        JOBS.add(new Job(world, chunk.getPos().x, chunk.getPos().z));
    }

    public static void tick(MinecraftServer server) {
        if (JOBS.isEmpty()) return;
        List<Compiled> rules = compiled(WishState.get(server));
        if (rules.isEmpty()) { JOBS.clear(); return; }
        long deadline = System.nanoTime() + 8_000_000L;
        Job j;
        while (System.nanoTime() < deadline && (j = JOBS.poll()) != null) {
            Chunk c = j.w.getChunk(j.cx, j.cz, ChunkStatus.FULL, false);
            if (c instanceof WorldChunk wc) process(j.w, wc, rules);
        }
    }

    private static boolean any(List<Compiled> rules, BlockState s) {
        for (Compiled r : rules) if (r.matches(s)) return true;
        return false;
    }

    private static void process(ServerWorld w, WorldChunk ch, List<Compiled> rules) {
        ChunkSection[] secs = ch.getSectionArray();
        ChunkPos cp = ch.getPos();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int si = 0; si < secs.length; si++) {
            ChunkSection s = secs[si];
            if (s == null || s.isEmpty() || !s.hasAny(st -> any(rules, st))) continue;
            int baseY = (ch.getBottomSectionCoord() + si) * 16;
            for (int y = 0; y < 16; y++)
                for (int z = 0; z < 16; z++)
                    for (int x = 0; x < 16; x++) {
                        BlockState st = s.getBlockState(x, y, z);
                        for (Compiled r : rules) {
                            if (!r.matches(st)) continue;
                            BlockState ns = r.result(st);
                            if (ns != st) w.setBlockState(m.set(cp.getStartX() + x, baseY + y, cp.getStartZ() + z), ns, Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
                            break;
                        }
                    }
        }
    }

    private WishRules() {}
}
