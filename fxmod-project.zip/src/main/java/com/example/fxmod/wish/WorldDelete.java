package com.example.fxmod.wish;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.WorldSavePath;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;

/**
 * Желание «удалить мир». Только в одиночной игре и только с подтверждением (написать желание второй раз).
 * Мир не стирается безвозвратно: после выхода папка мира переезжает в «deleted_worlds» рядом с игрой, и из списка миров пропадает.
 */
public final class WorldDelete {
    private static final Map<UUID, Integer> CONFIRM = new HashMap<>();
    private static int now = 0;
    private static int stopIn = -1;
    private static MinecraftServer stopping;
    private static Path pendingRoot;

    public static void clear() { CONFIRM.clear(); stopIn = -1; stopping = null; }

    /** true, если игрок уже подтвердил (второй раз за 30 секунд). Иначе просит подтвердить и возвращает false. */
    public static boolean confirm(ServerPlayerEntity p) {
        Integer t = CONFIRM.get(p.getUuid());
        if (t != null && now - t <= 600) { CONFIRM.remove(p.getUuid()); return true; }
        CONFIRM.put(p.getUuid(), now);
        p.sendMessage(Text.literal("⚠ «Удалить мир» уберёт этот мир из списка миров (папка уедет в deleted_worlds). "
                + "Чтобы подтвердить, напиши то же желание ещё раз в течение 30 секунд. Предмет пока не потрачен."), false);
        return false;
    }

    /** Запланировать выход и перенос мира. */
    public static String schedule(MinecraftServer server) {
        pendingRoot = server.getSavePath(WorldSavePath.ROOT).toAbsolutePath().normalize();
        stopping = server;
        stopIn = 100;   // 5 секунд на «растворение» мира
        return "Мир растворяется… через несколько секунд игра выйдет в меню";
    }

    public static void tick() {
        now++;
        if (stopIn < 0 || stopping == null) return;
        if (--stopIn == 0) {
            MinecraftServer s = stopping;
            stopping = null;
            s.stop(false);
        }
    }

    /** Вызывается после полной остановки сервера (файлы мира уже закрыты). */
    public static void finish() {
        Path src = pendingRoot;
        pendingRoot = null;
        if (src == null) return;
        try {
            Path dest = FabricLoader.getInstance().getGameDir().resolve("deleted_worlds");
            Files.createDirectories(dest);
            Path target = dest.resolve(src.getFileName() + "_" + System.currentTimeMillis());
            try {
                Files.move(src, target);
            } catch (IOException e) {          // другой диск: копируем и удаляем
                copyTree(src, target);
                deleteTree(src);
            }
        } catch (Exception ignored) { }
    }

    private static void copyTree(Path from, Path to) throws IOException {
        try (Stream<Path> s = Files.walk(from)) {
            for (Path p : (Iterable<Path>) s::iterator) {
                Path t = to.resolve(from.relativize(p).toString());
                if (Files.isDirectory(p)) Files.createDirectories(t); else Files.copy(p, t);
            }
        }
    }

    private static void deleteTree(Path root) throws IOException {
        try (Stream<Path> s = Files.walk(root)) {
            for (Path p : (Iterable<Path>) s.sorted(Comparator.reverseOrder())::iterator) Files.deleteIfExists(p);
        }
    }

    private WorldDelete() {}
}
