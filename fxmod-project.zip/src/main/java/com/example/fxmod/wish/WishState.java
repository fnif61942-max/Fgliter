package com.example.fxmod.wish;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.ArrayList;
import java.util.List;

/** Правила мира, загаданные хроно-желанием («нет травы»…). Хранятся в сейве и применяются к новым чанкам. */
public final class WishState extends PersistentState {
    public final List<String[]> rules = new ArrayList<>();   // {откуда (id/#теги через запятую), во что}

    public static WishState get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(WishState::fromNbt, WishState::new, "fxmod_wishes");
    }

    public static WishState fromNbt(NbtCompound nbt) {
        WishState st = new WishState();
        NbtList list = nbt.getList("rules", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < list.size(); i++) {
            NbtCompound c = list.getCompound(i);
            st.rules.add(new String[]{c.getString("from"), c.getString("to")});
        }
        return st;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtList list = new NbtList();
        for (String[] r : rules) {
            NbtCompound c = new NbtCompound();
            c.putString("from", r[0]);
            c.putString("to", r[1]);
            list.add(c);
        }
        nbt.put("rules", list);
        return nbt;
    }
}
