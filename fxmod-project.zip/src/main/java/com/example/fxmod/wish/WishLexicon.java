package com.example.fxmod.wish;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/** Словарь названий для разбора желаний: английские id + названия на языке игры + русские синонимы. */
public final class WishLexicon {
    private static WishText.Lexicon cached;

    public static void clear() { cached = null; }

    public static WishText.Lexicon get() {
        if (cached != null) return cached;
        WishText.Lexicon lex = new WishText.Lexicon();
        for (Block b : Registries.BLOCK) {
            if (b == Blocks.AIR || b == Blocks.CAVE_AIR || b == Blocks.VOID_AIR) continue;
            add(lex, 'B', Registries.BLOCK.getId(b), b.getName().getString());
        }
        for (Item it : Registries.ITEM) {
            if (it == Items.AIR) continue;
            add(lex, 'I', Registries.ITEM.getId(it), it.getName().getString());
        }
        for (EntityType<?> t : Registries.ENTITY_TYPE) {
            if (t == EntityType.PLAYER) continue;
            if (!t.isSummonable() && t != EntityType.LIGHTNING_BOLT) continue;
            add(lex, 'E', Registries.ENTITY_TYPE.getId(t), t.getName().getString());
        }
        for (StatusEffect e : Registries.STATUS_EFFECT) {
            add(lex, 'F', Registries.STATUS_EFFECT.getId(e), e.getName().getString());
        }
        WishText.addAliases(lex);
        cached = lex;
        return lex;
    }

    private static void add(WishText.Lexicon lex, char kind, Identifier id, String localized) {
        if (id == null) return;
        String en = id.getPath().replace('_', ' ');
        lex.add(en, kind, id.toString(), false);
        if (localized != null && !localized.isEmpty() && !WishText.normalize(localized).equals(WishText.normalize(en)))
            lex.add(localized, kind, id.toString(), false);
    }

    private WishLexicon() {}
}
