package com.example.fxmod.wish;

import com.example.fxmod.FxMod;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.particle.ItemStackParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/** Церемония «Хроно желания»: магический круг, колонны света, шар над головой, вспышка, исполнение желания. */
public final class Wishes {
    public static final double APEX = 30.0;      // высота шара над игроком
    public static final int T_BUILD = 90;        // момент исполнения желания
    public static final int T_END = 150;

    private static final Random RNG = new Random();
    private static final List<Ceremony> ACTIVE = new ArrayList<>();

    private static final class Ceremony {
        final ServerWorld w; final ServerPlayerEntity p; final Vec3d O; final WishText.Result plan; int u = 0;
        Ceremony(ServerWorld w, ServerPlayerEntity p, Vec3d O, WishText.Result plan) { this.w = w; this.p = p; this.O = O; this.plan = plan; }
    }

    public static void clear() { ACTIVE.clear(); }

    // ---------- приём желания ----------
    public static void submit(ServerPlayerEntity p, String raw) {
        ItemStack stack = p.getMainHandStack().isOf(FxMod.CHRONO_WISH) ? p.getMainHandStack()
                : p.getOffHandStack().isOf(FxMod.CHRONO_WISH) ? p.getOffHandStack() : null;
        if (stack == null) { p.sendMessage(Text.literal("Возьми Хроно желание в руку"), true); return; }
        for (Ceremony c : ACTIVE) if (c.p == p) return;

        String text = raw == null ? "" : raw.trim();
        if (text.length() > 200) text = text.substring(0, 200);
        if (text.isEmpty()) return;

        WishText.Result res = WishText.parse(text, WishLexicon.get());
        if (res.actions.isEmpty()) {
            p.sendMessage(Text.literal("Хроно желание не поняло: «" + text + "». Предмет не потрачен. Попробуй иначе, например: "
                    + "«удали всю траву в мире», «Эндер дракон», «убей всех монстров», «сделай ночь», «дай 64 алмаза», «замени воду на лаву»."), false);
            return;
        }
        stack.decrement(1);   // предмет исчезает

        ServerWorld w = p.getServerWorld();
        Ceremony c = new Ceremony(w, p, p.getPos(), res);
        ACTIVE.add(c);

        p.networkHandler.sendPacket(new TitleFadeS2CPacket(10, 100, 20));
        p.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal(text).formatted(Formatting.YELLOW)));
        p.networkHandler.sendPacket(new TitleS2CPacket(Text.literal("ХРОНО ЖЕЛАНИЕ").formatted(Formatting.GOLD, Formatting.BOLD)));

        for (ServerPlayerEntity pl : w.getPlayers()) {
            if (pl.squaredDistanceTo(p) > 300 * 300) continue;
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeInt(p.getId());
            buf.writeDouble(c.O.x); buf.writeDouble(c.O.y); buf.writeDouble(c.O.z);
            ServerPlayNetworking.send(pl, FxMod.WISH_START, buf);
        }
    }

    // ---------- частицы ----------
    private static void fx(ServerWorld w, ParticleEffect e, double x, double y, double z, int n, double dx, double dy, double dz, double sp) {
        for (ServerPlayerEntity pl : w.getPlayers()) w.spawnParticles(pl, e, true, x, y, z, n, dx, dy, dz, sp);
    }
    private static void fxv(ServerWorld w, ParticleEffect e, double x, double y, double z, double vx, double vy, double vz) {
        for (ServerPlayerEntity pl : w.getPlayers()) w.spawnParticles(pl, e, true, x, y, z, 0, vx, vy, vz, 1.0);
    }
    private static double smooth(double x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
    private static void snd(Ceremony c, SoundEvent s, double vol, double pitch) {
        c.w.playSound(null, c.O.x, c.O.y, c.O.z, s, SoundCategory.PLAYERS, (float) vol, (float) pitch);
    }

    private static void arc(Ceremony c, ParticleEffect e, double r, double g0, double g1) {
        int n = Math.max(1, (int) (Math.abs(g1 - g0) * r / 0.3));
        for (int i = 0; i <= n; i++) {
            double g = g0 + (g1 - g0) * i / n;
            fxv(c.w, e, c.O.x + Math.cos(g) * r, c.O.y + 0.15, c.O.z + Math.sin(g) * r, 0, 0, 0);
        }
    }

    private static void line(Ceremony c, ParticleEffect e, double x0, double z0, double x1, double z1) {
        double len = Math.hypot(x1 - x0, z1 - z0);
        int n = Math.max(1, (int) (len / 0.35));
        for (int i = 0; i <= n; i++) {
            double s = i / (double) n;
            fxv(c.w, e, c.O.x + x0 + (x1 - x0) * s, c.O.y + 0.15, c.O.z + z0 + (z1 - z0) * s, 0, 0, 0);
        }
    }

    /** Гексаграмма (две треугольника), вращается. */
    private static void star(Ceremony c, double r, double rot) {
        for (int t = 0; t < 2; t++) {
            for (int i = 0; i < 3; i++) {
                double a0 = rot + t * Math.PI / 3 + i * Math.PI * 2 / 3, a1 = rot + t * Math.PI / 3 + (i + 1) * Math.PI * 2 / 3;
                line(c, ParticleTypes.ELECTRIC_SPARK, Math.cos(a0) * r, Math.sin(a0) * r, Math.cos(a1) * r, Math.sin(a1) * r);
            }
        }
    }

    // ---------- тик ----------
    public static void tick() {
        Iterator<Ceremony> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Ceremony c = it.next();
            c.u++;
            if (c.p.isRemoved()) { it.remove(); continue; }
            if (c.u <= T_BUILD + 5) {   // во время церемонии игрок неподвижен и неуязвим
                c.p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 5, 6, false, false, false));
                c.p.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 5, 200, false, false, false));
                c.p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 5, 4, false, false, false));
            }
            if (c.u <= T_BUILD) build(c);
            if (c.u == T_BUILD) climax(c);
            if (c.u > T_BUILD) afterglow(c);
            if (c.u >= T_END) it.remove();
        }
    }

    private static void build(Ceremony c) {
        int u = c.u;
        Vec3d O = c.O;
        ServerWorld w = c.w;
        double[] radii = {3.0, 5.5, 8.5};
        double apexY = O.y + APEX;

        if (u <= 30) {                                      // круги рисуются по кругу
            for (int i = 0; i < 3; i++) arc(c, ParticleTypes.END_ROD, radii[i], i + (u - 1) / 30.0 * Math.PI * 2, i + u / 30.0 * Math.PI * 2);
        } else if (u % 16 == 0) {
            for (int i = 0; i < 3; i++) arc(c, ParticleTypes.END_ROD, radii[i], 0, Math.PI * 2);
        }
        star(c, 5.5, u * 0.06);

        if (u >= 20) {                                      // колонны света растут вверх
            double head = Math.min(APEX, (u - 20) * 0.75);
            for (int k = 0; k < 12; k++) {
                double a = k * Math.PI / 6 + u * 0.02;
                double x = O.x + Math.cos(a) * radii[2], z = O.z + Math.sin(a) * radii[2];
                fx(w, ParticleTypes.END_ROD, x, O.y + head, z, 2, 0.1, 0.1, 0.1, 0.01);
                if (u % 8 == 0) for (double y = 0; y <= head; y += 1.0) fxv(w, ParticleTypes.END_ROD, x, O.y + y, z, 0, 0, 0);
            }
        }
        if (u >= 60) {                                      // лучи сходятся к шару
            double pr = (u - 60) / 30.0;
            for (int k = 0; k < 12; k++) {
                double a = k * Math.PI / 6 + u * 0.02;
                double sx = O.x + Math.cos(a) * radii[2], sz = O.z + Math.sin(a) * radii[2];
                for (double s = 0; s <= pr; s += 0.04)
                    fxv(w, ParticleTypes.END_ROD, sx + (O.x - sx) * s, apexY - 0.0 + 0 * s, sz + (O.z - sz) * s, 0, 0, 0);
            }
        }
        double orbR = 0.3 + 2.7 * smooth(u / (double) T_BUILD);   // шар над головой
        for (int i = 0; i < 40; i++) {
            double th = RNG.nextDouble() * Math.PI * 2, z = RNG.nextDouble() * 2 - 1, rr = Math.sqrt(1 - z * z);
            fxv(w, ParticleTypes.END_ROD, O.x + rr * Math.cos(th) * orbR, apexY + z * orbR, O.z + rr * Math.sin(th) * orbR, 0, 0, 0);
        }
        fx(w, ParticleTypes.SOUL_FIRE_FLAME, O.x, apexY, O.z, 4, orbR * 0.5, orbR * 0.5, orbR * 0.5, 0.02);

        if (u > 10) {                                       // руны летят с земли в шар
            for (int i = 0; i < 6; i++) {
                double a = RNG.nextDouble() * Math.PI * 2, r = radii[2] + RNG.nextDouble() * 3;
                double sx = O.x + Math.cos(a) * r, sy = O.y + RNG.nextDouble() * 2, sz = O.z + Math.sin(a) * r;
                fxv(w, ParticleTypes.ENCHANT, sx, sy, sz, O.x - sx, apexY - sy, O.z - sz);
            }
        }
        if (u == 1) { snd(c, SoundEvents.BLOCK_BEACON_ACTIVATE, 6, 0.6); snd(c, SoundEvents.BLOCK_BELL_USE, 6, 0.6); }
        if (u % 10 == 0) snd(c, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 4, 0.5 + 1.5 * u / T_BUILD);
        if (u == 60) snd(c, SoundEvents.BLOCK_END_PORTAL_SPAWN, 3, 0.8);
    }

    private static void climax(Ceremony c) {
        ServerWorld w = c.w;
        Vec3d O = c.O;
        double ay = O.y + APEX;
        fx(w, ParticleTypes.FLASH, O.x, ay, O.z, 10, 2, 2, 2, 0);
        fx(w, ParticleTypes.TOTEM_OF_UNDYING, O.x, ay, O.z, 300, 3, 3, 3, 0.7);
        fx(w, ParticleTypes.END_ROD, O.x, ay, O.z, 300, 4, 4, 4, 0.6);
        fx(w, new ItemStackParticleEffect(ParticleTypes.ITEM, new ItemStack(FxMod.CHRONO_WISH)), O.x, ay, O.z, 60, 2, 2, 2, 0.4);
        fx(w, ParticleTypes.EXPLOSION_EMITTER, O.x, O.y + 1, O.z, 3, 2, 1, 2, 0);

        for (int i = 0; i < 6; i++) {                       // молнии-эффект по кольцу
            double a = RNG.nextDouble() * Math.PI * 2, r = 9 + RNG.nextDouble() * 5;
            int x = (int) Math.floor(O.x + Math.cos(a) * r), z = (int) Math.floor(O.z + Math.sin(a) * r);
            if (!w.isChunkLoaded(new BlockPos(x, (int) O.y, z))) continue;
            LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(w);
            if (bolt != null) {
                bolt.refreshPositionAfterTeleport(x + 0.5, w.getTopY(Heightmap.Type.WORLD_SURFACE, x, z), z + 0.5);
                bolt.setCosmetic(true);
                w.spawnEntity(bolt);
            }
        }
        snd(c, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 10, 0.6);
        snd(c, SoundEvents.ENTITY_PLAYER_LEVELUP, 8, 0.5);
        snd(c, SoundEvents.BLOCK_BELL_RESONATE, 8, 0.5);
        snd(c, SoundEvents.ENTITY_GENERIC_EXPLODE, 6, 0.6);

        // исполнение желания
        List<String> lines = new ArrayList<>();
        try { lines = WishExec.run(c.p, c.plan); } catch (Exception ex) { lines.add("Желание исполнилось не до конца"); }
        c.p.networkHandler.sendPacket(new TitleFadeS2CPacket(5, 60, 20));
        c.p.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal(lines.isEmpty() ? "" : lines.get(0)).formatted(Formatting.YELLOW)));
        c.p.networkHandler.sendPacket(new TitleS2CPacket(Text.literal("ЖЕЛАНИЕ ИСПОЛНЕНО").formatted(Formatting.GOLD, Formatting.BOLD)));
        for (String s : lines) c.p.sendMessage(Text.literal("✦ " + s).formatted(Formatting.GOLD), false);
    }

    private static void afterglow(Ceremony c) {
        int k = c.u - T_BUILD;
        Vec3d O = c.O;
        ServerWorld w = c.w;
        if (k <= 20) {                                      // золотая ударная волна по земле
            double r = k * 3.0;
            int pts = (int) (r * 2) + 12;
            for (int i = 0; i < pts; i++) {
                double a = i * Math.PI * 2 / pts;
                fxv(w, ParticleTypes.END_ROD, O.x + Math.cos(a) * r, O.y + 0.3, O.z + Math.sin(a) * r, 0, 0.15, 0);
                if (i % 4 == 0) fx(w, ParticleTypes.TOTEM_OF_UNDYING, O.x + Math.cos(a) * r, O.y + 0.5, O.z + Math.sin(a) * r, 1, 0.2, 0.3, 0.2, 0.2);
            }
        }
        if (k <= 45) {                                      // искры медленно падают
            for (int i = 0; i < 30; i++) {
                double a = RNG.nextDouble() * Math.PI * 2, r = RNG.nextDouble() * 14;
                fxv(w, ParticleTypes.END_ROD, O.x + Math.cos(a) * r, O.y + 4 + RNG.nextDouble() * 26, O.z + Math.sin(a) * r, 0, -0.35, 0);
            }
        }
    }

    private Wishes() {}
}
