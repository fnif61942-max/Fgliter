package com.example.fxmod.wish;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Журнал гибели существ: нужен, чтобы «отмотка времени» воскрешала убитых мобов. */
public final class EntityJournal {
    private static final int MAX = 3000;
    private static final ArrayDeque<Rec> LOG = new ArrayDeque<>();

    private static final class Rec {
        final RegistryKey<World> dim; final NbtCompound nbt; final int tick; final double x, y, z;
        Rec(RegistryKey<World> dim, NbtCompound nbt, int tick, double x, double y, double z) { this.dim = dim; this.nbt = nbt; this.tick = tick; this.x = x; this.y = y; this.z = z; }
    }

    public static void clear() { LOG.clear(); }

    /** Записать существо (вызывать при смерти или перед удалением). Игроков не записываем. */
    public static void record(Entity e) {
        if (e == null || e instanceof PlayerEntity || e.getWorld().isClient || !(e.getWorld() instanceof ServerWorld sw) || sw.getServer() == null) return;
        NbtCompound n = new NbtCompound();
        if (!e.saveSelfNbt(n)) return;
        n.remove("UUID");
        n.remove("DeathTime");
        n.remove("HurtTime");
        n.remove("Fire");
        n.remove("DragonPhase");
        n.remove("DragonDeathTime");
        float hp = e instanceof LivingEntity le ? Math.max(1f, le.getMaxHealth()) : 1f;
        n.putFloat("Health", hp);
        LOG.addLast(new Rec(sw.getRegistryKey(), n, sw.getServer().getTicks(), e.getX(), e.getY(), e.getZ()));
        while (LOG.size() > MAX) LOG.pollFirst();
    }

    /** Воскресить всех, кто погиб за последние windowTicks. Возвращает, сколько воскресло. */
    public static int revive(MinecraftServer server, int windowTicks) {
        int cutoff = server.getTicks() - windowTicks, count = 0;
        List<Rec> keep = new ArrayList<>();
        for (Rec r : new ArrayList<>(LOG)) {
            if (r.tick < cutoff) continue;                         // слишком давно — забываем
            ServerWorld w = server.getWorld(r.dim);
            if (w == null || !w.isChunkLoaded(BlockPos.ofFloored(r.x, r.y, r.z))) { keep.add(r); continue; }
            Entity e = EntityType.loadEntityWithPassengers(r.nbt.copy(), w, ent -> {
                ent.refreshPositionAndAngles(r.x, r.y, r.z, ent.getYaw(), ent.getPitch());
                return ent;
            });
            if (e == null) continue;
            if (e instanceof LivingEntity le) { le.setHealth(le.getMaxHealth()); le.deathTime = 0; le.hurtTime = 0; }
            w.spawnEntityAndPassengers(e);
            w.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, r.x, r.y + 1, r.z, 25, 0.4, 0.8, 0.4, 0.3);
            w.spawnParticles(ParticleTypes.REVERSE_PORTAL, r.x, r.y + 1, r.z, 30, 0.4, 0.8, 0.4, 0.2);
            count++;
        }
        LOG.clear();
        for (Rec r : keep) LOG.addLast(r);
        return count;
    }

    private EntityJournal() {}
}
