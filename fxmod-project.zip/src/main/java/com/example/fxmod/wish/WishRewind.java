package com.example.fxmod.wish;

import com.example.fxmod.ChronoHistory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** «Отмотай время назад»: воскрешает убитых и возвращает блоки, которые менялись за последние 3 минуты. */
public final class WishRewind {
    private static final List<ChronoHistory.Session> JOBS = new ArrayList<>();

    public static void clear() { JOBS.clear(); }

    public static String start(ServerPlayerEntity p, String mode) {
        MinecraftServer server = p.getServer();
        int revived = EntityJournal.revive(server, ChronoHistory.WINDOW);
        String blocks = "";
        if (!"mobs".equals(mode)) {
            ChronoHistory.Session s = ChronoHistory.begin(p.getServerWorld());
            if (s.total > 0) JOBS.add(s);
            blocks = ", блоков вернётся: " + s.total;
        }
        return "Время отмотано: воскресло существ " + revived + blocks;
    }

    public static void tick() {
        if (JOBS.isEmpty()) return;
        long deadline = System.nanoTime() + 12_000_000L;
        Iterator<ChronoHistory.Session> it = JOBS.iterator();
        while (it.hasNext()) {
            ChronoHistory.Session s = it.next();
            ChronoHistory.step(s, s.total, deadline, null);
            if (s.finished()) it.remove();
            if (System.nanoTime() > deadline) break;
        }
    }

    private WishRewind() {}
}
