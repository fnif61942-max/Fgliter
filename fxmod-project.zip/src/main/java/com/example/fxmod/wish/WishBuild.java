package com.example.fxmod.wish;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Постройки по желанию: дом, башня, замок, пирамида, мост, купол и др. Строятся слой за слоем, снизу вверх. */
public final class WishBuild {
    private static final BlockState AIR = Blocks.AIR.getDefaultState();
    private static final Random RNG = new Random();
    private static final List<Prepared> JOBS = new ArrayList<>();
    private static final Map<UUID, Map<WishText.Action, Prepared>> PRE = new HashMap<>();

    public static final class Prepared {
        public final String name; public final Vec3d center; public final double height, extent; public final int count;
        final ServerWorld w; final ServerPlayerEntity owner; final long[] pos; final BlockState[] st; final int perTick; int idx = 0; int tick = 0;
        Prepared(String name, Vec3d center, double height, double extent, ServerWorld w, ServerPlayerEntity owner, long[] pos, BlockState[] st) {
            this.name = name; this.center = center; this.height = height; this.extent = extent; this.w = w; this.owner = owner;
            this.pos = pos; this.st = st; this.count = pos.length;
            this.perTick = Math.max(40, (int) Math.ceil(pos.length / 90.0));   // вся постройка вырастает примерно за 4.5 секунды
        }
    }

    public static void clear() { JOBS.clear(); PRE.clear(); }

    /** Подготовить постройку заранее (нужно камере) и запомнить для исполнения. */
    public static Prepared register(ServerPlayerEntity p, WishText.Action a) {
        Prepared pr = prepare(p, a.a, a.b, a.n);
        if (pr != null) PRE.computeIfAbsent(p.getUuid(), k -> new IdentityHashMap<>()).put(a, pr);
        return pr;
    }

    public static Prepared take(ServerPlayerEntity p, WishText.Action a) {
        Map<WishText.Action, Prepared> m = PRE.get(p.getUuid());
        Prepared pr = m == null ? null : m.remove(a);
        return pr != null ? pr : prepare(p, a.a, a.b, a.n);
    }

    public static void start(Prepared pr) { JOBS.add(pr); }

    // ================= чертёж =================
    private static final class Plan {
        final Direction fwd, right, left; final BlockState mat;
        final List<int[]> pts = new ArrayList<>(); final List<BlockState> pal = new ArrayList<>(); final List<int[]> found = new ArrayList<>();
        int maxY = 0, minZ = 0, maxZ = 0, minX = 0, maxX = 0;
        Plan(Direction fwd, Direction right, Direction left, BlockState mat) { this.fwd = fwd; this.right = right; this.left = left; this.mat = mat; }
        BlockState wall(Block def) { return mat != null ? mat : def.getDefaultState(); }
        int idx(BlockState s) { int i = pal.indexOf(s); if (i < 0) { pal.add(s); i = pal.size() - 1; } return i; }
        void set(int x, int y, int z, BlockState s) {
            pts.add(new int[]{x, y, z, idx(s)});
            if (s != AIR) { maxY = Math.max(maxY, y); }
            minZ = Math.min(minZ, z); maxZ = Math.max(maxZ, z); minX = Math.min(minX, x); maxX = Math.max(maxX, x);
        }
        void found(int x, int z, BlockState s) { found.add(new int[]{x, z, idx(s)}); }
    }

    private static int size(int def, int code, int min, int max) {
        int v = code > 0 ? code : code == -1 ? (int) Math.round(def * 0.6) : code == -2 ? (int) Math.round(def * 1.5) : code == -3 ? (int) Math.round(def * 2.4) : def;
        return Math.max(min, Math.min(max, v));
    }

    public static Prepared prepare(ServerPlayerEntity p, String struct, String matId, int code) {
        Direction fwd = p.getHorizontalFacing();
        BlockState mat = null;
        if (matId != null && !matId.isEmpty()) {
            Identifier id = Identifier.tryParse(matId);
            if (id != null) { Block b = Registries.BLOCK.get(id); if (b != Blocks.AIR) mat = b.getDefaultState(); }
        }
        Plan P = new Plan(fwd, fwd.rotateYClockwise(), fwd.rotateYCounterclockwise(), mat);
        String name;
        switch (struct) {
            case "house": house(P, size(11, code, 7, 41)); name = "дом"; break;
            case "tower": tower(P, size(28, code, 10, 120)); name = "башня"; break;
            case "castle": castle(P, size(33, code, 21, 71)); name = "замок"; break;
            case "pyramid": pyramid(P, size(41, code, 11, 71)); name = "пирамида"; break;
            case "wall": wall(P, size(36, code, 8, 120)); name = "стена"; break;
            case "bridge": bridge(P, size(36, code, 8, 120)); name = "мост"; break;
            case "platform": platform(P, size(17, code, 5, 61)); name = "платформа"; break;
            case "pool": pool(P, size(15, code, 7, 41)); name = "бассейн"; break;
            case "dome": dome(P, size(25, code, 9, 71)); name = "купол"; break;
            case "sphere": sphere(P, size(21, code, 7, 61)); name = "сфера"; break;
            case "cube": cube(P, size(15, code, 5, 61)); name = "куб"; break;
            case "arch": arch(P, size(11, code, 5, 41)); name = "арка"; break;
            case "obelisk": obelisk(P, size(36, code, 10, 120)); name = "обелиск"; break;
            case "stairs": stairs(P, size(30, code, 8, 100)); name = "лестница"; break;
            case "lighthouse": lighthouse(P, size(30, code, 14, 100)); name = "маяк"; break;
            default: return null;
        }
        if (P.pts.isEmpty()) return null;
        return finish(p, P, name);
    }

    private static Prepared finish(ServerPlayerEntity p, Plan P, String name) {
        ServerWorld w = p.getServerWorld();
        BlockPos base = p.getBlockPos();
        int oz = 5 - P.minZ;
        List<Long> lp = new ArrayList<>();
        List<BlockState> ls = new ArrayList<>();
        for (int[] t : P.pts) {
            lp.add(base.offset(P.fwd, oz + t[2]).offset(P.right, t[0]).up(t[1]).asLong());
            ls.add(P.pal.get(t[3]));
        }
        for (int[] f : P.found) {                                   // фундамент: опускаем опоры до твёрдой земли
            BlockState s = P.pal.get(f[2]);
            for (int d = 0; d < 12; d++) {
                BlockPos bp = base.offset(P.fwd, oz + f[1]).offset(P.right, f[0]).up(-2 - d);
                if (!w.isChunkLoaded(bp)) break;
                BlockState cur = w.getBlockState(bp);
                if (!(cur.isAir() || cur.isReplaceable() || !cur.getFluidState().isEmpty())) break;
                lp.add(bp.asLong());
                ls.add(s);
            }
        }
        int n = lp.size();
        if (n > 200000) return null;
        long[] keys = new long[n];
        for (int i = 0; i < n; i++) keys[i] = ((long) (BlockPos.fromLong(lp.get(i)).getY() + 1024) << 24) | i;   // снизу вверх, порядок внутри слоя сохраняется
        Arrays.sort(keys);
        long[] pos = new long[n];
        BlockState[] st = new BlockState[n];
        for (int i = 0; i < n; i++) { int k = (int) (keys[i] & 0xFFFFFF); pos[i] = lp.get(k); st[i] = ls.get(k); }

        Vec3d center = new Vec3d(base.getX() + 0.5 + P.fwd.getOffsetX() * (oz + (P.minZ + P.maxZ) / 2.0) + P.right.getOffsetX() * ((P.minX + P.maxX) / 2.0),
                base.getY(), base.getZ() + 0.5 + P.fwd.getOffsetZ() * (oz + (P.minZ + P.maxZ) / 2.0) + P.right.getOffsetZ() * ((P.minX + P.maxX) / 2.0));
        double extent = Math.max(P.maxX - P.minX, P.maxZ - P.minZ) + 1;
        return new Prepared(name, center, P.maxY + 1, extent, w, p, pos, st);
    }

    // ================= исполнение =================
    private static void fx(ServerWorld w, net.minecraft.particle.ParticleEffect e, double x, double y, double z, int n, double d, double sp) {
        for (ServerPlayerEntity pl : w.getPlayers()) {
            if (pl.squaredDistanceTo(x, y, z) < 220 * 220) w.spawnParticles(pl, e, true, x, y, z, n, d, d, d, sp);
        }
    }

    public static void tick() {
        Iterator<Prepared> it = JOBS.iterator();
        BlockPos.Mutable m = new BlockPos.Mutable();
        while (it.hasNext()) {
            Prepared j = it.next();
            j.tick++;
            int end = Math.min(j.pos.length, j.idx + j.perTick);
            int first = j.idx;
            for (; j.idx < end; j.idx++) {
                m.set(j.pos[j.idx]);
                if (!j.w.isChunkLoaded(m)) continue;
                BlockState cur = j.w.getBlockState(m);
                if (!cur.isAir() && cur.getHardness(j.w, m) < 0) continue;
                j.w.setBlockState(m, j.st[j.idx], Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
            }
            for (int k = 0; k < 6 && end > first; k++) {          // искры на фронте стройки
                BlockPos bp = BlockPos.fromLong(j.pos[first + RNG.nextInt(end - first)]);
                fx(j.w, ParticleTypes.END_ROD, bp.getX() + 0.5, bp.getY() + 0.5, bp.getZ() + 0.5, 6, 0.6, 0.05);
                fx(j.w, ParticleTypes.ELECTRIC_SPARK, bp.getX() + 0.5, bp.getY() + 0.5, bp.getZ() + 0.5, 4, 0.5, 0.1);
            }
            if (j.tick % 4 == 0) j.w.playSound(null, j.center.x, j.center.y, j.center.z, SoundEvents.BLOCK_STONE_PLACE, SoundCategory.BLOCKS, 3f, 0.7f + 0.8f * j.idx / j.pos.length);
            if (j.idx >= j.pos.length) {
                fx(j.w, ParticleTypes.TOTEM_OF_UNDYING, j.center.x, j.center.y + j.height, j.center.z, 150, 3.0, 0.5);
                j.w.playSound(null, j.center.x, j.center.y, j.center.z, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.BLOCKS, 6f, 0.8f);
                if (!j.owner.isRemoved()) j.owner.sendMessage(Text.literal("✦ Постройка готова: " + j.name), false);
                it.remove();
            }
        }
    }

    // ================= генераторы (x вправо, y вверх, z вперёд; пол на уровне y = -1) =================
    private static BlockState torch() { return Blocks.TORCH.getDefaultState(); }

    private static BlockState roofStair(Plan P, Direction facing) {
        return P.mat != null ? P.mat : Blocks.OAK_STAIRS.getDefaultState().with(StairsBlock.FACING, facing);
    }

    /** Коробка с полом, стенами, окнами, дверью (в сторону игрока) и плоской крышей. */
    private static void box(Plan P, int cx, int cz, int hx, int hz, int H, BlockState wall, BlockState floor, boolean door, boolean roof, boolean crenel) {
        BlockState glass = Blocks.GLASS.getDefaultState(), cobble = Blocks.COBBLESTONE.getDefaultState();
        for (int x = -hx; x <= hx; x++)
            for (int z = -hz; z <= hz; z++) {
                int wx = cx + x, wz = cz + z;
                P.set(wx, -1, wz, floor);
                P.found(wx, wz, cobble);
                boolean edge = Math.abs(x) == hx || Math.abs(z) == hz;
                boolean corner = Math.abs(x) == hx && Math.abs(z) == hz;
                for (int y = 0; y < H; y++) {
                    if (!edge) { P.set(wx, y, wz, AIR); continue; }
                    boolean d = door && z == -hz && x == 0 && y <= 1;
                    boolean win = !corner && y >= 2 && y <= 3 && H >= 6 && ((Math.abs(x) == hx && Math.floorMod(z, 4) == 0) || (Math.abs(z) == hz && Math.floorMod(x, 4) == 0 && x != 0));
                    P.set(wx, y, wz, d ? AIR : win ? glass : wall);
                }
                if (roof) P.set(wx, H, wz, wall);
                if (roof && crenel && edge && ((wx + wz) & 1) == 0) P.set(wx, H + 1, wz, wall);
            }
        P.set(cx + hx - 1, 0, cz + hz - 1, torch());
        P.set(cx - hx + 1, 0, cz + hz - 1, torch());
    }

    private static void house(Plan P, int size) {
        int W = size | 1, D = (W + 4) | 1, hw = W / 2, hd = D / 2, H = 5;
        BlockState wall = P.wall(Blocks.OAK_PLANKS), log = P.mat != null ? P.mat : Blocks.OAK_LOG.getDefaultState(), glass = Blocks.GLASS.getDefaultState();
        BlockState floor = P.mat != null ? P.mat : Blocks.SPRUCE_PLANKS.getDefaultState(), cobble = Blocks.COBBLESTONE.getDefaultState();
        for (int x = -hw; x <= hw; x++)
            for (int z = -hd; z <= hd; z++) {
                P.set(x, -1, z, floor);
                P.found(x, z, cobble);
                boolean edge = Math.abs(x) == hw || Math.abs(z) == hd;
                boolean corner = Math.abs(x) == hw && Math.abs(z) == hd;
                for (int y = 0; y < H; y++) {
                    if (!edge) { P.set(x, y, z, AIR); continue; }
                    boolean door = z == -hd && x == 0 && y <= 1;
                    boolean win = !corner && y >= 1 && y <= 2 && ((Math.abs(x) == hw && Math.floorMod(z, 3) == 0) || (Math.abs(z) == hd && Math.abs(x) == 2));
                    P.set(x, y, z, door ? AIR : win ? glass : corner ? log : wall);
                }
            }
        for (int k = 0; k <= hw + 1; k++) {                          // двускатная крыша
            int xl = -(hw + 1) + k, xr = hw + 1 - k, y = H + k;
            if (xl > xr) break;
            for (int z = -hd - 1; z <= hd + 1; z++) {
                if (xl == xr) P.set(xl, y, z, P.wall(Blocks.OAK_PLANKS));
                else { P.set(xl, y, z, roofStair(P, P.right)); P.set(xr, y, z, roofStair(P, P.left)); }
            }
            for (int x = xl + 1; x <= xr - 1; x++) { P.set(x, y, -hd, wall); P.set(x, y, hd, wall); }
        }
        P.set(hw - 1, 0, hd - 1, torch()); P.set(-hw + 1, 0, hd - 1, torch());
        P.set(hw - 1, 0, -hd + 1, torch()); P.set(-hw + 1, 0, -hd + 1, torch());
    }

    private static void towerAt(Plan P, int cx, int cz, int R, int H, boolean ladder, boolean door) {
        BlockState wall = P.wall(Blocks.STONE_BRICKS), floorS = P.mat != null ? P.mat : Blocks.SPRUCE_PLANKS.getDefaultState(), cobble = Blocks.COBBLESTONE.getDefaultState();
        for (int x = -R; x <= R; x++)
            for (int z = -R; z <= R; z++) {
                double d = Math.hypot(x, z);
                if (d > R + 0.3) continue;
                boolean ring = d > R - 1.0;
                int wx = cx + x, wz = cz + z;
                P.set(wx, -1, wz, wall);
                P.found(wx, wz, cobble);
                for (int y = 0; y <= H; y++) {
                    if (!ring && ladder && x == 0 && z == R - 1) { P.set(wx, y, wz, Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, P.fwd.getOpposite())); continue; }
                    if (ring) {
                        boolean entr = door && x == 0 && z == -R && y <= 1;
                        boolean slit = y % 6 == 3 && y < H - 1 && ((x == 0 && Math.abs(z) == R) || (z == 0 && Math.abs(x) == R));
                        if (y == H) { if (((x + z) & 1) == 0 || (ladder && x == 0 && z == R)) P.set(wx, y, wz, wall); continue; }
                        P.set(wx, y, wz, entr || slit ? AIR : wall);
                    } else {
                        if (y == H) continue;
                        P.set(wx, y, wz, ((y % 6 == 0 && y > 0) || y == H - 1) ? floorS : AIR);
                    }
                }
            }
    }

    private static void tower(Plan P, int H) { towerAt(P, 0, 0, Math.max(3, Math.min(7, H / 7)), H, true, true); }

    private static void castle(Plan P, int W) {
        int hw = W / 2, wallH = 7;
        BlockState wall = P.wall(Blocks.STONE_BRICKS), cobble = Blocks.COBBLESTONE.getDefaultState();
        BlockState floor = P.mat != null ? P.mat : Blocks.SPRUCE_PLANKS.getDefaultState();
        for (int x = -hw; x <= hw; x++)
            for (int z = -hw; z <= hw; z++) {
                P.set(x, -1, z, cobble);
                P.found(x, z, cobble);
                boolean outer = Math.abs(x) >= hw - 1 || Math.abs(z) >= hw - 1;
                for (int y = 0; y < wallH; y++) {
                    if (!outer) { P.set(x, y, z, AIR); continue; }
                    boolean gate = z <= -hw + 1 && Math.abs(x) <= 1 && y <= 3;
                    P.set(x, y, z, gate ? AIR : wall);
                }
                if (outer && (Math.abs(x) == hw || Math.abs(z) == hw) && ((x + z) & 1) == 0) P.set(x, wallH, z, wall);
            }
        for (int sx : new int[]{-hw, hw}) for (int sz : new int[]{-hw, hw}) towerAt(P, sx, sz, 4, 14, false, false);
        int K = Math.max(9, (W / 3) | 1);
        box(P, 0, hw / 4, K / 2, K / 2, 13, wall, floor, true, true, true);
    }

    private static void pyramid(Plan P, int B) {
        B |= 1;
        int layers = B / 2 + 1;
        BlockState sand = P.wall(Blocks.SANDSTONE), gold = P.mat != null ? P.mat : Blocks.GOLD_BLOCK.getDefaultState(), cobble = Blocks.COBBLESTONE.getDefaultState();
        int hb = B / 2;
        for (int x = -hb; x <= hb; x++) for (int z = -hb; z <= hb; z++) { P.set(x, -1, z, sand); P.found(x, z, cobble); }
        for (int k = 0; k < layers; k++) {
            int half = hb - k;
            for (int x = -half; x <= half; x++)
                for (int z = -half; z <= half; z++) {
                    boolean edge = Math.abs(x) == half || Math.abs(z) == half;
                    boolean solid = edge || k >= layers - 3;
                    boolean tunnel = k <= 2 && z == -half && Math.abs(x) <= 1 && k <= 2;       // вход в пирамиду
                    P.set(x, k, z, tunnel ? AIR : solid ? (k >= layers - 2 ? gold : sand) : AIR);
                }
        }
        int t = Math.max(2, hb - 3);
        P.set(t, 0, t, torch()); P.set(-t, 0, t, torch()); P.set(t, 0, -t, torch()); P.set(-t, 0, -t, torch());
    }

    private static void wall(Plan P, int L) {
        BlockState wall = P.wall(Blocks.STONE_BRICKS), cobble = Blocks.COBBLESTONE.getDefaultState();
        for (int z = 0; z < L; z++)
            for (int x = -1; x <= 0; x++) {
                P.set(x, -1, z, wall);
                P.found(x, z, cobble);
                for (int y = 0; y < 6; y++) P.set(x, y, z, wall);
                if (z % 2 == 0) P.set(x, 6, z, wall);
            }
    }

    private static void bridge(Plan P, int L) {
        BlockState deck = P.wall(Blocks.OAK_PLANKS), fence = Blocks.OAK_FENCE.getDefaultState(), cobble = Blocks.COBBLESTONE.getDefaultState();
        for (int z = 0; z < L; z++) {
            for (int x = -2; x <= 2; x++) P.set(x, -1, z, deck);
            P.set(-2, 0, z, fence); P.set(2, 0, z, fence);
            if (z % 6 == 3) { P.set(-2, 1, z, fence); P.set(2, 1, z, fence); P.set(-2, 2, z, Blocks.LANTERN.getDefaultState()); P.set(2, 2, z, Blocks.LANTERN.getDefaultState()); }
            if (z % 8 == 4) { P.found(-2, z, cobble); P.found(2, z, cobble); }
        }
    }

    private static void platform(Plan P, int W) {
        BlockState floor = P.wall(Blocks.SMOOTH_STONE), rim = P.mat != null ? P.mat : Blocks.STONE_BRICKS.getDefaultState(), cobble = Blocks.COBBLESTONE.getDefaultState();
        int h = W / 2;
        for (int x = -h; x <= h; x++) for (int z = -h; z <= h; z++) { P.set(x, -1, z, (Math.abs(x) == h || Math.abs(z) == h) ? rim : floor); P.found(x, z, cobble); }
    }

    private static void pool(Plan P, int L) {
        int hx = Math.max(3, L / 3);
        BlockState quartz = P.wall(Blocks.QUARTZ_BLOCK), water = Blocks.WATER.getDefaultState(), lamp = Blocks.SEA_LANTERN.getDefaultState();
        for (int x = -hx - 1; x <= hx + 1; x++)
            for (int z = -1; z <= L; z++) {
                boolean rim = x == -hx - 1 || x == hx + 1 || z == -1 || z == L;
                for (int y = -4; y <= -1; y++) {
                    if (rim) P.set(x, y, z, (y == -1 && ((x == -hx - 1 || x == hx + 1) && (z == -1 || z == L))) ? lamp : quartz);
                    else P.set(x, y, z, y == -4 ? quartz : water);
                }
                P.set(x, 0, z, AIR);
            }
    }

    private static void dome(Plan P, int D) {
        int R = D / 2;
        BlockState glass = P.wall(Blocks.GLASS), floor = Blocks.SMOOTH_STONE.getDefaultState();
        for (int x = -R; x <= R; x++)
            for (int z = -R; z <= R; z++) {
                if (Math.hypot(x, z) <= R) P.set(x, -1, z, floor);
                for (int y = 0; y <= R; y++) {
                    double d = Math.sqrt(x * x + y * y + z * z);
                    if (d > R + 0.3 || d <= R - 1.0) continue;
                    boolean door = Math.abs(x) <= 1 && z < 0 && y <= 2;
                    P.set(x, y, z, door ? AIR : glass);
                }
            }
    }

    private static void sphere(Plan P, int D) {
        int R = D / 2;
        BlockState glass = P.wall(Blocks.GLASS);
        for (int x = -R; x <= R; x++)
            for (int y = -R; y <= R; y++)
                for (int z = -R; z <= R; z++) {
                    double d = Math.sqrt(x * x + y * y + z * z);
                    if (d > R + 0.3 || d <= R - 1.0) continue;
                    int yy = y + R;
                    boolean door = Math.abs(x) <= 1 && z < 0 && yy <= 2;
                    P.set(x, yy, z, door ? AIR : glass);
                }
        P.set(0, R, 0, Blocks.SEA_LANTERN.getDefaultState());
        P.set(0, -1, 0, Blocks.SMOOTH_STONE.getDefaultState());
    }

    private static void cube(Plan P, int S) {
        S |= 1;
        box(P, 0, 0, S / 2, S / 2, S, P.wall(Blocks.STONE_BRICKS), P.mat != null ? P.mat : Blocks.SMOOTH_STONE.getDefaultState(), true, true, false);
    }

    private static void arch(Plan P, int W) {
        int hw = W / 2, Hp = W;
        BlockState b = P.wall(Blocks.STONE_BRICKS), cobble = Blocks.COBBLESTONE.getDefaultState();
        for (int z = 0; z < 3; z++)
            for (int x = -hw - 3; x <= hw + 3; x++)
                for (int y = 0; y <= Hp + hw + 3; y++) {
                    boolean pillar = y < Hp && (Math.abs(x) >= hw && Math.abs(x) <= hw + 1);
                    double d = Math.hypot(x, y - Hp);
                    boolean ring = y >= Hp && d >= hw - 0.5 && d <= hw + 1.7;
                    if (pillar || ring) P.set(x, y, z, b);
                    if (y == 0 && pillar) P.found(x, z, cobble);
                }
    }

    private static void obelisk(Plan P, int H) {
        int b = Math.max(2, Math.min(5, H / 9));
        BlockState quartz = P.wall(Blocks.QUARTZ_BLOCK), gold = P.mat != null ? P.mat : Blocks.GOLD_BLOCK.getDefaultState(), step = Blocks.STONE_BRICKS.getDefaultState();
        int bw = b + 3;
        for (int x = -bw; x <= bw; x++) for (int z = -bw; z <= bw; z++) { P.set(x, -1, z, step); P.found(x, z, Blocks.COBBLESTONE.getDefaultState()); }
        for (int x = -bw + 1; x <= bw - 1; x++) for (int z = -bw + 1; z <= bw - 1; z++) P.set(x, 0, z, step);
        for (int y = 1; y < H; y++) {
            int half = Math.max(1, (int) Math.round(b - (b - 1) * y / (double) H));
            for (int x = -half; x <= half; x++) for (int z = -half; z <= half; z++) P.set(x, y, z, quartz);
        }
        for (int k = 0; k < 3; k++) {
            int half = Math.max(0, 1 - k);
            for (int x = -half; x <= half; x++) for (int z = -half; z <= half; z++) P.set(x, H + k, z, gold);
        }
    }

    private static void stairs(Plan P, int H) {
        BlockState step = P.mat != null ? P.mat : Blocks.STONE_BRICK_STAIRS.getDefaultState().with(StairsBlock.FACING, P.fwd);
        BlockState fence = Blocks.OAK_FENCE.getDefaultState(), base = P.wall(Blocks.STONE_BRICKS);
        for (int s = 0; s < H; s++) {
            for (int x = -2; x <= 2; x++) P.set(x, s, s, step);
            P.set(-3, s + 1, s, fence); P.set(3, s + 1, s, fence);
        }
        for (int x = -3; x <= 3; x++) for (int z = H; z <= H + 6; z++) P.set(x, H, z, base);   // площадка наверху
    }

    private static void lighthouse(Plan P, int H) {
        int R0 = Math.max(4, Math.min(8, H / 6)), R1 = Math.max(3, R0 - 2);
        BlockState body = P.wall(Blocks.STONE_BRICKS), cap = P.mat != null ? P.mat : Blocks.RED_NETHER_BRICKS.getDefaultState();
        BlockState glass = Blocks.GLASS.getDefaultState(), lamp = Blocks.SEA_LANTERN.getDefaultState(), cobble = Blocks.COBBLESTONE.getDefaultState();
        BlockState floorS = Blocks.SPRUCE_PLANKS.getDefaultState();
        for (int y = -1; y < H; y++) {
            double r = y < 0 ? R0 : R0 - (R0 - R1) * y / (double) H;
            for (int x = -R0; x <= R0; x++)
                for (int z = -R0; z <= R0; z++) {
                    double d = Math.hypot(x, z);
                    if (d > r + 0.3) continue;
                    if (y == -1) { P.set(x, -1, z, body); P.found(x, z, cobble); continue; }
                    boolean ring = d > r - 1.0;
                    if (!ring) { P.set(x, y, z, (y % 8 == 0 && y > 0) ? floorS : AIR); continue; }
                    boolean door = x == 0 && z < 0 && y <= 1;
                    boolean win = (y % 8 == 4 || y % 8 == 5) && y > 3 && ((x == 0 && Math.abs(z) >= 3) || (z == 0 && Math.abs(x) >= 3));
                    P.set(x, y, z, door ? AIR : win ? glass : body);
                }
        }
        int g = R1 + 2;
        for (int x = -g; x <= g; x++)                                   // галерея вокруг фонаря
            for (int z = -g; z <= g; z++) {
                double d = Math.hypot(x, z);
                if (d <= g + 0.3) P.set(x, H - 1, z, cap);
                if (d <= g + 0.3 && d > g - 0.7) P.set(x, H, z, cap);
            }
        int rl = Math.max(2, R1 - 1);
        for (int y = H; y < H + 3; y++)                                  // стеклянная комната с огнём
            for (int x = -rl; x <= rl; x++)
                for (int z = -rl; z <= rl; z++) {
                    double d = Math.hypot(x, z);
                    if (d <= rl + 0.3 && d > rl - 1.0) P.set(x, y, z, glass);
                }
        P.set(0, H, 0, lamp); P.set(0, H + 1, 0, lamp);
        for (int k = 0; k <= rl + 1; k++) {                              // красная крыша-конус
            double r2 = rl + 1 - k;
            for (int x = -rl - 1; x <= rl + 1; x++)
                for (int z = -rl - 1; z <= rl + 1; z++) if (Math.hypot(x, z) <= r2 + 0.3) P.set(x, H + 3 + k, z, cap);
        }
    }

    private WishBuild() {}
}
