package com.example.fxmod.wish;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.boss.dragon.phase.PhaseType;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/** Исполнение действий, которые разобрал WishText. */
public final class WishExec {
    private static final Random RNG = new Random();
    private static final Set<EntityType<?>> FLYERS = new HashSet<>(Arrays.asList(
            EntityType.ENDER_DRAGON, EntityType.GHAST, EntityType.PHANTOM, EntityType.BAT, EntityType.BLAZE, EntityType.ALLAY,
            EntityType.VEX, EntityType.PARROT, EntityType.BEE, EntityType.WITHER));

    public static List<String> run(ServerPlayerEntity p, WishText.Result res) {
        List<String> out = new ArrayList<>();
        MinecraftServer server = p.getServer();
        for (WishText.Action a : res.actions) {
            try {
                String line = null;
                switch (a.type) {
                    case "BLOCKS": line = blocks(server, a); break;
                    case "SUMMON": line = summon(p, a); break;
                    case "KILL": line = kill(server, p, a); break;
                    case "TRANSFORM": line = transform(server, p, a); break;
                    case "GIVE": line = give(p, a); break;
                    case "TIME": line = time(p, a); break;
                    case "WEATHER": line = weather(p, a); break;
                    case "HEAL": line = heal(p); break;
                    case "GOD": line = god(p); break;
                    case "FLY": line = fly(p); break;
                    case "EFFECT": line = effect(p, a); break;
                    case "BUILD": line = build(p, a); break;
                    case "CMD": line = command(p, a); break;
                    case "REWIND": line = WishRewind.start(p, a.a); break;
                    case "WORLD_DELETE": line = WorldDelete.schedule(server); break;
                    default: break;
                }
                if (line != null) out.add(line);
            } catch (Exception ex) {
                out.add("Не удалось исполнить: " + a.type);
            }
        }
        return out;
    }

    /** Любая команда игры с правами оператора (в одиночной игре или для оператора на сервере). */
    public static boolean canRunCommands(ServerPlayerEntity p) {
        return p.getServer().isSingleplayer() || p.hasPermissionLevel(2);
    }

    private static String command(ServerPlayerEntity p, WishText.Action a) {
        if (!canRunCommands(p)) return "Команды доступны только операторам сервера";
        String c = a.a.trim();
        if (c.startsWith("/")) c = c.substring(1);
        if (c.isEmpty()) return null;
        p.getServer().getCommandManager().executeWithPrefix(p.getCommandSource().withLevel(4), c);
        return "Команда выполнена: /" + c;
    }

    private static String build(ServerPlayerEntity p, WishText.Action a) {
        WishBuild.Prepared pr = WishBuild.take(p, a);
        if (pr == null) return "Не удалось построить: нет места или слишком большая постройка";
        WishBuild.start(pr);
        return "Строится: " + pr.name + " (" + pr.count + " блоков)";
    }

    // ---------- блоки ----------
    private static String blocks(MinecraftServer server, WishText.Action a) {
        boolean ok = WishRules.addRule(server, a.a, a.b);
        if (!ok) return "Не нашёл такой блок";
        return "Мир изменён: " + shortName(a.a) + " → " + shortName(a.b) + " (и в новых землях тоже)";
    }

    private static String shortName(String ids) {
        String first = ids.split(",")[0];
        int i = first.indexOf(':');
        String s = i >= 0 ? first.substring(i + 1) : first;
        return s.replace('_', ' ') + (ids.contains(",") ? " и др." : "");
    }

    // ---------- существа ----------
    private static List<Entity> find(MinecraftServer server, PlayerEntity owner, String spec) {
        List<Entity> list = new ArrayList<>();
        for (ServerWorld sw : server.getWorlds()) {
            for (Entity e : sw.iterateEntities()) {
                if (e == owner || e instanceof PlayerEntity || !e.isAlive()) continue;
                boolean ok;
                if (spec.startsWith("cat:")) {
                    String c = spec.substring(4);
                    ok = c.equals("hostile") ? (e instanceof HostileEntity || e instanceof Monster)
                            : c.equals("animals") ? e instanceof AnimalEntity
                            : e instanceof MobEntity;
                } else {
                    ok = Registries.ENTITY_TYPE.getId(e.getType()).toString().equals(spec.substring(7));
                }
                if (ok) list.add(e);
            }
        }
        return list;
    }

    private static String kill(MinecraftServer server, ServerPlayerEntity p, WishText.Action a) {
        List<Entity> list = find(server, p, a.a);
        for (Entity e : list) {
            ServerWorld w = (ServerWorld) e.getWorld();
            w.spawnParticles(ParticleTypes.POOF, e.getX(), e.getY() + e.getHeight() / 2, e.getZ(), 20, 0.4, 0.6, 0.4, 0.05);
            if (a.n == 2) { e.setOnFireFor(30); continue; }
            if (a.n == 1) { EntityJournal.record(e); e.discard(); continue; }
            if (e instanceof EnderDragonEntity d) {
                d.setHealth(1f);
                d.getPhaseManager().setPhase(PhaseType.DYING);
            } else {
                if (e instanceof LivingEntity le) le.damage(w.getDamageSources().indirectMagic(p, p), 1000f);
                if (e.isAlive()) e.kill();
            }
        }
        String what = a.a.startsWith("cat:") ? a.a.substring(4) : a.a.substring(7).replace("minecraft:", "").replace('_', ' ');
        return (a.n == 2 ? "Подожжено: " : a.n == 1 ? "Исчезло: " : "Уничтожено: ") + list.size() + " (" + what + ")";
    }

    private static String transform(MinecraftServer server, ServerPlayerEntity p, WishText.Action a) {
        Identifier tid = Identifier.tryParse(a.b);
        if (tid == null) return null;
        EntityType<?> to = Registries.ENTITY_TYPE.get(tid);
        List<Entity> list = find(server, p, a.a);
        int n = 0;
        for (Entity e : list) {
            ServerWorld w = (ServerWorld) e.getWorld();
            Entity ne = to.create(w);
            if (ne == null) continue;
            ne.refreshPositionAndAngles(e.getX(), e.getY(), e.getZ(), e.getYaw(), e.getPitch());
            if (ne instanceof MobEntity m) m.initialize(w, w.getLocalDifficulty(e.getBlockPos()), SpawnReason.COMMAND, null, null);
            e.discard();
            w.spawnEntityAndPassengers(ne);
            w.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, ne.getX(), ne.getY() + 1, ne.getZ(), 25, 0.4, 0.8, 0.4, 0.3);
            n++;
        }
        return "Превращено: " + n;
    }

    private static String summon(ServerPlayerEntity p, WishText.Action a) {
        Identifier id = Identifier.tryParse(a.a);
        if (id == null) return null;
        EntityType<?> type = Registries.ENTITY_TYPE.get(id);
        ServerWorld w = p.getServerWorld();
        int n = Math.max(1, Math.min(100, a.n));
        Vec3d look = p.getRotationVec(1f);
        Vec3d fwd = new Vec3d(look.x, 0, look.z);
        fwd = fwd.lengthSquared() < 1.0E-4 ? new Vec3d(0, 0, 1) : fwd.normalize();
        int made = 0;
        for (int i = 0; i < n; i++) {
            double dist = (type == EntityType.ENDER_DRAGON ? 25 : 8) + (n > 1 ? RNG.nextDouble() * 6 : 0);
            double side = n > 1 ? (RNG.nextDouble() - 0.5) * 12 : 0;
            double x = p.getX() + fwd.x * dist - fwd.z * side, z = p.getZ() + fwd.z * dist + fwd.x * side;
            double y;
            if (type == EntityType.LIGHTNING_BOLT) y = w.getTopY(Heightmap.Type.WORLD_SURFACE, (int) Math.floor(x), (int) Math.floor(z));
            else if (FLYERS.contains(type)) y = p.getY() + (type == EntityType.ENDER_DRAGON ? 18 : 6);
            else y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int) Math.floor(x), (int) Math.floor(z));
            if (!w.isChunkLoaded(new BlockPos((int) Math.floor(x), (int) p.getY(), (int) Math.floor(z)))) continue;
            Entity e = type.create(w);
            if (e == null) continue;
            e.refreshPositionAndAngles(x, y, z, p.getYaw() + 180f, 0f);
            if (e instanceof LightningEntity) { w.spawnEntity(e); made++; continue; }
            if (e instanceof MobEntity m) {
                m.initialize(w, w.getLocalDifficulty(BlockPos.ofFloored(x, y, z)), SpawnReason.COMMAND, null, null);
                if (n <= 30) m.setPersistent();
            }
            w.spawnEntityAndPassengers(e);
            w.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, x, y + 1, z, 20, 0.4, 0.8, 0.4, 0.3);
            made++;
        }
        return "Появилось: " + made + " (" + a.a.replace("minecraft:", "").replace('_', ' ') + ")";
    }

    // ---------- предметы ----------
    private static String give(ServerPlayerEntity p, WishText.Action a) {
        Identifier id = Identifier.tryParse(a.a);
        if (id == null) return null;
        Item item = Registries.ITEM.get(id);
        if (item == net.minecraft.item.Items.AIR) return null;
        int left = Math.max(1, Math.min(2304, a.n)), total = left;
        while (left > 0) {
            int c = Math.min(left, item.getMaxCount());
            p.getInventory().offerOrDrop(new ItemStack(item, c));
            left -= c;
        }
        return "Получено: " + total + " × " + a.a.replace("minecraft:", "").replace('_', ' ');
    }

    // ---------- мир ----------
    private static String time(ServerPlayerEntity p, WishText.Action a) {
        long target;
        switch (a.a) {
            case "sunrise": target = 23000; break;
            case "noon": target = 6000; break;
            case "sunset": target = 12000; break;
            case "night": target = 13000; break;
            case "midnight": target = 18000; break;
            default: target = 1000; break;
        }
        ServerWorld w = p.getServerWorld();
        long now = w.getTimeOfDay();
        w.setTimeOfDay(now - Math.floorMod(now, 24000L) + target);
        return "Время изменено: " + a.a;
    }

    private static String weather(ServerPlayerEntity p, WishText.Action a) {
        ServerWorld w = p.getServerWorld();
        if (a.a.equals("clear")) w.setWeather(12000 * 3, 0, false, false);
        else if (a.a.equals("thunder")) w.setWeather(0, 12000, true, true);
        else w.setWeather(0, 12000, true, false);
        return "Погода изменена: " + a.a;
    }

    // ---------- игрок ----------
    private static String heal(ServerPlayerEntity p) {
        p.setHealth(p.getMaxHealth());
        p.getHungerManager().setFoodLevel(20);
        p.getHungerManager().setSaturationLevel(20f);
        p.extinguish();
        p.clearStatusEffects();
        return "Ты исцелён и сыт";
    }

    private static String god(ServerPlayerEntity p) {
        int t = 20 * 60 * 10;
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, t, 4));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, t, 3));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, t, 0));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SATURATION, t, 0));
        return "Неуязвимость на 10 минут";
    }

    private static String fly(ServerPlayerEntity p) {
        p.getAbilities().allowFlying = true;
        p.sendAbilitiesUpdate();
        return "Теперь ты можешь летать (дважды нажми прыжок)";
    }

    private static String effect(ServerPlayerEntity p, WishText.Action a) {
        Identifier id = Identifier.tryParse(a.a);
        if (id == null) return null;
        StatusEffect e = Registries.STATUS_EFFECT.get(id);
        if (e == null) return null;
        int amp = 1;
        try { amp = Integer.parseInt(a.b); } catch (Exception ignore) { }
        p.addStatusEffect(new StatusEffectInstance(e, Math.max(1, a.n) * 20, amp));
        return "Эффект: " + a.a.replace("minecraft:", "").replace('_', ' ');
    }

    private WishExec() {}
}
