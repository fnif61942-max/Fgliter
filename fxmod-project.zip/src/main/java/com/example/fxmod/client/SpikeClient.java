package com.example.fxmod.client;

import com.example.fxmod.FxMod;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/** Клиент способности «Шипы»: клавиша G, поза удара ногой (видна всем) и кинокамера для владельца. */
public final class SpikeClient {
    private static KeyBinding KEY;
    private static final Map<Integer, Long> STOMPS = new HashMap<>();
    private static boolean cine;
    private static double clock;
    private static Vec3d O = Vec3d.ZERO, F = new Vec3d(0, 0, 1), R = new Vec3d(-1, 0, 0);

    public static void init() {
        KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.fxmod.spikes", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.fxmod"));
        ClientPlayNetworking.registerGlobalReceiver(FxMod.STOMP_PACKET, (client, handler, buf, sender) -> {
            int id = buf.readInt();
            Vec3d o = new Vec3d(buf.readDouble(), buf.readDouble(), buf.readDouble());
            double fx = buf.readDouble(), fz = buf.readDouble();
            client.execute(() -> onStomp(client, id, o, fx, fz));
        });
        ClientTickEvents.END_CLIENT_TICK.register(SpikeClient::tick);
    }

    private static void onStomp(MinecraftClient mc, int id, Vec3d o, double fx, double fz) {
        STOMPS.put(id, System.nanoTime());
        if (mc.player != null && mc.player.getId() == id) {
            cine = true; clock = 0; O = o; F = new Vec3d(fx, 0, fz); R = new Vec3d(-fz, 0, fx);
        }
    }

    private static void tick(MinecraftClient mc) {
        long n = System.nanoTime();
        Iterator<Map.Entry<Integer, Long>> it = STOMPS.entrySet().iterator();
        while (it.hasNext()) if ((n - it.next().getValue()) / 50_000_000.0 > 26) it.remove();

        if (cine) {
            clock += 1;
            if (clock >= 110 || mc.player == null || mc.world == null) cine = false;
        }
        if (mc.player != null && mc.world != null && mc.currentScreen == null) {
            while (KEY.wasPressed()) ClientPlayNetworking.send(FxMod.SPIKES_PACKET, PacketByteBufs.create());
        }
    }

    private static double smooth(double x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
    private static double lerp(double a, double b, double t) { return a + (b - a) * t; }

    /** Поза: {правая нога, левая нога, руки, корпус, голова} или null. Тайминг: замах 10 тиков, удар, восстановление. */
    public static float[] pose(int entityId) {
        Long st = STOMPS.get(entityId);
        if (st == null) return null;
        double a = (System.nanoTime() - st) / 50_000_000.0;
        if (a > 24) return null;
        double legR, legL, arm, body, head;
        if (a < 10) {                       // замах: нога вверх, руки вверх, откинуться назад
            double k = smooth(a / 10.0);
            legR = -1.75 * k; legL = 0.25 * k; arm = -2.7 * k; body = -0.15 * k; head = -0.1 * k;
        } else if (a < 13.5) {              // удар: нога вниз, руки вниз, корпус вперёд
            double q = smooth((a - 10) / 3.5);
            legR = lerp(-1.75, 0.55, q); legL = lerp(0.25, -0.1, q); arm = lerp(-2.7, 0.9, q);
            body = lerp(-0.15, 0.35, q); head = lerp(-0.1, 0.3, q);
        } else {                            // восстановление
            double q = smooth((a - 13.5) / 9.0);
            legR = lerp(0.55, 0, q); legL = lerp(-0.1, 0, q); arm = lerp(0.9, 0, q);
            body = lerp(0.35, 0, q); head = lerp(0.3, 0, q);
        }
        return new float[]{(float) legR, (float) legL, (float) arm, (float) body, (float) head};
    }

    /** Кинокамера: у ноги → над плечом за спиной вдоль волны → вид сбоку на всё поле. Возвращает {x,y,z,yaw,pitch} или null. */
    public static double[] compute(float td) {
        if (!cine) return null;
        double T = clock + td;
        Vec3d C = O.add(0, 1.2, 0);
        Vec3d pos, look;

        Vec3d pos2 = O.subtract(F.multiply(7)).add(R.multiply(2.5)).add(0, 5.5, 0);
        Vec3d pos3 = O.add(F.multiply(25)).add(R.multiply(34)).add(0, 18, 0);
        Vec3d look3 = O.add(F.multiply(25)).add(0, 14, 0);

        if (T < 14) {
            pos = pos1(T); look = C;
        } else if (T < 60) {
            double b = smooth((T - 14) / 16.0);
            pos = pos1(14).lerp(pos2, b);
            look = C.lerp(look2(T), b);
        } else {
            double b = smooth((T - 60) / 25.0);
            pos = pos2.lerp(pos3, b);
            look = look2(60).lerp(look3, b);
        }
        if (T >= 10 && T < 26) { // тряска при ударе
            double sh = 0.6 * (1 - (T - 10) / 16.0);
            pos = pos.add((Math.random() - 0.5) * sh, (Math.random() - 0.5) * sh, (Math.random() - 0.5) * sh);
        }
        Vec3d f = look.subtract(pos);
        double yaw = Math.toDegrees(Math.atan2(-f.x, f.z));
        double pitch = -Math.toDegrees(Math.atan2(f.y, Math.sqrt(f.x * f.x + f.z * f.z)));
        return new double[]{pos.x, pos.y, pos.z, yaw, pitch};
    }

    private static Vec3d pos1(double T) {
        double k = smooth(Math.min(T, 12) / 12.0);
        double dist = 5.0 - 1.8 * k;
        return O.add(F.multiply(dist * 0.85)).add(R.multiply(dist * 0.5)).add(0, 1.0 + 0.3 * k, 0);
    }

    private static Vec3d look2(double T) {
        double ws = Math.max(6, Math.min(50, (T - 10) * 3));
        return O.add(F.multiply(ws)).add(0, 8, 0);
    }

    private SpikeClient() {}
}
