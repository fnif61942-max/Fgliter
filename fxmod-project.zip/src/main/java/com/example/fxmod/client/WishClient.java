package com.example.fxmod.client;

import com.example.fxmod.ChronoWishItem;
import com.example.fxmod.FxMod;
import com.example.fxmod.wish.Wishes;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/** Клиент «Хроно желания»: окно ввода, поза с поднятыми руками, кинокамера с «долли-зумом» и вспышкой FOV. */
public final class WishClient {
    private static boolean cine;
    private static double clock;
    private static Vec3d O = Vec3d.ZERO, buildC = null;
    private static double buildH, buildExt;
    private static int endT = Wishes.T_END;
    private static final Map<Integer, Long> CASTS = new HashMap<>();

    public static boolean cineActive() { return cine; }

    public static void init() {
        ChronoWishItem.OPEN_SCREEN = () -> MinecraftClient.getInstance().setScreen(new WishScreen());
        ClientPlayNetworking.registerGlobalReceiver(FxMod.WISH_START, (client, handler, buf, sender) -> {
            int id = buf.readInt();
            Vec3d o = new Vec3d(buf.readDouble(), buf.readDouble(), buf.readDouble());
            boolean hb = buf.readBoolean();
            Vec3d bc = hb ? new Vec3d(buf.readDouble(), buf.readDouble(), buf.readDouble()) : null;
            double bh = hb ? buf.readDouble() : 0, be = hb ? buf.readDouble() : 0;
            int end = buf.readInt();
            client.execute(() -> onStart(client, id, o, bc, bh, be, end));
        });
        ClientTickEvents.END_CLIENT_TICK.register(WishClient::tick);
    }

    private static void onStart(MinecraftClient mc, int id, Vec3d o, Vec3d bc, double bh, double be, int end) {
        CASTS.put(id, System.nanoTime());
        if (mc.player != null && mc.player.getId() == id) { cine = true; clock = 0; O = o; buildC = bc; buildH = bh; buildExt = be; endT = end; }
    }

    private static void tick(MinecraftClient mc) {
        long n = System.nanoTime();
        Iterator<Map.Entry<Integer, Long>> it = CASTS.entrySet().iterator();
        while (it.hasNext()) if ((n - it.next().getValue()) / 50_000_000.0 > 280) it.remove();
        if (cine) {
            clock += 1;
            if (clock >= endT + 5 || mc.player == null || mc.world == null) cine = false;
        }
    }

    private static double smooth(double x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
    private static double lerp(double a, double b, double t) { return a + (b - a) * t; }

    /** Поза: {руки pitch, голова pitch}. Руки к небу до исполнения желания. */
    public static float[] pose(int entityId) {
        Long st = CASTS.get(entityId);
        if (st == null) return null;
        double a = (System.nanoTime() - st) / 50_000_000.0;
        if (a > Wishes.T_BUILD + 30) return null;
        double arm, head;
        if (a < 15) { double k = smooth(a / 15.0); arm = -2.9 * k; head = -0.4 * k; }
        else if (a < Wishes.T_BUILD) { arm = -2.9 + 0.08 * Math.sin(a * 0.4); head = -0.4; }
        else { double q = smooth((a - Wishes.T_BUILD) / 15.0); arm = lerp(-2.9, 0, q); head = lerp(-0.4, 0, q); }
        return new float[]{(float) arm, (float) head};
    }

    private static double phi30() { return 0.5 + 0.05 * 30 + 0.0012 * 900; }
    private static double phi60() { double k = 30; return phi30() + 0.09 * k + 0.0015 * k * k; }

    /** Возвращает {x,y,z,yaw,pitch} или null. */
    public static double[] compute(float td) {
        if (!cine) return null;
        double T = clock + td;
        Vec3d C = O.add(0, 1.4, 0);
        Vec3d pos, look;
        if (T < 30) {                                    // низкий облёт вокруг героя
            double ph = 0.5 + 0.05 * T + 0.0012 * T * T;
            pos = O.add(Math.cos(ph) * 7, 1.5 + 0.02 * T, Math.sin(ph) * 7);
            look = C;
        } else if (T < 60) {                             // спираль вверх, взгляд поднимается к шару
            double s = smooth((T - 30) / 30.0), k = T - 30;
            double ph = phi30() + 0.09 * k + 0.0015 * k * k;
            double r = 7 + 7 * s;
            pos = O.add(Math.cos(ph) * r, 2.1 + 8 * s, Math.sin(ph) * r);
            look = C.lerp(O.add(0, Wishes.APEX * 0.6, 0), s);
        } else if (T < Wishes.T_BUILD) {                 // долли-зум: камера отъезжает, угол обзора сужается
            double s = smooth((T - 60) / 30.0);
            double d = 14 + 30 * s;
            pos = O.add(Math.cos(phi60()) * d, 10.1 + 4 * s, Math.sin(phi60()) * d);
            look = C.lerp(O.add(0, 18, 0), 0.6);
        } else if (buildC != null) {                     // после вспышки камера смотрит, как растёт постройка
            double k = T - Wishes.T_BUILD;
            Vec3d axis = new Vec3d(buildC.x - O.x, 0, buildC.z - O.z);
            axis = axis.lengthSquared() < 1.0E-6 ? new Vec3d(1, 0, 0) : axis.normalize();
            Vec3d side = new Vec3d(-axis.z, 0, axis.x);
            double Dd = Math.max(40, buildExt * 1.6 + buildH * 0.8), ang = k * 0.004;
            Vec3d off = side.multiply(Math.cos(ang) * Dd).add(axis.multiply(-Math.sin(ang) * Dd * 0.6 - Dd * 0.3));
            pos = buildC.add(off).add(0, buildH * 0.55 + 12, 0);
            look = buildC.add(0, buildH * 0.45, 0);
        } else {                                         // монтажная склейка: общий план после вспышки
            double k = T - Wishes.T_BUILD;
            double ph = phi60() + 0.012 * k;
            pos = O.add(Math.cos(ph) * 40, 24 + 0.1 * k, Math.sin(ph) * 40);
            look = O.add(0, 6 + 0.1 * k, 0);
        }
        double sh = 0;
        if (T >= Wishes.T_BUILD) sh = 2.0 * Math.exp(-(T - Wishes.T_BUILD) / 10.0);          // тряска от вспышки
        else if (T > 40) sh = 0.04 + 0.2 * smooth((T - 40) / 50.0);                           // дрожь нарастает
        if (sh > 0) pos = pos.add((Math.random() - 0.5) * sh, (Math.random() - 0.5) * sh, (Math.random() - 0.5) * sh);

        Vec3d f = look.subtract(pos);
        double yaw = Math.toDegrees(Math.atan2(-f.x, f.z));
        double pitch = -Math.toDegrees(Math.atan2(f.y, Math.sqrt(f.x * f.x + f.z * f.z)));
        return new double[]{pos.x, pos.y, pos.z, yaw, pitch};
    }

    /** Множитель FOV: сужение при долли-зуме и резкий «выброс» на вспышке. */
    public static double fovFactor(float td) {
        if (!cine) return 1.0;
        double T = clock + td;
        if (T >= 60 && T < Wishes.T_BUILD) return 14.0 / (14 + 30 * smooth((T - 60) / 30.0));
        if (T >= Wishes.T_BUILD) return 1.0 + 0.35 * Math.exp(-(T - Wishes.T_BUILD) / 6.0);
        return 1.0;
    }

    private WishClient() {}
}
