package com.example.fxmod.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;

/** На время кинокамеры переключает вид на третье лицо: пропадают рука и прицел, игрок виден целиком. */
public final class CinematicView {
    private static boolean was = false;
    private static Perspective saved = Perspective.FIRST_PERSON;

    public static void tick(MinecraftClient mc) {
        boolean active = mc.player != null && (FugaCinematic.active() || SpikeClient.cineActive());
        if (active && !was) {
            saved = mc.options.getPerspective();
            mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        } else if (!active && was) {
            mc.options.setPerspective(saved);
        }
        was = active;
    }

    private CinematicView() {}
}
