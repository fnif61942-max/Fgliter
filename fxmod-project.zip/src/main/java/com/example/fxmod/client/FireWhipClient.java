package com.example.fxmod.client;

import com.example.fxmod.FxMod;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;

/** Клиент: ловит удар (ЛКМ), чередует левую/правую руку, запускает анимацию и шлёт серверу пакет хлыста. */
public final class FireWhipClient {
    private static boolean useOff = false;
    private static int cooldown = 0, whipTicks = 0;

    public static boolean isWhipping() { return whipTicks > 0; }

    public static void init() {
        ClientTickEvents.START_CLIENT_TICK.register(FireWhipClient::onTick);
    }

    private static void onTick(MinecraftClient mc) {
        if (cooldown > 0) cooldown--;
        if (whipTicks > 0) whipTicks--;

        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null || p.isSpectator() || p.isUsingItem()) return;
        if (!(p.getMainHandStack().isEmpty() || p.getMainHandStack().isOf(FxMod.FUGA))) return;
        // если смотришь на ближний блок — обычное поведение (ломать блоки)
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK) return;

        boolean pressed = false;
        while (mc.options.attackKey.wasPressed()) pressed = true;
        if (!pressed && !mc.options.attackKey.isPressed()) return;
        if (cooldown > 0) return;

        useOff = !useOff;
        p.swingHand(useOff ? Hand.OFF_HAND : Hand.MAIN_HAND);
        whipTicks = 8;
        cooldown = 7;

        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeBoolean(useOff);
        ClientPlayNetworking.send(FxMod.WHIP_PACKET, buf);
    }

    private FireWhipClient() {}
}
