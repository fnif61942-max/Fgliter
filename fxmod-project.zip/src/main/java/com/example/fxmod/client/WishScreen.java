package com.example.fxmod.client;

import com.example.fxmod.FxMod;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;

/** Окно «Хроно желания»: иконка и поле для текста — пиши любое желание на любом языке. */
public class WishScreen extends Screen {
    private TextFieldWidget field;
    private final ItemStack icon = new ItemStack(FxMod.CHRONO_WISH);

    public WishScreen() { super(Text.literal("хроно-желание")); }

    @Override
    protected void init() {
        int cx = this.width / 2, cy = this.height / 2;
        field = new TextFieldWidget(this.textRenderer, cx - 160, cy + 14, 320, 20, Text.literal("Желание"));
        field.setMaxLength(200);
        this.addDrawableChild(field);
        this.setInitialFocus(field);
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Загадать"), b -> submit()).dimensions(cx - 162, cy + 42, 160, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Отмена"), b -> this.close()).dimensions(cx + 2, cy + 42, 160, 20).build());
    }

    private void submit() {
        String t = field.getText().trim();
        if (t.isEmpty()) return;
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeString(t, 256);
        ClientPlayNetworking.send(FxMod.WISH_PACKET, buf);
        this.close();
    }

    @Override
    public boolean keyPressed(int key, int scancode, int mods) {
        if (key == 257 || key == 335) { submit(); return true; }   // Enter
        return super.keyPressed(key, scancode, mods);
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx);
        int cx = this.width / 2, cy = this.height / 2;
        double t = (System.currentTimeMillis() % 100000) / 1000.0;
        float pulse = 1.0f + 0.06f * (float) Math.sin(t * 3.0);

        MatrixStack m = ctx.getMatrices();       // большая пульсирующая иконка
        m.push();
        m.translate(cx, cy - 62, 0);
        m.scale(6f * pulse, 6f * pulse, 1f);
        m.translate(-8, -8, 0);
        ctx.drawItem(icon, 0, 0);
        m.pop();

        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("хроно-желание").formatted(net.minecraft.util.Formatting.GOLD, net.minecraft.util.Formatting.BOLD), cx, cy - 12, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Напиши любое желание на любом языке"), cx, cy, 0xDDDDDD);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Примеры: удали всю траву • Эндер дракон • построй замок из золота • отмотай время назад • сделай ночь"), cx, cy + 72, 0x999999);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("После исполнения предмет исчезнет"), cx, cy + 86, 0x777777);
        super.render(ctx, mouseX, mouseY, delta);
    }
}
