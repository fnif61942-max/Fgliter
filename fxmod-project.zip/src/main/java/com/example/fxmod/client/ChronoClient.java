package com.example.fxmod.client;

import com.example.fxmod.Chronos;
import com.example.fxmod.FxMod;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/** Клиент «Хроноса»: клавиша V, поза мага (руки к небу) и кинокамера. */
public final class ChronoClient {
    private static KeyBinding KEY;
    private static final Map<Integer, Long> CASTS = new HashMap<>();
    private static boolean cine;
    private static double clock;
    private static Vec3d O = Vec3d.ZERO, F = new Vec3d(0, 0, 1), R = new Vec3d(-1, 0, 0), Cc = Vec3d.ZERO;

    public static boolean cineActive() { return cine; }

    public static void init() {
        KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.fxmod.chrono", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.fxmod"));
        ClientPlayNetworking.registerGlobalReceiver(FxMod.CHRONO_START, (client, handler, buf, sender) -> {
            int id = buf.readInt();
            Vec3d o = new Vec3d(buf.readDouble(), buf.readDouble(), buf.readDouble());
            double fx = buf.readDouble(), fz = buf.readDouble();
            client.execute(() -> onStart(client, id, o, fx, fz));
        });
        ClientTickEvents.END_CLIENT_TICK.register(ChronoClient::tick);
    }

    private static void onStart(MinecraftClient mc, int id, Vec3d o, double fx, double fz) {
        CASTS.put(id, System.nanoTime());
        if (mc.player != null && mc.player.getId() == id) {
            cine = true; clock = 0; O = o; F = new Vec3d(fx, 0, fz); R = new Vec3d(-fz, 0, fx);
            Cc = o.subtract(F.multiply(Chronos.CLOCK_DIST)).add(0, Chronos.CLOCK_Y, 0);
        }
    }

    private static void tick(MinecraftClient mc) {
        long n = System.nanoTime();
        Iterator<Map.Entry<Integer, Long>> it = CASTS.entrySet().iterator();
        while (it.hasNext()) if ((n - it.next().getValue()) / 50_000_000.0 > Chronos.T_END + 20) it.remove();

        if (cine) {
            clock += 1;
            if (clock >= Chronos.T_END + 5 || mc.player == null || mc.world == null) cine = false;
        }
        if (mc.player != null && mc.world != null && mc.currentScreen == null) {
            while (KEY.wasPressed()) ClientPlayNetworking.send(FxMod.CHRONO_PACKET, PacketByteBufs.create());
        }
    }

    private static double smooth(double x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
    private static double lerp(double a, double b, double t) { return a + (b - a) * t; }

    /** Поза мага: {руки pitch, руки roll, голова pitch}. Руки к небу, пока идёт заклинание, и удар вниз на волне. */
    public static float[] pose(int entityId) {
        Long st = CASTS.get(entityId);
        if (st == null) return null;
        double a = (System.nanoTime() - st) / 50_000_000.0;
        if (a > Chronos.T_WAVE + 30) return null;
        double arm, roll, head;
        if (a < 20) {
            double k = smooth(a / 20.0);
            arm = -2.9 * k; roll = 0.35 * k; head = -0.35 * k;
        } else if (a < Chronos.T_WAVE) {
            arm = -2.9 + 0.1 * Math.sin(a * 0.3); roll = 0.35; head = -0.35;
        } else if (a < Chronos.T_WAVE + 10) {
            double q = smooth((a - Chronos.T_WAVE) / 10.0);
            arm = lerp(-2.9, 0.6, q); roll = lerp(0.35, 0, q); head = lerp(-0.35, 0.3, q);
        } else {
            double q = smooth((a - Chronos.T_WAVE - 10) / 20.0);
            arm = lerp(0.6, 0, q); roll = 0; head = lerp(0.3, 0, q);
        }
        return new float[]{(float) arm, (float) roll, (float) head};
    }

    private static Vec3d A() { return R.multiply(-1); }   // «вправо» для того, кто смотрит на циферблат

    // --- ключевые кадры ---
    private static Vec3d chest() { return O.add(0, 1.4, 0); }

    private static Vec3d posA(double T) {                    // 0..40: перед игроком, часы появляются за его спиной
        double k = smooth(T / Chronos.T_SUMMON);
        return O.add(F.multiply(12 - 3 * k)).add(0, 2.2 + 0.8 * k, 0);
    }
    private static Vec3d lookA(double T) {
        return chest().lerp(Cc, 0.45 * smooth(T / Chronos.T_SUMMON));
    }
    private static Vec3d posB(double T) {                    // 40..100: медленно уходим вбок
        double s = smooth((T - Chronos.T_SUMMON) / Chronos.T_FORWARD);
        return O.add(F.multiply(9 + 6 * s)).add(A().multiply(8 * s)).add(0, 3 + 2 * s, 0);
    }
    private static Vec3d lookB(double T) {
        double s = smooth((T - Chronos.T_SUMMON) / Chronos.T_FORWARD);
        return lookA(Chronos.T_SUMMON).lerp(Cc.lerp(chest(), 0.25), s);
    }
    private static Vec3d mid() { return O.add(Cc).multiply(0.5); }
    private static Vec3d posC(double T) {                    // 100..260: орбита вокруг героя и часов, всё быстрее
        int k0 = Chronos.T_SUMMON + Chronos.T_FORWARD;
        Vec3d p0 = posB(k0), m = mid();
        double vx = p0.x - m.x, vz = p0.z - m.z, r0 = Math.hypot(vx, vz), phi0 = Math.atan2(vz, vx);
        double k = Math.max(0, Math.min(Chronos.T_BACK, T - k0));
        double phi = phi0 + (0.004 * k + 0.00022 * k * k);
        double r = r0 + 0.12 * k;
        return new Vec3d(m.x + Math.cos(phi) * r, p0.y + 0.04 * k, m.z + Math.sin(phi) * r);
    }
    private static Vec3d lookC(double T) {
        int k0 = Chronos.T_SUMMON + Chronos.T_FORWARD;
        double k = Math.max(0, Math.min(Chronos.T_BACK, T - k0));
        return lookB(k0).lerp(mid().add(0, 7, 0), smooth(k / 30.0));
    }

    /** Возвращает {x,y,z,yaw,pitch} или null. */
    public static double[] compute(float td) {
        if (!cine) return null;
        double T = clock + td;
        int k0 = Chronos.T_SUMMON + Chronos.T_FORWARD;
        Vec3d pos, look;
        if (T < Chronos.T_SUMMON) { pos = posA(T); look = lookA(T); }
        else if (T < k0) { pos = posB(T); look = lookB(T); }
        else if (T < Chronos.T_WAVE) { pos = posC(T); look = lookC(T); }
        else {                                               // волна: камера уходит на общий план и смотрит на часы
            double b = smooth((T - Chronos.T_WAVE) / 40.0);
            Vec3d W = Cc.add(F.multiply(70)).add(A().multiply(25)).add(0, 20, 0);
            pos = posC(Chronos.T_WAVE).lerp(W, b);
            look = lookC(Chronos.T_WAVE).lerp(Cc.add(0, -4, 0), b);
        }
        double sh = 0;
        if (T >= Chronos.T_WAVE && T < Chronos.T_WAVE + 25) sh = 1.2 * (1 - (T - Chronos.T_WAVE) / 25.0);
        if (T > k0 && T < Chronos.T_WAVE) sh = 0.05 + 0.25 * smooth((T - k0) / Chronos.T_BACK);   // дрожь нарастает вместе с ускорением
        if (sh > 0) pos = pos.add((Math.random() - 0.5) * sh, (Math.random() - 0.5) * sh, (Math.random() - 0.5) * sh);

        Vec3d f = look.subtract(pos);
        double yaw = Math.toDegrees(Math.atan2(-f.x, f.z));
        double pitch = -Math.toDegrees(Math.atan2(f.y, Math.sqrt(f.x * f.x + f.z * f.z)));
        return new double[]{pos.x, pos.y, pos.z, yaw, pitch};
    }

    private ChronoClient() {}
}
