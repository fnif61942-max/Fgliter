package com.example.fxmod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** «Хроно желание»: ПКМ открывает окно ввода желания (на клиенте), дальше всё делает сервер. Предмет расходуется. */
public class ChronoWishItem extends Item {
    /** Устанавливается клиентом: открывает экран ввода (чтобы общий код не ссылался на клиентские классы). */
    public static Runnable OPEN_SCREEN;

    public ChronoWishItem(Settings settings) { super(settings); }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world.isClient && OPEN_SCREEN != null) OPEN_SCREEN.run();
        return TypedActionResult.success(stack);
    }

    @Override
    public boolean hasGlint(ItemStack stack) { return true; }
}
