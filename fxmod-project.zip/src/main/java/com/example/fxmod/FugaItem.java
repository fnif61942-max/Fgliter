package com.example.fxmod;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

public class FugaItem extends Item {
    private static final int MAX_USE = 72000;

    public FugaItem(Settings settings) { super(settings); }

    @Override public UseAction getUseAction(ItemStack stack) { return UseAction.BOW; }
    @Override public int getMaxUseTime(ItemStack stack) { return MAX_USE; }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        player.setCurrentHand(hand);
        return TypedActionResult.consume(player.getStackInHand(hand));
    }

    @Override
    public void usageTick(World world, LivingEntity user, ItemStack stack, int remainingUseTicks) {
        if (!(world instanceof ServerWorld sw)) return;
        int used = MAX_USE - remainingUseTicks;
        FugaFx.charge(sw, user, used);
        // во время зарядки игрок «прирос» к земле и неуязвим
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 5, 6, false, false, false));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 5, 200, false, false, false));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 5, 4, false, false, false));
    }

    @Override
    public void onStoppedUsing(ItemStack stack, World world, LivingEntity user, int remainingUseTicks) {
        if (!(world instanceof ServerWorld sw)) return;
        int used = MAX_USE - remainingUseTicks;
        if (used >= FugaFx.CHARGE_TICKS) {
            FugaFx.fire(sw, user);
            if (user instanceof PlayerEntity p) p.getItemCooldownManager().set(this, FugaFx.COOLDOWN);
        } else if (user instanceof ServerPlayerEntity sp) {
            sp.sendMessage(Text.literal("Fuga прервана: держи ПКМ, пока не наполнится заряд"), true);
        }
    }
}
