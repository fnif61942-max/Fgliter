package com.example.fxmod;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameRules;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Клавиша V: «Хронос». За спиной появляются гигантские часы. Стрелки сначала идут вперёд, замедляются, потом идут назад
 * всё быстрее; смена дня и ночи и сам мир откатываются назад. В конце часы выпускают огненную волну радиусом 1000 блоков:
 * всё живое в радиусе погибает.
 */
public final class Chronos {
    // ================= НАСТРОЙКИ =================
    public static final double WAVE_RADIUS = 1000.0;  // радиус огненной волны
    public static final float DAMAGE = 1000f;
    public static final int COOLDOWN = 3600;          // перезарядка, тиков (3600 = 3 минуты)
    private static final boolean RESTORE_WORLD = true; // откатывать блоки мира (постройки за последние 3 мин тоже!)
    private static final double DAYS_BACK = 2.0;       // на сколько суток откатывается небо
    // =============================================

    public static final double CLOCK_DIST = 20.0, CLOCK_Y = 16.0, S = 14.0; // расстояние за спиной, высота, радиус циферблата
    public static final int T_SUMMON = 40, T_FORWARD = 60, T_BACK = 160;
    public static final int T_WAVE = T_SUMMON + T_FORWARD + T_BACK;          // 260
    public static final int T_END = T_WAVE + 75;
    private static final int WAVE_DENSITY = 2;           // плотность эффектов волны: 1 = легче для телефона, 3 = максимум

    private static final String[] NUM = {"XII", "I", "II", "III", "IIII", "V", "VI", "VII", "VIII", "IX", "X", "XI"};
    private static final Random RNG = new Random();
    private static final Map<UUID, Integer> LAST = new HashMap<>();
    private static Ability cur;
    private static ChronoHistory.Session pending;
    private static ServerWorld pendingWorld;
    private static int now = 0;

    private static final class Ability {
        final ServerWorld w; final ServerPlayerEntity owner;
        final Vec3d O, fwd, right, axisX, center, waveCenter;
        final long baseTod; double cum = 0, theta, hourBase, scale; double beatAcc = 0; boolean parity;
        int u = 0; ChronoHistory.Session session; boolean restoreStarted;
        final Set<UUID> killed = new HashSet<>(), passed = new HashSet<>();
        Ability(ServerWorld w, ServerPlayerEntity owner, Vec3d O, Vec3d fwd) {
            this.w = w; this.owner = owner; this.O = O; this.fwd = fwd;
            this.right = new Vec3d(-fwd.z, 0, fwd.x);
            this.axisX = right.multiply(-1);                 // «вправо» для того, кто смотрит на циферблат
            this.center = O.subtract(fwd.multiply(CLOCK_DIST)).add(0, CLOCK_Y, 0);
            this.waveCenter = new Vec3d(center.x, O.y, center.z);
            this.baseTod = w.getTimeOfDay();
            this.theta = Math.toRadians(120);                // как на фото: примерно 12:20
            this.hourBase = Math.toRadians(10);
        }
    }

    // ---------- скорость времени ----------
    private static double dTodForward(int u) {
        if (u <= T_SUMMON) return 150;
        double f = 1 - (u - T_SUMMON) / (double) T_FORWARD;
        return 150 * Math.max(0, f) * Math.max(0, f);
    }
    private static double shape(int k) { double x = k / (double) T_BACK; return 0.02 + x * x; }
    private static double dTod(Ability a, int u) {
        if (u <= T_SUMMON + T_FORWARD) return dTodForward(u);
        if (u <= T_WAVE) return -a.scale * shape(u - T_SUMMON - T_FORWARD - 1);
        return 0;
    }

    // ---------- частицы ----------
    private static void fxv(ServerWorld w, ParticleEffect e, double x, double y, double z, double vx, double vy, double vz) {
        for (ServerPlayerEntity pl : w.getPlayers()) w.spawnParticles(pl, e, true, x, y, z, 0, vx, vy, vz, 1.0);
    }
    private static void fx(ServerWorld w, ParticleEffect e, double x, double y, double z, int n, double dx, double dy, double dz, double sp) {
        for (ServerPlayerEntity pl : w.getPlayers()) w.spawnParticles(pl, e, true, x, y, z, n, dx, dy, dz, sp);
    }
    private static double smooth(double x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }

    private static void snd(Ability a, SoundEvent s, double vol, double pitch) {
        a.w.playSound(null, a.center.x, a.center.y, a.center.z, s, SoundCategory.PLAYERS, (float) vol, (float) pitch);
    }

    /** Сброс состояния при остановке сервера. */
    public static void clear() { cur = null; pending = null; pendingWorld = null; LAST.clear(); ChronoHistory.clear(); }

    // ---------- запуск ----------
    public static void start(ServerPlayerEntity p) {
        if (p.isUsingItem() || !p.isAlive() || p.isSpectator()) return;
        if (cur != null || pending != null) { p.sendMessage(Text.literal("Время уже течёт вспять"), true); return; }
        Integer last = LAST.get(p.getUuid());
        if (last != null && now - last < COOLDOWN) {
            p.sendMessage(Text.literal("Хронос перезаряжается: " + ((COOLDOWN - (now - last)) / 20 + 1) + " с"), true);
            return;
        }
        LAST.put(p.getUuid(), now);

        ServerWorld w = p.getServerWorld();
        Vec3d look = p.getRotationVec(1f);
        Vec3d fwd = new Vec3d(look.x, 0, look.z);
        if (fwd.lengthSquared() < 1.0E-4) { double yaw = Math.toRadians(p.getYaw()); fwd = new Vec3d(-Math.sin(yaw), 0, Math.cos(yaw)); }
        fwd = fwd.normalize();
        Ability a = new Ability(w, p, p.getPos(), fwd);

        double sumF = 0;
        for (int u = 1; u <= T_SUMMON + T_FORWARD; u++) sumF += dTodForward(u);
        double sumShape = 0;
        for (int k = 0; k < T_BACK; k++) sumShape += shape(k);
        a.scale = (sumF + DAYS_BACK * 24000) / sumShape;   // итог: небо возвращается ровно на целые сутки назад
        cur = a;

        for (ServerPlayerEntity pl : w.getPlayers()) {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeInt(p.getId());
            buf.writeDouble(a.O.x); buf.writeDouble(a.O.y); buf.writeDouble(a.O.z);
            buf.writeDouble(fwd.x); buf.writeDouble(fwd.z);
            ServerPlayNetworking.send(pl, FxMod.CHRONO_START, buf);
        }
    }

    // ---------- тик ----------
    public static void tick() {
        now++;
        if (pending != null && pendingWorld != null) {
            ChronoHistory.step(pending, pending.total, System.nanoTime() + 12_000_000L, null);
            if (pending.finished()) { pending = null; pendingWorld = null; }
        }
        if (cur == null) return;
        Ability a = cur;
        a.u++;
        if (a.u <= T_WAVE + 10) lockOwner(a);

        if (a.u <= T_WAVE) timeStep(a);
        if (a.u <= T_WAVE + 10) { drawFace(a); drawHands(a); }
        if (a.u <= T_WAVE) { auras(a); sounds(a); }
        if (RESTORE_WORLD) restoreStep(a);
        if (a.u >= T_WAVE) waveStep(a);

        if (a.u >= T_END) finish(a);
    }

    private static void lockOwner(Ability a) {
        LivingEntity p = a.owner;
        if (p.isRemoved()) return;
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 5, 6, false, false, false));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 5, 200, false, false, false));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 5, 4, false, false, false));
    }

    private static void timeStep(Ability a) {
        double dT = dTod(a, a.u);
        a.cum += dT;
        a.theta += dT / 400.0;                         // стрелка связана со скоростью времени
        a.w.setTimeOfDay(a.baseTod + (long) a.cum);
        sendTime(a.w);
        if (a.u == T_WAVE) { a.w.setTimeOfDay(a.baseTod); sendTime(a.w); }   // мир возвращается ровно как был
    }

    private static void sendTime(ServerWorld w) {
        w.getServer().getPlayerManager().sendToDimension(
                new WorldTimeUpdateS2CPacket(w.getTime(), w.getTimeOfDay(), w.getGameRules().getBoolean(GameRules.DO_DAYLIGHT_CYCLE)),
                w.getRegistryKey());
    }

    private static void finish(Ability a) {
        a.w.setTimeOfDay(a.baseTod);
        sendTime(a.w);
        if (a.session != null && !a.session.finished()) { pending = a.session; pendingWorld = a.w; }
        cur = null;
        if (!a.owner.isRemoved()) a.owner.sendMessage(Text.literal("Время вернулось в норму"), true);
    }

    // ---------- откат блоков мира ----------
    private static void restoreStep(Ability a) {
        int k0 = T_SUMMON + T_FORWARD;
        if (a.u <= k0 || a.u > T_WAVE) return;
        if (!a.restoreStarted) { a.restoreStarted = true; a.session = ChronoHistory.begin(a.w); }
        int k = a.u - k0;                                         // 1..T_BACK
        int target = (int) Math.round(a.session.total * Math.pow(k / (double) T_BACK, 2.2));  // чем дольше, тем быстрее
        int want = Math.max(0, target - a.session.done);
        List<BlockPos> sample = new ArrayList<>();
        ChronoHistory.step(a.session, want, System.nanoTime() + 14_000_000L, sample);
        for (BlockPos bp : sample) {
            for (ServerPlayerEntity pl : a.w.getPlayers()) {
                if (pl.squaredDistanceTo(bp.getX(), bp.getY(), bp.getZ()) < 140 * 140) {
                    fx(a.w, ParticleTypes.REVERSE_PORTAL, bp.getX() + 0.5, bp.getY() + 0.8, bp.getZ() + 0.5, 6, 0.4, 0.6, 0.4, 0.1);
                    break;
                }
            }
        }
    }

    // ---------- рисование циферблата ----------
    private static void plot(Ability a, ParticleEffect e, double x, double y) {
        Vec3d p = a.center.add(a.axisX.multiply(x)).add(0, y, 0);
        fxv(a.w, e, p.x, p.y, p.z, 0, 0, 0);
    }
    private static void line(Ability a, ParticleEffect e, double x0, double y0, double x1, double y1, double sp) {
        double len = Math.hypot(x1 - x0, y1 - y0);
        int n = Math.max(1, (int) (len / sp));
        for (int i = 0; i <= n; i++) { double s = i / (double) n; plot(a, e, x0 + (x1 - x0) * s, y0 + (y1 - y0) * s); }
    }
    private static void arc(Ability a, ParticleEffect e, double r, double a0, double a1, double sp) {
        int n = Math.max(1, (int) (Math.abs(a1 - a0) * r / sp));
        for (int i = 0; i <= n; i++) { double g = a0 + (a1 - a0) * i / n; plot(a, e, Math.sin(g) * r, Math.cos(g) * r); }
    }

    private static double adv(char c) { return c == 'I' ? 0.45 : 0.95; }

    /** Римская цифра: верх цифры смотрит наружу от центра, как на фото. */
    private static void numeral(Ability a, ParticleEffect e, int idx) {
        String s = NUM[idx];
        double ang = idx * Math.PI / 6;
        double rc = 0.80 * S, h = 0.20 * S, sx = h * 0.8;
        double ox = Math.sin(ang), oy = Math.cos(ang), tx = Math.cos(ang), ty = -Math.sin(ang);
        double total = 0.14 * (s.length() - 1);
        for (char c : s.toCharArray()) total += adv(c);
        double cursor = -total / 2;
        for (char c : s.toCharArray()) {
            double cx = cursor + adv(c) / 2;
            double[][] st;
            if (c == 'I') st = new double[][]{{0, -0.5, 0, 0.5}, {-0.2, 0.5, 0.2, 0.5}, {-0.2, -0.5, 0.2, -0.5}};
            else if (c == 'V') st = new double[][]{{-0.45, 0.5, 0, -0.5}, {0.45, 0.5, 0, -0.5}};
            else st = new double[][]{{-0.45, 0.5, 0.45, -0.5}, {-0.45, -0.5, 0.45, 0.5}};
            for (double[] l : st) {
                double x0 = rc * ox + (cx + l[0]) * sx * tx + l[1] * h * ox, y0 = rc * oy + (cx + l[0]) * sx * ty + l[1] * h * oy;
                double x1 = rc * ox + (cx + l[2]) * sx * tx + l[3] * h * ox, y1 = rc * oy + (cx + l[2]) * sx * ty + l[3] * h * oy;
                line(a, e, x0, y0, x1, y1, 0.22);
            }
            cursor += adv(c) + 0.14;
        }
    }

    /** Части циферблата: 0-1 внешнее кольцо, 2-3 внутреннее, 4-15 цифры XII…XI. */
    private static void facePart(Ability a, int i, ParticleEffect e, double g0, double g1) {
        if (i == 0) arc(a, e, 1.00 * S, g0, g1, 0.22);
        else if (i == 1) arc(a, e, 0.96 * S, g0, g1, 0.22);
        else if (i == 2) arc(a, e, 0.62 * S, g0, g1, 0.22);
        else if (i == 3) arc(a, e, 0.58 * S, g0, g1, 0.22);
        else numeral(a, e, i - 4);
    }
    private static int appear(int i) { return i < 4 ? 4 * i : 12 + (i - 4) * 2; }

    private static void drawFace(Ability a) {
        int u = a.u;
        for (int i = 0; i < 16; i++) {
            int ap = appear(i);
            if (u < ap) continue;
            boolean ring = i < 4;
            if (u <= T_WAVE) {
                if (ring && u < ap + 12) {                         // кольцо «рисуется» по кругу
                    double g0 = (u - ap) / 12.0 * Math.PI * 2, g1 = (u - ap + 1) / 12.0 * Math.PI * 2;
                    facePart(a, i, ParticleTypes.END_ROD, g0, g1);
                } else {
                    int off = ring ? ap + 12 : ap;
                    if (u >= off && (u - off) % 24 == 0) facePart(a, i, ParticleTypes.END_ROD, 0, Math.PI * 2);
                }
            } else if (u < T_WAVE + 40 && (u - T_WAVE) % 4 == 0) {   // в момент волны циферблат вспыхивает огнём
                facePart(a, i, ParticleTypes.FLAME, 0, Math.PI * 2);
            }
        }
    }

    private static void hand(Ability a, ParticleEffect e, double ang, double len, double tail) {
        double dx = Math.sin(ang), dy = Math.cos(ang), px = -dy, py = dx;
        line(a, e, -dx * tail, -dy * tail, dx * (len - 0.30 * S), dy * (len - 0.30 * S), 0.2);
        double w = 0.035 * S;
        double ax = dx * len, ay = dy * len;
        double bx = dx * (len - 0.14 * S), by = dy * (len - 0.14 * S);
        double cx = dx * (len - 0.30 * S), cy = dy * (len - 0.30 * S);
        line(a, e, ax, ay, bx + px * w, by + py * w, 0.15);
        line(a, e, ax, ay, bx - px * w, by - py * w, 0.15);
        line(a, e, bx + px * w, by + py * w, cx, cy, 0.15);
        line(a, e, bx - px * w, by - py * w, cx, cy, 0.15);
    }

    private static void drawHands(Ability a) {
        if (a.u < 8) return;
        ParticleEffect e = a.u <= T_WAVE ? ParticleTypes.ELECTRIC_SPARK : ParticleTypes.FLAME;
        double dT = a.u <= T_WAVE ? dTod(a, a.u) : 0;
        double dth = dT / 400.0;
        int steps = (int) Math.max(1, Math.min(10, Math.ceil(Math.abs(dth) / 0.12)));   // размытие движения при быстром вращении
        for (int s = 1; s <= steps; s++) {
            double th = a.theta - dth * (steps - s) / steps;
            hand(a, e, th, 0.78 * S, 0.12 * S);
        }
        hand(a, e, a.hourBase + (a.theta - Math.toRadians(120)) / 12.0, 0.48 * S, 0.10 * S);
        arc(a, e, 0.05 * S, 0, Math.PI * 2, 0.2);
    }

    // ---------- ауры вокруг ----------
    private static void auras(Ability a) {
        ServerWorld w = a.w;
        int u = a.u;
        boolean back = u > T_SUMMON + T_FORWARD;
        double k = back ? (u - T_SUMMON - T_FORWARD) / (double) T_BACK : 0;
        int n = back ? 6 + (int) (14 * k) : 10;
        for (int i = 0; i < n; i++) {   // поток энергии: к часам (вперёд) / от часов (назад)
            double ang = RNG.nextDouble() * Math.PI * 2, d = 12 + RNG.nextDouble() * 28;
            Vec3d s = new Vec3d(a.O.x + Math.cos(ang) * d, a.O.y + 1 + RNG.nextDouble() * 20, a.O.z + Math.sin(ang) * d);
            Vec3d v = a.center.subtract(s).normalize().multiply(back ? -0.8 : 0.9);
            fxv(w, ParticleTypes.END_ROD, s.x, s.y, s.z, v.x, v.y, v.z);
        }
        if (back) { // вихрь «времени» против часовой, быстрее с каждым тиком
            double spin = -(0.03 * (u - T_SUMMON - T_FORWARD) + 0.002 * Math.pow(u - T_SUMMON - T_FORWARD, 2) * 0.1);
            for (int i = 0; i < 14; i++) {
                double ang = i * Math.PI * 2 / 14 + spin * 6;
                double r = 8 + 6 * Math.sin(u * 0.1 + i);
                fxv(w, ParticleTypes.WHITE_ASH, a.O.x + Math.cos(ang) * r, a.O.y + 0.5 + (i % 5), a.O.z + Math.sin(ang) * r,
                        Math.sin(ang) * 0.25, 0.1, -Math.cos(ang) * 0.25);
            }
            fx(w, ParticleTypes.REVERSE_PORTAL, a.O.x, a.O.y + 1, a.O.z, 8, 6, 3, 6, 0.2);
        }
        if (u == 1) { snd(a, SoundEvents.BLOCK_BELL_USE, 8, 0.5); snd(a, SoundEvents.BLOCK_BEACON_ACTIVATE, 6, 0.5); }
        if (u == T_SUMMON) snd(a, SoundEvents.BLOCK_BELL_RESONATE, 8, 0.6);
    }

    // ---------- звуки «тик-так» ----------
    private static void sounds(Ability a) {
        int u = a.u;
        double dT = Math.abs(dTod(a, u));
        a.beatAcc += dT / 150.0;
        if (a.beatAcc >= 1.0) {
            a.beatAcc -= Math.floor(a.beatAcc);
            a.parity = !a.parity;
            boolean back = u > T_SUMMON + T_FORWARD;
            double pitch = back ? 0.9 + 1.1 * Math.min(1.0, dT / 700.0) : 1.0 - 0.3 * (u - T_SUMMON) / T_FORWARD;
            if (u < T_SUMMON) pitch = 1.0;
            snd(a, a.parity ? SoundEvents.BLOCK_STONE_BUTTON_CLICK_ON : SoundEvents.BLOCK_STONE_BUTTON_CLICK_OFF, 3.5, a.parity ? pitch * 1.5 : pitch * 1.1);
        }
        int k0 = T_SUMMON + T_FORWARD;
        if (u == k0) { snd(a, SoundEvents.BLOCK_BEACON_DEACTIVATE, 8, 0.5); snd(a, SoundEvents.BLOCK_BELL_USE, 6, 0.4); } // стрелки разворачиваются
        if (u > k0 && (u - k0) % 20 == 0) snd(a, SoundEvents.BLOCK_BEACON_AMBIENT, 5, 0.5 + 1.5 * (u - k0) / T_BACK);
    }

    // ---------- огненная волна ----------
    /** Радиус волны: сначала медленнее (чтобы было видно), потом разгоняется до 1000 блоков за ~48 тиков. */
    public static double waveRadius(double tw) {
        if (tw <= 0) return 0;
        return Math.min(WAVE_RADIUS, 3.0 * tw + 0.38 * tw * tw);
    }

    private static void waveStep(Ability a) {
        ServerWorld w = a.w;
        int tw = a.u - T_WAVE;
        Vec3d wc = a.waveCenter;
        double r = waveRadius(tw);
        if (tw == 0) {
            fx(w, ParticleTypes.FLASH, a.center.x, a.center.y, a.center.z, 12, 6, 6, 6, 0);
            fx(w, ParticleTypes.EXPLOSION_EMITTER, a.center.x, a.center.y, a.center.z, 10, 10, 10, 10, 0);
            fx(w, ParticleTypes.FLAME, a.center.x, a.center.y, a.center.z, 2500, 10, 10, 2, 0.5);
            snd(a, SoundEvents.ENTITY_GENERIC_EXPLODE, 14, 0.4);
            snd(a, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 14, 0.5);
            snd(a, SoundEvents.BLOCK_BELL_USE, 14, 0.35);
            snd(a, SoundEvents.ENTITY_WITHER_SPAWN, 14, 0.6);
        }
        if (tw <= 45) centerBlast(a, tw, r);
        if (tw % 3 == 0 && r < 300) snd(a, SoundEvents.ENTITY_ENDER_DRAGON_FLAP, 14, 0.5);
        if (tw > 60) return;

        // смерть всего живого, до чего дошла волна
        List<Entity> victims = new ArrayList<>();
        for (Entity e : w.iterateEntities()) {
            if (!(e instanceof LivingEntity) || e == a.owner || !e.isAlive() || a.killed.contains(e.getUuid())) continue;
            if (e instanceof PlayerEntity pl && (pl.isCreative() || pl.isSpectator())) continue;
            if (Math.hypot(e.getX() - wc.x, e.getZ() - wc.z) > r) continue;
            victims.add(e);
        }
        for (Entity e : victims) {
            a.killed.add(e.getUuid());
            e.setOnFireFor(10);
            e.damage(w.getDamageSources().indirectMagic(a.owner, a.owner), DAMAGE);
            if (e.isAlive()) ((LivingEntity) e).kill();
            fx(w, ParticleTypes.FLAME, e.getX(), e.getY() + 1, e.getZ(), 40, 0.5, 1.0, 0.5, 0.12);
            fx(w, ParticleTypes.LAVA, e.getX(), e.getY() + 1, e.getZ(), 6, 0.4, 0.8, 0.4, 0);
        }

        // толстая стена огня рядом с каждым игроком + звук, когда волна проходит игрока
        for (ServerPlayerEntity pl : w.getPlayers()) {
            double dx = pl.getX() - wc.x, dz = pl.getZ() - wc.z, D = Math.hypot(dx, dz);
            if (!a.passed.contains(pl.getUuid()) && D <= r) {
                a.passed.add(pl.getUuid());
                w.playSound(null, pl.getX(), pl.getY(), pl.getZ(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 10f, 0.5f);
                w.playSound(null, pl.getX(), pl.getY(), pl.getZ(), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 8f, 0.4f);
                w.playSound(null, pl.getX(), pl.getY(), pl.getZ(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 6f, 0.6f);
                w.spawnParticles(pl, ParticleTypes.FLASH, true, pl.getX(), pl.getY() + 2, pl.getZ(), 4, 1, 1, 1, 0);
            }
            if (Math.abs(D - r) > 150 || r < 1) continue;
            double phi = D < 1.0E-3 ? 0 : Math.atan2(dz, dx);
            double span = r <= 150 ? Math.PI : Math.min(Math.PI, 170.0 / r + 0.02);
            double step = 3.5 / Math.max(r, 4);
            int idx = 0;
            for (double th = phi - span; th <= phi + span; th += step, idx++) {
                double rr = r + (RNG.nextDouble() - 0.5) * 10;            // толщина стены ~10 блоков
                double x = wc.x + Math.cos(th) * rr, z = wc.z + Math.sin(th) * rr;
                if (Math.hypot(x - pl.getX(), z - pl.getZ()) > 160) continue;
                for (int k = 0; k < 3 * WAVE_DENSITY; k++) {
                    double y = pl.getY() - 6 + RNG.nextDouble() * 70;
                    w.spawnParticles(pl, ParticleTypes.FLAME, true, x, y, z, 3, 1.0, 1.0, 1.0, 0.08);
                }
                w.spawnParticles(pl, ParticleTypes.LAVA, true, x, wc.y + 1, z, 2, 1.0, 0.5, 1.0, 0);
                w.spawnParticles(pl, ParticleTypes.LARGE_SMOKE, true, x, wc.y + 3 + RNG.nextDouble() * 10, z, 1, 1.5, 2.0, 1.5, 0.05);
                if (idx % 4 == 0) w.spawnParticles(pl, ParticleTypes.EXPLOSION, true, x, wc.y + 4 + RNG.nextDouble() * 25, z, 1, 0, 0, 0, 0);
                if (idx % 10 == 0) w.spawnParticles(pl, ParticleTypes.EXPLOSION_EMITTER, true, x, wc.y + 2, z, 1, 0, 0, 0, 0);
            }
        }
    }

    /** Эпицентр: огненный шар, столп до небес и расширяющийся купол. */
    private static void centerBlast(Ability a, int tw, double r) {
        ServerWorld w = a.w;
        Vec3d wc = a.waveCenter;
        Vec3d c = a.center;
        if (tw <= 12) { // шар
            double R = 4 + tw * 3.5;
            for (int i = 0; i < 160 * WAVE_DENSITY; i++) {
                double th = RNG.nextDouble() * Math.PI * 2, z = RNG.nextDouble() * 2 - 1, rr = Math.sqrt(1 - z * z);
                fxv(w, ParticleTypes.FLAME, c.x + rr * Math.cos(th) * R, c.y + z * R, c.z + rr * Math.sin(th) * R, rr * Math.cos(th) * 0.4, z * 0.4, rr * Math.sin(th) * 0.4);
            }
            fx(w, ParticleTypes.LAVA, c.x, c.y, c.z, 30, R * 0.5, R * 0.5, R * 0.5, 0);
        }
        // столп огня от земли до неба (до 250 блоков)
        double h = Math.min(250, tw * 20.0);
        double fade = tw > 30 ? Math.max(0.2, 1 - (tw - 30) / 15.0) : 1;
        for (double y = 0; y <= h; y += 4) {
            fx(w, ParticleTypes.FLAME, wc.x, wc.y + y, wc.z, (int) (14 * WAVE_DENSITY * fade), 3.5, 2.2, 3.5, 0.06);
            fx(w, ParticleTypes.LAVA, wc.x, wc.y + y, wc.z, Math.max(1, (int) (2 * WAVE_DENSITY * fade)), 3.0, 2.0, 3.0, 0);
            fx(w, ParticleTypes.LARGE_SMOKE, wc.x, wc.y + y, wc.z, (int) (3 * WAVE_DENSITY * fade), 4.5, 2.0, 4.5, 0.03);
        }
        // купол
        if (tw <= 30) {
            double rd = Math.min(r, 130);
            for (int i = 0; i < 160 * WAVE_DENSITY; i++) {
                double th = RNG.nextDouble() * Math.PI * 2, z = RNG.nextDouble(), rr = Math.sqrt(1 - z * z);
                fx(w, ParticleTypes.FLAME, wc.x + rr * Math.cos(th) * rd, wc.y + z * rd, wc.z + rr * Math.sin(th) * rd, 1, 0, 0, 0, 0);
            }
        }
    }

    private Chronos() {}
}
