package com.example.fxmod;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/** «Fuga» — огненная стрела: зарядка, полёт со шлейфом, огромный взрыв, огненный столп и купол. */
public final class FugaFx {
    public static final double SPEED = 3.0; // блоков за тик (4 шага по 0.75) — клиентская камера считает так же
    private static final double RADIUS = 7.0;
    private static final Random RNG = new Random();
    private static final List<Bolt> BOLTS = new ArrayList<>();
    private static final List<Blast> BLASTS = new ArrayList<>();

    private static final class Bolt {
        final ServerWorld w; final LivingEntity owner; final Vec3d dir; Vec3d pos; int t = 0;
        Bolt(ServerWorld w, LivingEntity owner, Vec3d pos, Vec3d dir) { this.w = w; this.owner = owner; this.pos = pos; this.dir = dir; }
    }

    private static final class Blast {
        final ServerWorld w; final Vec3d pos; int t = 0;
        Blast(ServerWorld w, Vec3d pos) { this.w = w; this.pos = pos; }
    }

    /** Частицы видны камере даже далеко от игрока (force = дальняя дистанция). */
    private static void fx(ServerWorld w, ParticleEffect e, double x, double y, double z, int n, double dx, double dy, double dz, double sp) {
        for (ServerPlayerEntity pl : w.getPlayers()) {
            w.spawnParticles(pl, e, true, x, y, z, n, dx, dy, dz, sp);
        }
    }

    private static Vec3d[] basis(Vec3d dir) {
        Vec3d u = dir.crossProduct(new Vec3d(0, 1, 0));
        if (u.lengthSquared() < 1.0E-4) u = new Vec3d(1, 0, 0);
        u = u.normalize();
        Vec3d v = dir.crossProduct(u).normalize();
        return new Vec3d[]{u, v};
    }

    public static void charge(ServerWorld w, LivingEntity p, int ticks) {
        Vec3d dir = p.getRotationVec(1f);
        Vec3d c = p.getEyePos().add(dir.multiply(2.0));
        Vec3d[] b = basis(dir);
        double r = Math.min(ticks, 20) * 0.06;
        for (int i = 0; i < 20; i++) {
            double a = i * Math.PI * 2 / 20 + ticks * 0.3;
            Vec3d o = b[0].multiply(Math.cos(a) * r).add(b[1].multiply(Math.sin(a) * r));
            fx(w, ParticleTypes.FLAME, c.x + o.x, c.y + o.y, c.z + o.z, 1, 0, 0, 0, 0.01);
        }
        for (int k = 0; k < 10; k++) {
            Vec3d s = c.add(dir.multiply(-1.0 + k * 0.3));
            fx(w, ParticleTypes.FLAME, s.x, s.y, s.z, 1, 0.03, 0.03, 0.03, 0.0);
        }
        // огонь стекается к рукам, пока идёт зарядка
        fx(w, ParticleTypes.LAVA, p.getX(), p.getY() + 1, p.getZ(), 1, 0.6, 0.6, 0.6, 0);
        if (ticks == 20) {
            w.playSound(null, p.getBlockPos(), SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.PLAYERS, 2f, 0.6f);
            fx(w, ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        }
    }

    public static void fire(ServerWorld w, LivingEntity p) {
        Vec3d dir = p.getRotationVec(1f);
        Vec3d start = p.getEyePos().add(dir.multiply(1.5));
        BOLTS.add(new Bolt(w, p, start, dir));
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 2f, 0.5f);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, SoundCategory.PLAYERS, 1.5f, 0.6f);
        if (p instanceof ServerPlayerEntity sp) {
            PacketByteBuf buf = PacketByteBufs.create();
            Vec3d eye = p.getEyePos();
            buf.writeDouble(eye.x); buf.writeDouble(eye.y); buf.writeDouble(eye.z);
            buf.writeDouble(dir.x); buf.writeDouble(dir.y); buf.writeDouble(dir.z);
            ServerPlayNetworking.send(sp, FxMod.FIRE_PACKET, buf);
        }
    }

    public static void tick() {
        Iterator<Bolt> it = BOLTS.iterator();
        while (it.hasNext()) {
            Bolt b = it.next();
            b.t++;
            boolean hit = false;
            for (int s = 0; s < 4 && !hit; s++) {
                b.pos = b.pos.add(b.dir.multiply(0.75));
                trail(b);
                BlockPos bp = BlockPos.ofFloored(b.pos);
                if (!b.w.getBlockState(bp).getCollisionShape(b.w, bp).isEmpty()) {
                    hit = true;
                    b.pos = b.pos.subtract(b.dir.multiply(0.75));
                } else if (!b.w.getOtherEntities(b.owner, new Box(b.pos, b.pos).expand(0.8),
                        e -> e instanceof LivingEntity && e.isAlive()).isEmpty()) {
                    hit = true;
                }
            }
            if (hit || b.t > 40) {
                explode(b);
                it.remove();
            }
        }

        Iterator<Blast> bi = BLASTS.iterator();
        while (bi.hasNext()) {
            Blast bl = bi.next();
            bl.t++;
            blastTick(bl);
            if (bl.t >= 45) bi.remove();
        }
    }

    private static void trail(Bolt b) {
        ServerWorld w = b.w;
        Vec3d[] bs = basis(b.dir);
        fx(w, ParticleTypes.FLAME, b.pos.x, b.pos.y, b.pos.z, 14, 0.3, 0.3, 0.3, 0.03);
        fx(w, ParticleTypes.LAVA, b.pos.x, b.pos.y, b.pos.z, 2, 0.25, 0.25, 0.25, 0);
        fx(w, ParticleTypes.SMOKE, b.pos.x, b.pos.y, b.pos.z, 3, 0.25, 0.25, 0.25, 0.01);
        fx(w, ParticleTypes.CAMPFIRE_COSY_SMOKE, b.pos.x, b.pos.y, b.pos.z, 1, 0.1, 0.1, 0.1, 0.02);
        for (int i = 0; i < 10; i++) { // вихрь вокруг наконечника
            double a = i * Math.PI / 5 + b.t * 0.8;
            Vec3d o = bs[0].multiply(Math.cos(a) * 1.0).add(bs[1].multiply(Math.sin(a) * 1.0));
            fx(w, ParticleTypes.FLAME, b.pos.x + o.x, b.pos.y + o.y, b.pos.z + o.z, 1, 0, 0, 0, 0.0);
        }
    }

    private static void explode(Bolt b) {
        ServerWorld w = b.w;
        Vec3d p = b.pos;
        BLASTS.add(new Blast(w, p));

        fx(w, ParticleTypes.EXPLOSION_EMITTER, p.x, p.y, p.z, 3, 1.0, 1.0, 1.0, 0);
        fx(w, ParticleTypes.FLASH, p.x, p.y, p.z, 3, 0.5, 0.5, 0.5, 0);
        fx(w, ParticleTypes.FLAME, p.x, p.y, p.z, 500, 3.0, 3.0, 3.0, 0.2);
        fx(w, ParticleTypes.LAVA, p.x, p.y, p.z, 100, 3.0, 3.0, 3.0, 0);
        fx(w, ParticleTypes.LARGE_SMOKE, p.x, p.y, p.z, 150, 3.0, 3.0, 3.0, 0.06);
        w.playSound(null, BlockPos.ofFloored(p), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 4f, 0.6f);

        Box area = new Box(p, p).expand(RADIUS);
        for (Entity e : w.getOtherEntities(b.owner, area, en -> en instanceof LivingEntity)) {
            double d = e.getPos().distanceTo(p);
            if (d > RADIUS) continue;
            float dmg = (float) (28 * (1 - d / RADIUS)) + 4;
            e.damage(w.getDamageSources().indirectMagic(b.owner, b.owner), dmg);
            e.setOnFireFor(10);
            Vec3d kb = e.getPos().subtract(p).normalize().multiply(1.4).add(0, 0.6, 0);
            e.setVelocity(kb);
            e.velocityModified = true;
        }

        if (b.owner instanceof ServerPlayerEntity sp) {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeDouble(p.x); buf.writeDouble(p.y); buf.writeDouble(p.z);
            ServerPlayNetworking.send(sp, FxMod.IMPACT_PACKET, buf);
        }
    }

    /** После взрыва: ударная волна, огненный столп, расширяющийся купол, дождь из искр. */
    private static void blastTick(Blast bl) {
        ServerWorld w = bl.w;
        Vec3d p = bl.pos;
        int t = bl.t;

        // кольцо ударной волны по земле
        if (t <= 30) {
            double r = t * 0.9;
            int points = (int) (r * 6) + 16;
            for (int i = 0; i < points; i++) {
                double a = i * (Math.PI * 2 / points);
                double px = p.x + Math.cos(a) * r, pz = p.z + Math.sin(a) * r;
                fx(w, ParticleTypes.FLAME, px, p.y + 0.3, pz, 1, 0, 0.15, 0, 0.04);
                if (i % 4 == 0) fx(w, ParticleTypes.LARGE_SMOKE, px, p.y + 0.4, pz, 1, 0, 0.1, 0, 0.02);
            }
        }

        // огненный столп с вращающимися языками
        if (t <= 35) {
            double h = t * 1.1;
            for (int k = 0; k < 4; k++) {
                double a = t * 0.5 + k * Math.PI / 2;
                double rr = 1.2 + h * 0.06;
                fx(w, ParticleTypes.FLAME, p.x + Math.cos(a) * rr, p.y + h, p.z + Math.sin(a) * rr, 4, 0.15, 0.4, 0.15, 0.02);
                fx(w, ParticleTypes.LAVA, p.x + Math.cos(a) * rr, p.y + h, p.z + Math.sin(a) * rr, 1, 0.2, 0.2, 0.2, 0);
            }
            fx(w, ParticleTypes.LARGE_SMOKE, p.x, p.y + h, p.z, 3, 0.8, 0.5, 0.8, 0.02);
        }

        // расширяющийся огненный купол
        if (t <= 22) {
            double r = t * 0.55;
            for (int i = 0; i < 70; i++) {
                double th = RNG.nextDouble() * Math.PI * 2;
                double z = RNG.nextDouble();
                double rr = Math.sqrt(1 - z * z);
                fx(w, ParticleTypes.FLAME, p.x + rr * Math.cos(th) * r, p.y + z * r, p.z + rr * Math.sin(th) * r, 1, 0, 0, 0, 0);
            }
        }

        // дождь из огня и пепла
        if (t >= 8) {
            fx(w, ParticleTypes.FALLING_LAVA, p.x, p.y + 9, p.z, 14, 7, 2, 7, 0);
            fx(w, ParticleTypes.ASH, p.x, p.y + 4, p.z, 25, 8, 4, 8, 0.02);
        }

        if (t == 1) fx(w, ParticleTypes.FLASH, p.x, p.y + 1, p.z, 5, 1, 1, 1, 0);
        if (t == 6) w.playSound(null, BlockPos.ofFloored(p), SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, SoundCategory.PLAYERS, 4f, 0.5f);
        if (t == 12) w.playSound(null, BlockPos.ofFloored(p), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 4f, 0.7f);
    }

    private FugaFx() {}
}
