package com.example.fxmod.client;

import com.example.fxmod.FxMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.util.math.Vec3d;

public class FxModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(FxMod.FIRE_PACKET, (client, handler, buf, sender) -> {
            Vec3d o = new Vec3d(buf.readDouble(), buf.readDouble(), buf.readDouble());
            Vec3d d = new Vec3d(buf.readDouble(), buf.readDouble(), buf.readDouble());
            client.execute(() -> FugaCinematic.start(o, d));
        });
        ClientPlayNetworking.registerGlobalReceiver(FxMod.IMPACT_PACKET, (client, handler, buf, sender) -> {
            Vec3d p = new Vec3d(buf.readDouble(), buf.readDouble(), buf.readDouble());
            client.execute(() -> FugaCinematic.impact(p));
        });
        ClientTickEvents.END_CLIENT_TICK.register(c -> FugaCinematic.tick());
    }
}
