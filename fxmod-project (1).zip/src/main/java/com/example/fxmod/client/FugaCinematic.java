package com.example.fxmod.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

/** Кинематографическая камера для Fuga: старт от глаз игрока → облёт стрелы → взрыв с вращением вокруг эпицентра. */
public final class FugaCinematic {
    private static final double SPEED = 3.0;
    private static boolean active;
    private static Vec3d origin = Vec3d.ZERO, dir = new Vec3d(0, 0, 1), impact;
    private static double clock, impactClock = -1;

    public static boolean active() { return active; }

    public static void start(Vec3d o, Vec3d d) {
        origin = o; dir = d.normalize(); impact = null; impactClock = -1; clock = 0; active = true;
    }

    public static void impact(Vec3d pos) {
        if (!active) return;
        impact = pos; impactClock = clock;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null) {
            // слои звука прямо в точке камеры-эпицентра
            mc.world.playSound(pos.x, pos.y, pos.z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 6f, 0.5f, false);
            mc.world.playSound(pos.x, pos.y, pos.z, SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, SoundCategory.PLAYERS, 6f, 0.5f, false);
            mc.world.playSound(pos.x, pos.y, pos.z, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 6f, 0.6f, false);
        }
    }

    public static void tick() {
        if (!active) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) { active = false; return; }
        clock += 1;
        if (clock > 200 || (impact != null && clock - impactClock > 75)) active = false;
    }

    private static Vec3d[] basis(Vec3d d) {
        Vec3d u = d.crossProduct(new Vec3d(0, 1, 0));
        if (u.lengthSquared() < 1.0E-4) u = new Vec3d(1, 0, 0);
        u = u.normalize();
        return new Vec3d[]{u, d.crossProduct(u).normalize()};
    }

    private static double smooth(double x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }

    /** Возвращает {x, y, z, yaw, pitch} или null. */
    public static double[] compute(float tickDelta) {
        if (!active) return null;
        double t = clock + tickDelta;
        Vec3d pos, look;

        if (impact == null || t < impactClock) {
            // полёт: камера кружит вокруг стрелы, стартуя из глаз игрока
            Vec3d bolt = origin.add(dir.multiply(1.5 + SPEED * t));
            Vec3d[] b = basis(dir);
            double ramp = Math.min(t, 12);
            double a = 0.8 + t * 0.14;
            double rad = 4.0 + ramp * 0.15;
            double back = 2.5 + ramp * 0.9;
            Vec3d off = b[0].multiply(Math.cos(a) * rad).add(b[1].multiply(Math.sin(a) * rad)).subtract(dir.multiply(back));
            Vec3d orbit = bolt.add(off);
            pos = origin.lerp(orbit, smooth(t / 8.0));
            look = bolt.add(dir.multiply(3));
        } else {
            // после взрыва: камера поднимается и вращается вокруг эпицентра
            double s = t - impactClock;
            Vec3d c = impact.add(0, 2 + s * 0.05, 0);
            double ang = 0.6 + s * 0.045;
            double d = 11 + s * 0.22;
            double h = 3 + s * 0.12;
            pos = c.add(Math.cos(ang) * d, h, Math.sin(ang) * d);
            look = c;
            double shake = Math.max(0, 1 - s / 22.0) * 0.7; // тряска камеры
            pos = pos.add((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
        }

        Vec3d f = look.subtract(pos);
        double yaw = Math.toDegrees(Math.atan2(-f.x, f.z));
        double pitch = -Math.toDegrees(Math.atan2(f.y, Math.sqrt(f.x * f.x + f.z * f.z)));
        return new double[]{pos.x, pos.y, pos.z, yaw, pitch};
    }

    private FugaCinematic() {}
}
