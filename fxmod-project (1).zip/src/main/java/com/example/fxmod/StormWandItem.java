package com.example.fxmod;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class StormWandItem extends Item {
    public StormWandItem(Settings settings) { super(settings); }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world instanceof ServerWorld sw) {
            Fx.start(sw, player.getX(), player.getY(), player.getZ());

            LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(sw);
            if (bolt != null) {
                bolt.refreshPositionAfterTeleport(player.getX(), player.getY(), player.getZ());
                bolt.setCosmetic(true); // только визуал, без урона и огня
                sw.spawnEntity(bolt);
            }
            sw.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 1.2f, 0.8f);
            player.getItemCooldownManager().set(this, 50);
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}
