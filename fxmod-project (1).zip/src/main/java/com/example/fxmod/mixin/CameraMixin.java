package com.example.fxmod.mixin;

import com.example.fxmod.client.FugaCinematic;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setPos(double x, double y, double z);
    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Shadow private boolean thirdPerson;

    @Inject(method = "update", at = @At("TAIL"))
    private void fxmod$cinematic(BlockView area, Entity focused, boolean tp, boolean inverse, float tickDelta, CallbackInfo ci) {
        double[] c = FugaCinematic.compute(tickDelta);
        if (c != null) {
            setPos(c[0], c[1], c[2]);
            setRotation((float) c[3], (float) c[4]);
            this.thirdPerson = true; // показываем игрока и прячем руку
        }
    }
}
