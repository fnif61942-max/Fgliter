package com.example.fxmod;

import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Анимированный эффект: двойная спираль вверх + расширяющаяся ударная волна + вспышки. */
public final class Fx {
    private static final int DURATION = 40;
    private static final List<Effect> ACTIVE = new ArrayList<>();

    private static final class Effect {
        final ServerWorld w; final double x, y, z; int t = 0;
        Effect(ServerWorld w, double x, double y, double z) { this.w = w; this.x = x; this.y = y; this.z = z; }
    }

    public static void start(ServerWorld w, double x, double y, double z) {
        ACTIVE.add(new Effect(w, x, y, z));
        w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, x, y + 1, z, 1, 0, 0, 0, 0);
        w.spawnParticles(ParticleTypes.FLASH, x, y + 1, z, 1, 0, 0, 0, 0);
    }

    public static void tick() {
        Iterator<Effect> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Effect e = it.next();
            e.t++;
            ServerWorld w = e.w;

            // двойная спираль, поднимается к небу
            double h = e.t * 0.35;
            double a = e.t * 0.55;
            for (int s = 0; s < 2; s++) {
                double ang = a + s * Math.PI;
                double r = 1.5 + Math.sin(e.t * 0.2) * 0.5;
                w.spawnParticles(ParticleTypes.END_ROD, e.x + Math.cos(ang) * r, e.y + h, e.z + Math.sin(ang) * r, 2, 0.02, 0.02, 0.02, 0.01);
                w.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, e.x + Math.cos(ang) * r, e.y + h, e.z + Math.sin(ang) * r, 1, 0, 0, 0, 0.02);
            }

            // ударная волна по земле
            if (e.t <= 25) {
                double radius = e.t * 0.7;
                int points = (int) (radius * 8) + 12;
                for (int i = 0; i < points; i++) {
                    double ang = i * (Math.PI * 2 / points);
                    double px = e.x + Math.cos(ang) * radius;
                    double pz = e.z + Math.sin(ang) * radius;
                    w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, px, e.y + 0.1, pz, 1, 0, 0.1, 0, 0.05);
                    if (i % 3 == 0) w.spawnParticles(ParticleTypes.CLOUD, px, e.y + 0.2, pz, 1, 0, 0.05, 0, 0.02);
                }
            }

            // финальный салют
            if (e.t == DURATION - 5) {
                w.spawnParticles(ParticleTypes.FIREWORK, e.x, e.y + h, e.z, 150, 0.1, 0.1, 0.1, 0.4);
                w.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, e.x, e.y + h, e.z, 100, 0.5, 0.5, 0.5, 0.5);
            }
            if (e.t >= DURATION) it.remove();
        }
    }

    private Fx() {}
}
