package com.example.fxmod;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

public class FugaItem extends Item {
    private static final int MAX_USE = 72000;
    private static final int CHARGE_TICKS = 20;

    public FugaItem(Settings settings) { super(settings); }

    @Override public UseAction getUseAction(ItemStack stack) { return UseAction.BOW; }
    @Override public int getMaxUseTime(ItemStack stack) { return MAX_USE; }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        player.setCurrentHand(hand);
        return TypedActionResult.consume(player.getStackInHand(hand));
    }

    @Override
    public void usageTick(World world, LivingEntity user, ItemStack stack, int remainingUseTicks) {
        if (world instanceof ServerWorld sw) FugaFx.charge(sw, user, MAX_USE - remainingUseTicks);
    }

    @Override
    public void onStoppedUsing(ItemStack stack, World world, LivingEntity user, int remainingUseTicks) {
        int used = MAX_USE - remainingUseTicks;
        if (used >= CHARGE_TICKS && world instanceof ServerWorld sw) {
            FugaFx.fire(sw, user);
            if (user instanceof PlayerEntity p) p.getItemCooldownManager().set(this, 100);
        }
    }
}
